import { CreateSocialDto } from './dto/create-social.dto';
import { UpdateSocialDto } from './dto/update-social.dto';
import { SocialDocument } from './entities/social.entity';
import mongoose, { Model } from 'mongoose';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { SearchParamDto } from './dto/search-param.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
export declare class SocialService {
    private readonly socialModel;
    private readonly configService;
    private readonly httpService;
    private readonly logger;
    private readonly algorithm;
    constructor(socialModel: Model<SocialDocument>, configService: ConfigService, httpService: HttpService);
    private encrypt;
    private decrypt;
    create(createSocialDto: CreateSocialDto): Promise<import("./entities/social.entity").Social & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    findAll(query?: SearchParamDto): Promise<{
        data: Omit<import("./entities/social.entity").Social & mongoose.Document<any, any, any> & {
            _id: mongoose.Types.ObjectId;
        }, never>[];
        count: number;
        search: {
            platforms: string[];
            status: string[];
        };
    }>;
    findOne(id: string): Promise<{
        accessToken: string;
        _id: unknown;
    }>;
    update(id: string, updateSocialDto: UpdateSocialDto): Promise<import("./entities/social.entity").Social & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    remove(id: string): Promise<import("./entities/social.entity").Social & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    updateStatus(id: string, status: string): Promise<void>;
    setTelegramWebhook(accessToken: string, botId: string): Promise<any>;
    deleteTelegramWebhook(accessToken: string): Promise<any>;
    getBotToken(botId: string): Promise<{
        accessToken: string;
        engageBotId: any;
    }>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getPublishedCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getDraftCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    dateWiseComparison(query: ComparisonDto): Promise<any[]>;
}
