"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialStatusEnumList = exports.SocialStatusEnum = void 0;
exports.SocialStatusEnum = {
    PUBLISHED: 'published',
    DRAFT: 'draft',
};
exports.SocialStatusEnumList = Object.values(exports.SocialStatusEnum);
//# sourceMappingURL=social-status.enum.js.map