export declare const SocialPlatformEnum: {
    readonly FACEBOOK: "facebook";
    readonly TELEGRAM: "telegram";
    readonly WHATSAPP: "whatsapp";
};
export declare const SocialPlatformEnumList: string[];
