"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialPlatformEnumList = exports.SocialPlatformEnum = void 0;
exports.SocialPlatformEnum = {
    FACEBOOK: 'facebook',
    TELEGRAM: 'telegram',
    WHATSAPP: 'whatsapp',
};
exports.SocialPlatformEnumList = Object.values(exports.SocialPlatformEnum);
//# sourceMappingURL=social-platform.enum.js.map