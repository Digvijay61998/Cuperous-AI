export declare const SocialStatusEnum: {
    readonly PUBLISHED: "published";
    readonly DRAFT: "draft";
};
export declare const SocialStatusEnumList: string[];
