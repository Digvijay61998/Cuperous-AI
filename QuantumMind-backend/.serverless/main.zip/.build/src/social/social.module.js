"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialModule = void 0;
const common_1 = require("@nestjs/common");
const social_service_1 = require("./social.service");
const social_controller_1 = require("./social.controller");
const social_provider_1 = require("./social.provider");
const axios_1 = require("@nestjs/axios");
let SocialModule = class SocialModule {
};
SocialModule = __decorate([
    (0, common_1.Module)({
        controllers: [social_controller_1.SocialController],
        providers: [social_service_1.SocialService, ...social_provider_1.socialProviders],
        imports: [axios_1.HttpModule.register({ timeout: 5000 })],
        exports: [social_service_1.SocialService],
    })
], SocialModule);
exports.SocialModule = SocialModule;
//# sourceMappingURL=social.module.js.map