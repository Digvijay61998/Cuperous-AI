"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const create_social_dto_1 = require("./dto/create-social.dto");
const search_param_dto_1 = require("./dto/search-param.dto");
const update_social_dto_1 = require("./dto/update-social.dto");
const update_status_dto_1 = require("./dto/update-status.dto");
const social_service_1 = require("./social.service");
const conversation_service_1 = require("src/conversation/conversation.service");
const report_params_dto_1 = require("src/util/report-params.dto");
const comparison_dto_1 = require("src/util/comparison.dto");
let SocialController = class SocialController {
    constructor(socialService, conversationService) {
        this.socialService = socialService;
        this.conversationService = conversationService;
    }
    async create(createSocialDto) {
        return await this.socialService.create(createSocialDto);
    }
    async findAll(query) {
        return await this.socialService.findAll(query);
    }
    async getStats() {
        return await this.socialService.stats();
    }
    async getPlatformConversationsStats() {
        return await this.conversationService.TotalCountPlatform();
    }
    async getDatewisePlatfrom(query) {
        return await this.conversationService.DateWisePlatform(query);
    }
    async getDaywisePlatform(query) {
        return await this.conversationService.DayWisePlatform(query);
    }
    async getDateWiseComparison(query) {
        return await this.socialService.dateWiseComparison(query);
    }
    async findOne(id) {
        return await this.socialService.findOne(id);
    }
    async update(id, updateSocialDto) {
        return await this.socialService.update(id, updateSocialDto);
    }
    async updateStatus(id, body) {
        return await this.socialService.updateStatus(id, body.status);
    }
    async remove(id) {
        return await this.socialService.remove(id);
    }
};
__decorate([
    (0, common_1.Post)(),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_social_dto_1.CreateSocialDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('report'),
    (0, public_decorator_1.Public)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getPlatformConversationsStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getDatewisePlatfrom", null);
__decorate([
    (0, common_1.Get)('report/day-wise'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getDaywisePlatform", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-comparison'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [comparison_dto_1.ComparisonDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getDateWiseComparison", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_social_dto_1.UpdateSocialDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/update-status'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_status_dto_1.UpdateStatusDto]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "remove", null);
SocialController = __decorate([
    (0, common_1.Controller)('social'),
    (0, swagger_1.ApiTags)('Social'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [social_service_1.SocialService,
        conversation_service_1.ConversationService])
], SocialController);
exports.SocialController = SocialController;
//# sourceMappingURL=social.controller.js.map