"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SocialService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialService = void 0;
const common_1 = require("@nestjs/common");
const constants_1 = require("./constants");
const mongoose_1 = __importStar(require("mongoose"));
const social_platform_enum_1 = require("./enums/social-platform.enum");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const util_1 = require("util");
const rxjs_1 = require("rxjs");
const axios_1 = require("@nestjs/axios");
const social_status_enum_1 = require("./enums/social-status.enum");
const get_subtitle_1 = require("src/util/get-subtitle");
const bson_1 = require("bson");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
let SocialService = SocialService_1 = class SocialService {
    constructor(socialModel, configService, httpService) {
        this.socialModel = socialModel;
        this.configService = configService;
        this.httpService = httpService;
        this.logger = new common_1.Logger(SocialService_1.name);
        this.algorithm = 'aes-256-cbc';
    }
    async encrypt(text) {
        const password = this.configService.get('encryption.key');
        const key = (await (0, util_1.promisify)(crypto_1.scrypt)(password, 'salt', 32));
        const iv = (0, crypto_1.randomBytes)(16);
        const cipher = (0, crypto_1.createCipheriv)(this.algorithm, key, iv);
        const encrypted = Buffer.concat([cipher.update(text), cipher.final()]);
        return `${iv.toString('hex')}:${encrypted.toString('hex')}`;
    }
    async decrypt(text) {
        const password = this.configService.get('encryption.key');
        const [iv, encryptedText] = text.split(':');
        const key = (await (0, util_1.promisify)(crypto_1.scrypt)(password, 'salt', 32));
        const decipher = (0, crypto_1.createDecipheriv)(this.algorithm, key, Buffer.from(iv, 'hex'));
        const decrypted = Buffer.concat([
            decipher.update(Buffer.from(encryptedText, 'hex')),
            decipher.final(),
        ]);
        return decrypted.toString();
    }
    async create(createSocialDto) {
        try {
            const social = await this.socialModel.create(Object.assign(Object.assign({}, createSocialDto), { accessToken: await this.encrypt(createSocialDto.accessToken) }));
            return social;
        }
        catch (error) {
            this.logger.error(`Error creating tag: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, status, platform, bot, } = query;
            const queryObject = {};
            if (status)
                queryObject['status'] = status;
            if (platform)
                queryObject['platform'] = platform;
            if (bot)
                queryObject['engageBot'] = bot;
            const social = this.socialModel
                .find(queryObject)
                .sort({ createdAt: -1 })
                .populate('engageBot', 'name')
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                social.limit(limitOfDocuments);
            }
            const data = await social.exec();
            const count = await this.socialModel.countDocuments();
            const search = {
                platforms: social_platform_enum_1.SocialPlatformEnumList,
                status: social_status_enum_1.SocialStatusEnumList,
            };
            return { data, count, search };
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findOne(id) {
        try {
            const social = await this.socialModel
                .findById(id)
                .populate('botId', 'name')
                .exec();
            if (!social)
                throw new common_1.HttpException('No Social Integration found', 404);
            return Object.assign(Object.assign({}, social.toObject()), { accessToken: await this.decrypt(social.accessToken) });
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async update(id, updateSocialDto) {
        try {
            const social = await this.socialModel.findByIdAndUpdate(id, Object.assign(Object.assign({}, updateSocialDto), { accessToken: updateSocialDto.accessToken &&
                    (await this.encrypt(updateSocialDto.accessToken)) }), { new: true });
            if (!social)
                throw new common_1.HttpException('No Social Integration found', 404);
            return social;
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async remove(id) {
        try {
            const social = await this.socialModel.findByIdAndDelete(id);
            if (!social)
                throw new common_1.HttpException('No Social Integration found', 404);
            return social;
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateStatus(id, status) {
        try {
            const social = await this.socialModel.findById(id);
            if (!social)
                throw new common_1.HttpException('No Social Integration found', 404);
            if (social.platform === 'telegram') {
                if (status === social_status_enum_1.SocialStatusEnum.PUBLISHED) {
                    await this.setTelegramWebhook(social.accessToken, social.botId);
                }
                else {
                    await this.deleteTelegramWebhook(social.accessToken);
                }
            }
            social.status = status;
            await social.save();
        }
        catch (error) {
            this.logger.error(`Error while updating social integrations status : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async setTelegramWebhook(accessToken, botId) {
        var _a, _b;
        try {
            const decryptedAccessToken = await this.decrypt(accessToken);
            let url = `${this.configService.get('social.telegram.baseUrl')}${decryptedAccessToken}/setWebhook`;
            url = `${url}?url=${this.configService.get('social.telegram.webhookUrl')}/${botId}`;
            const response = await (0, rxjs_1.firstValueFrom)(this.httpService.get(url));
            return response.data;
        }
        catch (error) {
            const errorMessage = ((_b = (_a = error.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.description) || error.message;
            this.logger.error(`Error while setting telegram webhook : ${errorMessage}`);
            throw new common_1.HttpException(errorMessage, error.status || 500);
        }
    }
    async deleteTelegramWebhook(accessToken) {
        try {
            const decryptedAccessToken = await this.decrypt(accessToken);
            const url = `${this.configService.get('social.telegram.baseUrl')}${decryptedAccessToken}/deleteWebhook`;
            const response = await (0, rxjs_1.firstValueFrom)(this.httpService.get(url));
            return response.data;
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotToken(botId) {
        try {
            const bot = await this.socialModel.findOne({ botId });
            if (!bot)
                return null;
            return {
                accessToken: await this.decrypt(bot.accessToken),
                engageBotId: bot.engageBot.toHexString(),
            };
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new Error(error.message);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.socialModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.socialModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Total Social',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'social',
        };
    }
    async getPublishedCount(days = 30) {
        const total = await this.socialModel.countDocuments({
            status: social_status_enum_1.SocialStatusEnum.PUBLISHED,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.socialModel.countDocuments({
                status: social_status_enum_1.SocialStatusEnum.PUBLISHED,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Published Social',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'social',
        };
    }
    async getDraftCount(days = 30) {
        const total = await this.socialModel.countDocuments({
            status: social_status_enum_1.SocialStatusEnum.DRAFT,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.socialModel.countDocuments({
                status: social_status_enum_1.SocialStatusEnum.DRAFT,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Draft Social',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'social',
        };
    }
    async stats(days = 30) {
        try {
            const result = await Promise.all([
                this.getTotalCount(days),
                this.getPublishedCount(days),
                this.getDraftCount(days),
            ]);
            return result;
        }
        catch (error) {
            this.logger.error(`Error getting stats: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async dateWiseComparison(query) {
        try {
            const { param1, param2, startDate, endDate = new Date() } = query;
            const match = {};
            if (startDate && endDate) {
                match['createdAt'] = {
                    $gte: new Date(startDate),
                    $lte: new Date(endDate),
                };
            }
            if (!startDate)
                match['createdAt'] = {
                    $lte: new Date(endDate),
                };
            if (param1 && param2) {
                match['bot'] = {
                    $in: [new bson_1.ObjectId(param1), new bson_1.ObjectId(param2)],
                };
            }
            const conversation = mongoose_1.default.model('Conversation');
            const data = await conversation.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: '%Y-%m-%d',
                                date: '$createdAt',
                            },
                        },
                        param1: {
                            $push: {
                                $cond: {
                                    if: {
                                        $eq: ['$bot', new bson_1.ObjectId(param1)],
                                    },
                                    then: {
                                        platform: '$$ROOT.platform',
                                    },
                                    else: '$$REMOVE',
                                },
                            },
                        },
                        param2: {
                            $push: {
                                $cond: {
                                    if: {
                                        $eq: ['$bot', new bson_1.ObjectId(param2)],
                                    },
                                    then: {
                                        platform: '$$ROOT.platform',
                                    },
                                    else: '$$REMOVE',
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        _id: 0,
                        date: '$_id',
                        bot1: {
                            total: {
                                $size: '$param1',
                            },
                            facebook: {
                                $size: {
                                    $filter: {
                                        input: '$param1',
                                        as: 'item',
                                        cond: {
                                            $eq: ['$$item.platform', platform_enum_1.PlatformEnum.FACEBOOK],
                                        },
                                    },
                                },
                            },
                            whatsapp: {
                                $size: {
                                    $filter: {
                                        input: '$param1',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.WHATSAPP] },
                                    },
                                },
                            },
                            widget: {
                                $size: {
                                    $filter: {
                                        input: '$param1',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.WIDGET] },
                                    },
                                },
                            },
                            telegram: {
                                $size: {
                                    $filter: {
                                        input: '$param1',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.TELEGRAM] },
                                    },
                                },
                            },
                        },
                        bot2: {
                            total: {
                                $size: '$param2',
                            },
                            facebook: {
                                $size: {
                                    $filter: {
                                        input: '$param2',
                                        as: 'item',
                                        cond: {
                                            $eq: ['$$item.platform', platform_enum_1.PlatformEnum.FACEBOOK],
                                        },
                                    },
                                },
                            },
                            whatsapp: {
                                $size: {
                                    $filter: {
                                        input: '$param2',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.WHATSAPP] },
                                    },
                                },
                            },
                            widget: {
                                $size: {
                                    $filter: {
                                        input: '$param2',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.WIDGET] },
                                    },
                                },
                            },
                            telegram: {
                                $size: {
                                    $filter: {
                                        input: '$param2',
                                        as: 'item',
                                        cond: { $eq: ['$$item.platform', platform_enum_1.PlatformEnum.TELEGRAM] },
                                    },
                                },
                            },
                        },
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error getting stats: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
SocialService = SocialService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.SOCIAL_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        config_1.ConfigService,
        axios_1.HttpService])
], SocialService);
exports.SocialService = SocialService;
//# sourceMappingURL=social.service.js.map