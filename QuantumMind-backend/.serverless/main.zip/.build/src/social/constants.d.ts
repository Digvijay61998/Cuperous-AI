export declare const SOCIAL_PROVIDER = "SOCIAL_PROVIDER";
