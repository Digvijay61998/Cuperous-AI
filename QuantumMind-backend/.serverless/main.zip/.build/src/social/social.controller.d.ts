/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { CreateSocialDto } from './dto/create-social.dto';
import { SearchParamDto } from './dto/search-param.dto';
import { UpdateSocialDto } from './dto/update-social.dto';
import { UpdateStatusDto } from './dto/update-status.dto';
import { SocialService } from './social.service';
import { ConversationService } from 'src/conversation/conversation.service';
import { ReportParamsDto } from 'src/util/report-params.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
export declare class SocialController {
    private readonly socialService;
    private readonly conversationService;
    constructor(socialService: SocialService, conversationService: ConversationService);
    create(createSocialDto: CreateSocialDto): Promise<import("./entities/social.entity").Social & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query: SearchParamDto): Promise<{
        data: Omit<import("./entities/social.entity").Social & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>[];
        count: number;
        search: {
            platforms: string[];
            status: string[];
        };
    }>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getPlatformConversationsStats(): Promise<any>;
    getDatewisePlatfrom(query: ReportParamsDto): Promise<any[]>;
    getDaywisePlatform(query: ReportParamsDto): Promise<any[]>;
    getDateWiseComparison(query: ComparisonDto): Promise<any[]>;
    findOne(id: string): Promise<{
        accessToken: string;
        _id: unknown;
    }>;
    update(id: string, updateSocialDto: UpdateSocialDto): Promise<import("./entities/social.entity").Social & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateStatus(id: string, body: UpdateStatusDto): Promise<void>;
    remove(id: string): Promise<import("./entities/social.entity").Social & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
