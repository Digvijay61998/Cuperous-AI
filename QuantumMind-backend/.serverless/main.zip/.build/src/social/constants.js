"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOCIAL_PROVIDER = void 0;
exports.SOCIAL_PROVIDER = 'SOCIAL_PROVIDER';
//# sourceMappingURL=constants.js.map