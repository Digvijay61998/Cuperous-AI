export declare class SocialModule {
}
