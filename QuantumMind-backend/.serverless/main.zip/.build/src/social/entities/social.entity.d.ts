import mongoose from 'mongoose';
export type SocialDocument = Social & mongoose.Document;
export declare class Social {
    name: string;
    accessToken: string;
    platform: string;
    engageBot: any;
    botId: string;
    status: string;
}
export declare const SocialSchema: mongoose.Schema<Social, mongoose.Model<Social, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Social>;
