"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialSchema = exports.Social = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = __importDefault(require("mongoose"));
const social_platform_enum_1 = require("../enums/social-platform.enum");
const social_status_enum_1 = require("../enums/social-status.enum");
let Social = class Social {
};
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Social.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Social.prototype, "accessToken", void 0);
__decorate([
    (0, mongoose_1.Prop)({ enum: social_platform_enum_1.SocialPlatformEnum }),
    __metadata("design:type", String)
], Social.prototype, "platform", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Bot',
    }),
    __metadata("design:type", Object)
], Social.prototype, "engageBot", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Social.prototype, "botId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: social_status_enum_1.SocialStatusEnum,
        default: social_status_enum_1.SocialStatusEnum.DRAFT,
    }),
    __metadata("design:type", String)
], Social.prototype, "status", void 0);
Social = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret._id;
                delete ret.__v;
            },
        },
    })
], Social);
exports.Social = Social;
exports.SocialSchema = mongoose_1.SchemaFactory.createForClass(Social);
//# sourceMappingURL=social.entity.js.map