export declare class SearchParamDto {
    skip?: number;
    limit?: number;
    status?: string;
    platform?: string;
    bot?: string;
}
