export declare class CreateSocialDto {
    accessToken: string;
    botId: string;
    platform: string;
    name: string;
    engageBot: string;
}
