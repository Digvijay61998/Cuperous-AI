"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.socialProviders = void 0;
const constants_1 = require("./constants");
const social_entity_1 = require("./entities/social.entity");
const constants_2 = require("src/constants");
exports.socialProviders = [
    {
        provide: constants_1.SOCIAL_PROVIDER,
        useFactory: (connection) => connection.model(social_entity_1.Social.name, social_entity_1.SocialSchema),
        inject: [constants_2.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=social.provider.js.map