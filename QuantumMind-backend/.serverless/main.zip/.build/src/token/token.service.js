"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const constants_1 = require("src/constants");
const mongoose_1 = require("mongoose");
const util_1 = require("src/util");
const config_1 = require("@nestjs/config");
let TokenService = class TokenService {
    constructor(tokenModel, jwtService, configService) {
        this.tokenModel = tokenModel;
        this.jwtService = jwtService;
        this.configService = configService;
    }
    async sign(payload, signOptions) {
        return this.jwtService.sign(payload, signOptions);
    }
    verify(token) {
        return this.jwtService.verify(token);
    }
    async createRefreshToken(user) {
        const refreshTokenExpiresIn = this.configService.get('jwt.refreshExpiresInDays');
        const refreshToken = await this.tokenModel.create({
            token: (0, util_1.generateId)('refresh_token', 40),
            userId: user._id,
            email: user.email,
            role: user.role,
            expiresAt: new Date(Date.now() + refreshTokenExpiresIn * 24 * 60 * 60 * 1000),
        });
        return refreshToken.token;
    }
    async refreshAccessToken(refreshToken) {
        const token = await this.tokenModel.findOne({ token: refreshToken });
        if (token) {
            const signoptions = this.configService.get('jwt.signOptions');
            const accessToken = await this.sign({ _id: token.userId, email: token.email, role: token.role }, signoptions);
            return accessToken;
        }
        return null;
    }
};
TokenService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.TOKEN_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        jwt_1.JwtService,
        config_1.ConfigService])
], TokenService);
exports.TokenService = TokenService;
//# sourceMappingURL=token.service.js.map