import * as mongoose from 'mongoose';
export type TokenDocument = Token & mongoose.Document;
export declare class Token {
    token: string;
    userId: string;
    email: string;
    role: string;
    expiresAt: Date;
}
export declare const TokenSchema: mongoose.Schema<Token, mongoose.Model<Token, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Token>;
