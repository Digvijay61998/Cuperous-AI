import { JwtService } from '@nestjs/jwt';
import { Model } from 'mongoose';
import { TokenDocument } from './entities/token.entity';
import { JwtPayload } from 'src/auth/strategy/jwt.strategy';
import { ConfigService } from '@nestjs/config';
export declare class TokenService {
    private readonly tokenModel;
    private readonly jwtService;
    private readonly configService;
    constructor(tokenModel: Model<TokenDocument>, jwtService: JwtService, configService: ConfigService);
    sign(payload: any, signOptions?: any): Promise<string>;
    verify(token: string): any;
    createRefreshToken(user: JwtPayload): Promise<string>;
    refreshAccessToken(refreshToken: string): Promise<string>;
}
