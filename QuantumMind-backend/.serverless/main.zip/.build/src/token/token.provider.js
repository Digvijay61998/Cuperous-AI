"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tokenProviders = void 0;
const constants_1 = require("src/constants");
const constants_2 = require("src/constants");
const token_entity_1 = require("./entities/token.entity");
exports.tokenProviders = [
    {
        provide: constants_2.TOKEN_PROVIDER,
        useFactory: (connection) => connection.model(token_entity_1.Token.name, token_entity_1.TokenSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=token.provider.js.map