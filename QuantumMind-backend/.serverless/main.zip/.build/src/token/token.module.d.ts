export declare class TokenModule {
}
