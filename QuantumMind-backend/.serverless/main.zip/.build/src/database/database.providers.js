"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseProviders = void 0;
const mongoose = __importStar(require("mongoose"));
const constants_1 = require("src/constants");
const config_1 = require("@nestjs/config");
exports.databaseProviders = [
    {
        provide: constants_1.DATABASE_PROVIDER,
        inject: [config_1.ConfigService],
        useFactory: async (configService) => {
            const host = configService.get('database.host');
            const port = configService.get('database.port');
            const username = configService.get('database.username');
            const password = configService.get('database.password');
            const database = configService.get('database.database');
            const uri = `mongodb://${username}:${password}@${host}:${port}/${database}?authSource=admin`;
            console.log('uri', uri);
            mongoose.set('strictQuery', false);
            return await mongoose.connect(uri, {
                useUnifiedTopology: true,
            });
        },
    },
];
//# sourceMappingURL=database.providers.js.map