"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WEBHOOK_ACTIVITIES_PROVIDER = exports.WEBHOOK_PROVIDER = void 0;
exports.WEBHOOK_PROVIDER = 'WEBHOOK_PROVIDER';
exports.WEBHOOK_ACTIVITIES_PROVIDER = 'WEBHOOK_ACTIVITIES_PROVIDER';
//# sourceMappingURL=constant.js.map