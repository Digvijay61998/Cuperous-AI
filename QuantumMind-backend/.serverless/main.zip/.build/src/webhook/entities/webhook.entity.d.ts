import * as mongoose from 'mongoose';
import { WebHookActivities } from './webhook-activities';
export type WebhookDocument = Webhook & mongoose.Document;
export declare class Webhook {
    name: string;
    url: string;
    verifyToken: string;
    headersKey: string;
    headersValue: string;
    basicAuthUsername: string;
    basicAuthPassword: string;
    events: string;
    isActive: boolean;
    failedRequests: number;
    lastRequest: Date;
    succesRequests: number;
    activities: WebHookActivities[];
}
export declare const WebhookSchema: mongoose.Schema<Webhook, mongoose.Model<Webhook, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Webhook>;
