import { Bot } from 'src/bots/entities';
import * as mongoose from 'mongoose';
import { Webhook } from './webhook.entity';
export declare class WebHookActivities {
    status: string;
    bot: Bot;
    webhookId: Webhook;
}
export type WebHookActivitiesDocument = WebHookActivities & mongoose.Document;
export declare const WebHookActivitiesSchema: mongoose.Schema<WebHookActivities, mongoose.Model<WebHookActivities, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, WebHookActivities>;
