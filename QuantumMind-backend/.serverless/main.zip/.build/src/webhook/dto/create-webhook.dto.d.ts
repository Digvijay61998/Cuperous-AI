export declare class CreateWebhookDto {
    name: string;
    url: string;
    verifyToken: string;
    headersKey: string;
    headersValue: string;
    basicAuthUsername: string;
    basicAuthPassword: string;
    events: string;
    isActive: boolean;
}
