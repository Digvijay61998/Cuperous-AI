"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const configuration_1 = __importDefault(require("./config/configuration"));
const config_1 = require("@nestjs/config");
const database_module_1 = require("./database/database.module");
const token_module_1 = require("./token/token.module");
const auth_module_1 = require("./auth/auth.module");
const core_1 = require("@nestjs/core");
const jwt_guards_1 = require("./auth/guards/jwt.guards");
const agent_module_1 = require("./agent/agent.module");
const bots_module_1 = require("./bots/bots.module");
const visitor_module_1 = require("./visitor/visitor.module");
const tag_module_1 = require("./tag/tag.module");
const event_emitter_1 = require("@nestjs/event-emitter");
const segments_module_1 = require("./segments/segments.module");
const tickets_module_1 = require("./tickets/tickets.module");
const webhook_module_1 = require("./webhook/webhook.module");
const conversation_module_1 = require("./conversation/conversation.module");
const redis_module_1 = require("./redis/redis.module");
const socket_module_1 = require("./socket/socket.module");
const redis_propagate_module_1 = require("./redis-propagate/redis-propagate.module");
const engage_gateway_1 = require("./engage/engage.gateway");
const message_handler_module_1 = require("./message-handler/message-handler.module");
const widget_module_1 = require("./widget/widget.module");
const unanswered_module_1 = require("./unanswered/unanswered.module");
const upload_module_1 = require("./upload/upload.module");
const questions_module_1 = require("./questions/questions.module");
const feedback_module_1 = require("./feedback/feedback.module");
const advertisement_module_1 = require("./advertisement/advertisement.module");
const offer_module_1 = require("./offer/offer.module");
const engage_service_1 = require("./engage/engage.service");
const engage_module_1 = require("./engage/engage.module");
const facebook_module_1 = require("./facebook/facebook.module");
const telegram_module_1 = require("./telegram/telegram.module");
const chat_initializer_module_1 = require("./chat-initializer/chat-initializer.module");
const video_module_1 = require("./video/video.module");
const whatsapp_module_1 = require("./whatsapp/whatsapp.module");
const mails_module_1 = require("./mails/mails.module");
const social_module_1 = require("./social/social.module");
const scraper_module_1 = require("./scraper/scraper.module");
const bull_1 = require("@nestjs/bull");
let AppModule = class AppModule {
};
AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                load: [configuration_1.default],
                isGlobal: true,
            }),
            database_module_1.DatabaseModule,
            scraper_module_1.ScrapeModule,
            token_module_1.TokenModule,
            auth_module_1.AuthModule,
            agent_module_1.AgentModule,
            bots_module_1.BotsModule,
            visitor_module_1.VisitorModule,
            tag_module_1.TagModule,
            segments_module_1.SegmentsModule,
            tickets_module_1.TicketsModule,
            webhook_module_1.WebhookModule,
            conversation_module_1.ConversationModule,
            redis_module_1.RedisModule,
            socket_module_1.SocketModule,
            redis_propagate_module_1.RedisPropagateModule,
            message_handler_module_1.MessageHandlerModule,
            widget_module_1.WidgetModule,
            unanswered_module_1.UnansweredModule,
            upload_module_1.UploadModule,
            questions_module_1.QuestionsModule,
            feedback_module_1.FeedbackModule,
            advertisement_module_1.AdvertisementModule,
            offer_module_1.OfferModule,
            engage_module_1.EngageModule,
            event_emitter_1.EventEmitterModule.forRoot(),
            facebook_module_1.FacebookModule,
            telegram_module_1.TelegramModule,
            chat_initializer_module_1.ChatInitializerModule,
            video_module_1.VideoModule,
            whatsapp_module_1.WhatsappModule,
            mails_module_1.MailsModule,
            social_module_1.SocialModule,
            bull_1.BullModule.forRootAsync({
                useFactory: (configService) => ({
                    redis: {
                        host: configService.get("redis.host"),
                        port: configService.get("redis.port"),
                        password: configService.get("redis.password"),
                    },
                }),
                inject: [config_1.ConfigService],
            }),
        ],
        controllers: [app_controller_1.AppController],
        providers: [
            app_service_1.AppService,
            {
                provide: core_1.APP_GUARD,
                useClass: jwt_guards_1.JwtAuthGuard,
            },
            engage_gateway_1.EngageGateway,
            engage_service_1.EngageService,
        ],
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map