"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OfferStatusEnum = void 0;
var OfferStatusEnum;
(function (OfferStatusEnum) {
    OfferStatusEnum["PUBLISHED"] = "published";
    OfferStatusEnum["DRAFT"] = "draft";
})(OfferStatusEnum = exports.OfferStatusEnum || (exports.OfferStatusEnum = {}));
//# sourceMappingURL=offer-status.enum.js.map