export declare enum OfferStatusEnum {
    PUBLISHED = "published",
    DRAFT = "draft"
}
