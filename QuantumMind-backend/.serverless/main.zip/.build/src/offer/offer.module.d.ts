export declare class OfferModule {
}
