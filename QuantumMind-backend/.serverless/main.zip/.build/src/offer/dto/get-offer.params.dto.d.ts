export declare class offerQueryParams {
    offerId?: string;
    startDate?: string;
    endDate?: string;
}
