import { Cards } from '../entities/offer.entity';
import { OfferStatusEnum } from '../enums/offer-status.enum';
export declare class CreateOfferDto {
    title: string;
    assignedToBots: string[];
    cards: Cards[];
    status: OfferStatusEnum;
}
