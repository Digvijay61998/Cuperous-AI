export declare class incrementClicksDto {
    offerId: string;
    botId: any;
    tag: string;
}
