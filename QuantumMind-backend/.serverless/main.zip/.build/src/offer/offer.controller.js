"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OfferController = void 0;
const common_1 = require("@nestjs/common");
const offer_service_1 = require("./offer.service");
const create_offer_dto_1 = require("./dto/create-offer.dto");
const search_param_dto_1 = require("./dto/search-param.dto");
const update_offer_dto_1 = require("./dto/update-offer.dto");
const swagger_1 = require("@nestjs/swagger");
const get_offer_params_dto_1 = require("./dto/get-offer.params.dto");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const comparison_dto_1 = require("src/util/comparison.dto");
let OfferController = class OfferController {
    constructor(offerService) {
        this.offerService = offerService;
    }
    async create(createOfferDto) {
        return await this.offerService.create(createOfferDto);
    }
    async findAll(query) {
        return await this.offerService.findAll(query);
    }
    async getStats() {
        return await this.offerService.stats();
    }
    async findOne(id) {
        return await this.offerService.findOne(id);
    }
    async update(id, updateOfferDto) {
        return await this.offerService.update(id, updateOfferDto);
    }
    async remove(id) {
        return await this.offerService.remove(id);
    }
    async offerClickCount() {
        return this.offerService.findOfferClickCount();
    }
    async botClicksCountData(query) {
        return this.offerService.findBotClicksCount(query);
    }
    async tagsClicksCountData(query) {
        return this.offerService.findTagsClicksCount(query);
    }
    async offerDateWiseStats(query) {
        return this.offerService.getDayWisePerformance(query);
    }
    async offerDateSummaryStats(query) {
        return this.offerService.getDateWisePerformance(query);
    }
    async offerDateWiseCompare(query) {
        return this.offerService.dateWiseComparison(query);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_offer_dto_1.CreateOfferDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_offer_dto_1.UpdateOfferDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('report/count'),
    (0, public_decorator_1.Public)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "offerClickCount", null);
__decorate([
    (0, common_1.Get)('report/bots-total-clicks'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "botClicksCountData", null);
__decorate([
    (0, common_1.Get)('report/tags-total-clicks'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "tagsClicksCountData", null);
__decorate([
    (0, common_1.Get)('report/day-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_offer_params_dto_1.offerQueryParams]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "offerDateWiseStats", null);
__decorate([
    (0, common_1.Get)('report/date-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_offer_params_dto_1.offerQueryParams]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "offerDateSummaryStats", null);
__decorate([
    (0, common_1.Get)('report/date-wise-compare'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [comparison_dto_1.ComparisonDto]),
    __metadata("design:returntype", Promise)
], OfferController.prototype, "offerDateWiseCompare", null);
OfferController = __decorate([
    (0, common_1.Controller)('offer'),
    (0, swagger_1.ApiTags)('Offer'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [offer_service_1.OfferService])
], OfferController);
exports.OfferController = OfferController;
//# sourceMappingURL=offer.controller.js.map