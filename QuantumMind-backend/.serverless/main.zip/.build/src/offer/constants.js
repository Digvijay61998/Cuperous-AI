"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OFFER_PROVIDER = void 0;
exports.OFFER_PROVIDER = 'OFFER_PROVIDER';
//# sourceMappingURL=constants.js.map