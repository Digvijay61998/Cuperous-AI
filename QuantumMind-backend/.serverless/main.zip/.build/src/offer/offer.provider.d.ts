import { Provider } from '@nestjs/common';
export declare const offerProviders: Provider[];
