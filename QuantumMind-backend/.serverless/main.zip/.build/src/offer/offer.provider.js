"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.offerProviders = void 0;
const constants_1 = require("src/constants");
const constants_2 = require("./constants");
const offer_entity_1 = require("./entities/offer.entity");
exports.offerProviders = [
    {
        provide: constants_2.OFFER_PROVIDER,
        useFactory: (connection) => connection.model(offer_entity_1.Offer.name, offer_entity_1.OfferSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=offer.provider.js.map