export declare const OFFER_PROVIDER = "OFFER_PROVIDER";
