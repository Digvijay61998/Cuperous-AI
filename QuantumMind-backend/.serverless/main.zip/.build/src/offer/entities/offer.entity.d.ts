import * as mongoose from 'mongoose';
import { OfferStatusEnum } from '../enums/offer-status.enum';
interface Clicks {
    botId: {
        type: mongoose.Schema.Types.ObjectId;
        ref: 'Bot';
    };
    date: Date;
    tag: string;
}
export interface Cards {
    image: string;
    link: string;
    title: string;
    description: string;
    tag: string;
}
export declare class Offer {
    title: string;
    cards: Cards[];
    assignedToBots: string[];
    clicks: Clicks[];
    status: OfferStatusEnum;
}
export declare const OfferSchema: mongoose.Schema<Offer, mongoose.Model<Offer, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Offer>;
export type OfferDocument = Offer & mongoose.Document;
export {};
