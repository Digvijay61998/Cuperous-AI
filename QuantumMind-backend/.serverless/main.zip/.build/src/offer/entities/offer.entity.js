"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OfferSchema = exports.Offer = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const offer_status_enum_1 = require("../enums/offer-status.enum");
let Offer = class Offer {
};
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Offer.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Array)
], Offer.prototype, "cards", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Bot' }],
        ref: 'Bot',
    }),
    __metadata("design:type", Array)
], Offer.prototype, "assignedToBots", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                botId: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'Bot',
                },
                date: {
                    type: Date,
                    default: Date.now,
                },
                tag: String,
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Offer.prototype, "clicks", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: offer_status_enum_1.OfferStatusEnum,
        default: offer_status_enum_1.OfferStatusEnum.DRAFT,
    }),
    __metadata("design:type", String)
], Offer.prototype, "status", void 0);
Offer = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret.__v;
                delete ret._id;
                delete ret.clicks;
            },
        },
    })
], Offer);
exports.Offer = Offer;
exports.OfferSchema = mongoose_1.SchemaFactory.createForClass(Offer);
exports.OfferSchema.post('save', function (doc, next) {
    const offer = doc;
    if (offer.status === offer_status_enum_1.OfferStatusEnum.PUBLISHED) {
        offer.assignedToBots.forEach(async (botId) => {
            const bot = await mongoose.model('Bot').findById(botId);
            bot.offer = offer._id;
            await bot.save();
        });
    }
    next();
});
exports.OfferSchema.pre('findOneAndUpdate', async function (next) {
    const offer = this.getUpdate();
    const Bot = mongoose.model('Bot');
    const id = this.getQuery()._id.toString();
    if (offer.assignedToBots) {
        const newBots = offer.assignedToBots;
        const oldBots = await this.model
            .findById(this.getQuery())
            .exec()
            .then((doc) => doc.assignedToBots.map((bot) => bot.toString()));
        const botTounassign = oldBots.filter((bot) => !newBots.includes(bot));
        const Bot = mongoose.model('Bot');
        await Bot.updateMany({ _id: { $in: botTounassign } }, { $unset: { advertisement: '' } });
    }
    if (offer.status) {
        const bots = await this.model
            .findById(this.getQuery())
            .exec()
            .then((doc) => doc.assignedToBots.map((bot) => bot.toString()));
        if (offer.status === offer_status_enum_1.OfferStatusEnum.PUBLISHED) {
            await Bot.updateMany({ _id: { $in: bots } }, { $set: { offer: id, showOffer: true } });
        }
        if (offer.status === offer_status_enum_1.OfferStatusEnum.DRAFT) {
            await Bot.updateMany({ _id: { $in: bots } }, { $unset: { offer: '' }, showOffer: false });
        }
    }
    next();
});
exports.OfferSchema.pre('remove', async function (next) {
    const offer = this;
    const Bot = mongoose.model('Bot');
    await Bot.updateMany({ offer: offer._id }, { $unset: { offer: '' }, showOffer: false });
    next();
});
exports.OfferSchema.virtual('clicksCount').get(function () {
    var _a;
    return (_a = this.clicks) === null || _a === void 0 ? void 0 : _a.length;
});
//# sourceMappingURL=offer.entity.js.map