/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { CreateOfferDto } from './dto/create-offer.dto';
import { UpdateOfferDto } from './dto/update-offer.dto';
import { SearchParamDto } from './dto/search-param.dto';
import { OfferDocument } from './entities/offer.entity';
import { Model } from 'mongoose';
import { BotsService } from 'src/bots/bots.service';
import { incrementClicksDto } from './dto/increment-count.dto';
import { offerQueryParams } from './dto/get-offer.params.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
export declare class OfferService {
    private readonly offerModel;
    private readonly botsService;
    private readonly logger;
    constructor(offerModel: Model<OfferDocument>, botsService: BotsService);
    create(createOfferDto: CreateOfferDto): Promise<import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query?: SearchParamDto): Promise<{
        data: Omit<import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>[];
        count: number;
    }>;
    findOne(id: string): Promise<import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, updateOfferDto: UpdateOfferDto): Promise<import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string): Promise<import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    incrementClicks(data: incrementClicksDto): Promise<void>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getPublishedCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getDraftCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    findOfferClickCount(): Promise<any[]>;
    findBotClicksCount(query?: SearchParamDto): Promise<any[]>;
    findTagsClicksCount(query?: SearchParamDto): Promise<any[]>;
    getDateWisePerformance(params: offerQueryParams): Promise<any[]>;
    dateWiseComparison(query: ComparisonDto): Promise<any[]>;
    getDayWisePerformance(params: offerQueryParams): Promise<any[]>;
    findOfferDateVisitorsStats(query: offerQueryParams): Promise<(import("./entities/offer.entity").Offer & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    })[]>;
}
