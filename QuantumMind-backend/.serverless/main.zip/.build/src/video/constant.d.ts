export declare const VIDEO_PROVIDER = "VIDEO_MODEL";
