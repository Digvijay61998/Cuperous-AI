"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoProviders = void 0;
const constants_1 = require("src/constants");
const constant_1 = require("./constant");
const video_entity_1 = require("./entities/video.entity");
exports.VideoProviders = [
    {
        provide: constant_1.VIDEO_PROVIDER,
        useFactory: (connection) => connection.model(video_entity_1.Video.name, video_entity_1.VideoSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=video.provider.js.map