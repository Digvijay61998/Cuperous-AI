export declare const VideoStatusEnum: {
    readonly LIVE: "live";
    readonly DRAFT: "draft";
};
export declare const VideoStatusEnumList: string[];
