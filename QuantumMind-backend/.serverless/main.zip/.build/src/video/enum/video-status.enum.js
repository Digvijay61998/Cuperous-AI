"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoStatusEnumList = exports.VideoStatusEnum = void 0;
exports.VideoStatusEnum = {
    LIVE: 'live',
    DRAFT: 'draft',
};
exports.VideoStatusEnumList = Object.values(exports.VideoStatusEnum);
//# sourceMappingURL=video-status.enum.js.map