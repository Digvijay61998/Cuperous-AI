"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoCategoryEnumList = exports.VideoCategoryEnum = void 0;
exports.VideoCategoryEnum = {
    AGENT: 'agent',
    BOT: 'bot',
    VISITOR: 'visitor',
    CONVERSATION: 'conversation',
    SERVICE_REQUEST: 'service-request',
    TELEGRAM: 'telegram',
    FACEBOOK: 'facebook',
    WHATSAPP: 'whatsapp',
    WEBHOOK: 'webhook',
    SEGMENT: 'segment',
    TAG: 'tag',
    ADVERTISEMENT: 'advertisement',
    OFFERS: 'offers',
    QUESTION_BANK: 'question-bank',
};
exports.VideoCategoryEnumList = Object.values(exports.VideoCategoryEnum);
//# sourceMappingURL=video-category.enum.js.map