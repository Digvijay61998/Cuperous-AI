export declare const VideoCategoryEnum: {
    readonly AGENT: "agent";
    readonly BOT: "bot";
    readonly VISITOR: "visitor";
    readonly CONVERSATION: "conversation";
    readonly SERVICE_REQUEST: "service-request";
    readonly TELEGRAM: "telegram";
    readonly FACEBOOK: "facebook";
    readonly WHATSAPP: "whatsapp";
    readonly WEBHOOK: "webhook";
    readonly SEGMENT: "segment";
    readonly TAG: "tag";
    readonly ADVERTISEMENT: "advertisement";
    readonly OFFERS: "offers";
    readonly QUESTION_BANK: "question-bank";
};
export declare const VideoCategoryEnumList: string[];
