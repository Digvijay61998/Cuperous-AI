"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VIDEO_PROVIDER = void 0;
exports.VIDEO_PROVIDER = 'VIDEO_MODEL';
//# sourceMappingURL=constant.js.map