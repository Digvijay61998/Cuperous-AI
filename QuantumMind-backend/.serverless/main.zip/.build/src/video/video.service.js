"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var VideoService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const constant_1 = require("./constant");
const video_category_enum_1 = require("./enum/video-category.enum");
const video_status_enum_1 = require("./enum/video-status.enum");
let VideoService = VideoService_1 = class VideoService {
    constructor(videoModel) {
        this.videoModel = videoModel;
        this.logger = new common_1.Logger(VideoService_1.name);
    }
    async create(createVideoDto) {
        try {
            const video = await this.videoModel.create(Object.assign({}, createVideoDto));
            return video;
        }
        catch (error) {
            this.logger.error(`Error creating tag: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll(query) {
        try {
            const { skip, limit, status, category, text } = query;
            const queryObj = {};
            if (status) {
                queryObj['status'] = status;
            }
            if (category) {
                queryObj['category'] = category;
            }
            if (text) {
                queryObj['$text'] = { $search: text };
            }
            const video = this.videoModel
                .find(queryObj)
                .skip(skip)
                .sort({ createdAt: -1 });
            if (limit)
                video.limit(limit);
            const data = await video;
            const count = await this.videoModel.countDocuments(queryObj);
            const search = {
                categories: video_category_enum_1.VideoCategoryEnumList,
                status: video_status_enum_1.VideoStatusEnumList,
            };
            return { data, count, search };
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    getParams() {
        return {
            categories: video_category_enum_1.VideoCategoryEnumList,
            status: video_status_enum_1.VideoStatusEnumList,
        };
    }
    async incrementViewCount(videoId) {
        try {
            const video = await this.videoModel.findByIdAndUpdate(videoId, {
                $push: {
                    views: {
                        date: new Date(),
                    },
                },
            });
            if (!video) {
                throw new common_1.HttpException('Video not found', 404);
            }
            return video;
        }
        catch (error) {
            this.logger.error(`Error while getting video with id ${videoId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findOne(videoId) {
        try {
            const video = await this.videoModel.findById(videoId);
            return video;
        }
        catch (error) {
            this.logger.error(`Error while getting video with id ${videoId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async update(id, updateVideoDto) {
        try {
            const video = await this.videoModel.findByIdAndUpdate(id, updateVideoDto, { new: true });
            return video;
        }
        catch (error) {
            this.logger.error(`Error while updating Video with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async remove(id) {
        try {
            const video = await this.videoModel.findByIdAndDelete(id);
            return video;
        }
        catch (error) {
            this.logger.error(`Error while deleting webhook with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
VideoService = VideoService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.VIDEO_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model])
], VideoService);
exports.VideoService = VideoService;
//# sourceMappingURL=video.service.js.map