export declare class CreateVideoDto {
    title: string;
    url: string;
    category: string;
    status: string;
    description: string;
}
