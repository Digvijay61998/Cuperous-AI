export declare class SearchParamDto {
    skip?: number;
    limit?: number;
    status?: string;
    category?: string;
    text?: string;
}
