export declare class VideoModule {
}
