import * as mongoose from 'mongoose';
export type VideoDocument = Video & mongoose.Document;
export declare class Video {
    title: string;
    subtitle: string;
    url: string;
    category: string;
    description: string;
    status: string;
    views: [];
}
export declare const VideoSchema: mongoose.Schema<Video, mongoose.Model<Video, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Video>;
