import { FeedbackForEnum } from '../enums/feedback-for.enum';
export declare class CreateFeedbackDto {
    feedbackFor: FeedbackForEnum;
    rating: number;
    comment: string;
    visitor: string;
    agent?: string;
    bot: string;
    conversation: string;
}
