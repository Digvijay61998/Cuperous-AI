"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.feedbackProviders = void 0;
const constants_1 = require("./constants");
const feedback_entity_1 = require("./entities/feedback.entity");
const constants_2 = require("src/constants");
exports.feedbackProviders = [
    {
        provide: constants_1.FEEDBACK_PROVIDER,
        useFactory: (connection) => connection.model(feedback_entity_1.Feedback.name, feedback_entity_1.FeedbackSchema),
        inject: [constants_2.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=feedback.provider.js.map