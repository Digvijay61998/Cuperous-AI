"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var FeedbackService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedbackService = void 0;
const common_1 = require("@nestjs/common");
const constants_1 = require("./constants");
const mongoose_1 = require("mongoose");
const agent_service_1 = require("src/agent/agent.service");
const visitor_service_1 = require("src/visitor/visitor.service");
const conversation_service_1 = require("src/conversation/conversation.service");
const feedback_for_enum_1 = require("./enums/feedback-for.enum");
let FeedbackService = FeedbackService_1 = class FeedbackService {
    constructor(feedbackModel, agentService, visitorService, conversationService) {
        this.feedbackModel = feedbackModel;
        this.agentService = agentService;
        this.visitorService = visitorService;
        this.conversationService = conversationService;
        this.logger = new common_1.Logger(FeedbackService_1.name);
    }
    async create(createFeedbackDto) {
        try {
            const createdFeedback = new this.feedbackModel(createFeedbackDto);
            const savedFeedback = await createdFeedback.save();
            if (createFeedbackDto.feedbackFor === feedback_for_enum_1.FeedbackForEnum.AGENT)
                await this.agentService.updateRatingAndFeedback(createFeedbackDto.agent, createFeedbackDto.rating, savedFeedback._id);
            await this.visitorService.updateFeedback(createFeedbackDto.visitor, savedFeedback._id);
            await this.conversationService.updateConversationFeedback(createFeedbackDto.conversation, savedFeedback._id);
            return savedFeedback;
        }
        catch (error) {
            this.logger.error(`Error while creating feedback ${error}`);
        }
    }
};
FeedbackService = FeedbackService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.FEEDBACK_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        agent_service_1.AgentService,
        visitor_service_1.VisitorService,
        conversation_service_1.ConversationService])
], FeedbackService);
exports.FeedbackService = FeedbackService;
//# sourceMappingURL=feedback.service.js.map