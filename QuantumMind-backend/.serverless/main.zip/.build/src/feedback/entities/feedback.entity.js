"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedbackSchema = exports.Feedback = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = __importDefault(require("mongoose"));
const feedback_for_enum_1 = require("../enums/feedback-for.enum");
let Feedback = class Feedback {
};
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Number)
], Feedback.prototype, "rating", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Feedback.prototype, "comment", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Visitor',
    }),
    __metadata("design:type", String)
], Feedback.prototype, "visitor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Agent',
    }),
    __metadata("design:type", String)
], Feedback.prototype, "agent", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Bot',
    }),
    __metadata("design:type", String)
], Feedback.prototype, "bot", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
        enum: feedback_for_enum_1.FeedbackForEnum,
    }),
    __metadata("design:type", String)
], Feedback.prototype, "feedbackFor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Conversation',
    }),
    __metadata("design:type", String)
], Feedback.prototype, "conversation", void 0);
Feedback = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret._id;
                delete ret.__v;
            },
        },
    })
], Feedback);
exports.Feedback = Feedback;
exports.FeedbackSchema = mongoose_1.SchemaFactory.createForClass(Feedback);
//# sourceMappingURL=feedback.entity.js.map