import mongoose from 'mongoose';
import { FeedbackForEnum } from '../enums/feedback-for.enum';
export declare class Feedback {
    rating: number;
    comment: string;
    visitor: string;
    agent: string;
    bot: string;
    feedbackFor: FeedbackForEnum;
    conversation: string;
}
export declare const FeedbackSchema: mongoose.Schema<Feedback, mongoose.Model<Feedback, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Feedback>;
export type FeedbackDocument = Feedback & mongoose.Document;
