"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedbackForEnum = void 0;
var FeedbackForEnum;
(function (FeedbackForEnum) {
    FeedbackForEnum["AGENT"] = "agent";
    FeedbackForEnum["VISITOR"] = "visitor";
    FeedbackForEnum["BOT"] = "bot";
})(FeedbackForEnum = exports.FeedbackForEnum || (exports.FeedbackForEnum = {}));
//# sourceMappingURL=feedback-for.enum.js.map