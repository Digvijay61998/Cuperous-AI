export declare enum FeedbackForEnum {
    AGENT = "agent",
    VISITOR = "visitor",
    BOT = "bot"
}
