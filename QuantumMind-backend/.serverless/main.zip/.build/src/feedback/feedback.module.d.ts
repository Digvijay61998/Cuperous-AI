export declare class FeedbackModule {
}
