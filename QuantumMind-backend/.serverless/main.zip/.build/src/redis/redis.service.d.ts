import { RedisClient } from './redis.providers';
import { Observable } from 'rxjs';
export interface RedisSubscribeMessage {
    readonly message: string;
    readonly channel: string;
}
export declare class RedisService {
    private readonly redisSubscriberClient;
    private readonly redisPublisherClient;
    constructor(redisSubscriberClient: RedisClient, redisPublisherClient: RedisClient);
    fromEvent<T>(eventName: string): Observable<T>;
    publish(channel: string, value: unknown): Promise<number>;
}
