"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.redisProviders = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
const redis_constants_1 = require("./redis.constants");
const config_1 = require("@nestjs/config");
exports.redisProviders = [
    {
        provide: redis_constants_1.REDIS_PUBLISHER_CLIENT,
        useFactory: (configService) => {
            const redisConfig = configService.get('redis');
            return new ioredis_1.default(redisConfig);
        },
        inject: [config_1.ConfigService],
    },
    {
        provide: redis_constants_1.REDIS_SUBSCRIBER_CLIENT,
        useFactory: (configService) => {
            const redisConfig = configService.get('redis');
            return new ioredis_1.default(redisConfig);
        },
        inject: [config_1.ConfigService],
    },
];
//# sourceMappingURL=redis.providers.js.map