import { Model } from "mongoose";
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { CreateMultipleQuestionsDto, CreateSingleQuestionDto } from "./dto/create-question.dto";
import { SearchParamDto } from "./dto/search-param.dto";
import { UpdateQuestionStatusDto } from "./dto/update-question-status.dto";
import { UpdateQuestionDto } from "./dto/update-question.dto";
import { Question, QuestionDocument } from "./entities/question.entity";
import { HttpService } from "@nestjs/axios";
import { ConfigService } from "@nestjs/config";
export declare class QuestionsService {
    private readonly questionModel;
    private readonly httpService;
    private readonly configService;
    private readonly logger;
    constructor(questionModel: Model<QuestionDocument>, httpService: HttpService, configService: ConfigService);
    createSingleQuestion(createQuestionDto: CreateSingleQuestionDto, user: JwtPayload): Promise<QuestionDocument>;
    createMultipleQuestions(createMultipleQuestionsDto: CreateMultipleQuestionsDto, user: JwtPayload): Promise<any>;
    getAllQuestions(query?: SearchParamDto): Promise<{
        data: QuestionDocument[];
        count: number;
    }>;
    getQuestionById(id: string): Promise<QuestionDocument>;
    updateStatus(id: string, approvedBy: string, updateQuestionStatusDto: UpdateQuestionStatusDto): Promise<QuestionDocument>;
    search(question: string, language?: string): Promise<QuestionDocument[]>;
    updateQuestion(id: string, updateQuestionDto: UpdateQuestionDto, user: JwtPayload): Promise<Question>;
    deleteQuestion(id: string): Promise<QuestionDocument>;
    findAnswer(question: string, language?: string, tags?: string[]): Promise<string>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getApprovedCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getUnderReviewCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getIntent(question: string): Promise<any>;
}
