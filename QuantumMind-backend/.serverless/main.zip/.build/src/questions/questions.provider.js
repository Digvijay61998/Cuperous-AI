"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.questionProviders = void 0;
const constants_1 = require("src/constants");
const constants_2 = require("./constants");
const question_entity_1 = require("./entities/question.entity");
exports.questionProviders = [
    {
        provide: constants_2.QUESTION_PROVIDER,
        useFactory: (connection) => connection.model(question_entity_1.Question.name, question_entity_1.QuestionSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=questions.provider.js.map