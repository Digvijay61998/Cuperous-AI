import { Provider } from '@nestjs/common';
export declare const questionProviders: Provider[];
