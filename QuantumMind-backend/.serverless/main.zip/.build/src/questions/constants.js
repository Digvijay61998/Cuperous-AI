"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QUESTION_PROVIDER = void 0;
exports.QUESTION_PROVIDER = 'QUESTION_MODEL';
//# sourceMappingURL=constants.js.map