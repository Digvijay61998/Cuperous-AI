export declare class QuestionsModule {
}
