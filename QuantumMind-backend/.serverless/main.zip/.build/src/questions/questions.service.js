"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var QuestionsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const agent_role_enum_1 = require("src/agent/enums/agent-role.enum");
const get_subtitle_1 = require("src/util/get-subtitle");
const constants_1 = require("./constants");
const question_status_enum_1 = require("./enums/question-status.enum");
const axios_1 = require("@nestjs/axios");
const rxjs_1 = require("rxjs");
const config_1 = require("@nestjs/config");
let QuestionsService = QuestionsService_1 = class QuestionsService {
    constructor(questionModel, httpService, configService) {
        this.questionModel = questionModel;
        this.httpService = httpService;
        this.configService = configService;
        this.logger = new common_1.Logger(QuestionsService_1.name);
    }
    async createSingleQuestion(createQuestionDto, user) {
        try {
            let question = await this.questionModel.findOne({
                question: createQuestionDto.question,
            });
            const status = user.role === "admin"
                ? question_status_enum_1.QuestionStatusEnum.APPROVED
                : question_status_enum_1.QuestionStatusEnum.UNDER_REVIEW;
            if (question) {
                question.answers = [...question.answers, ...createQuestionDto.answers];
            }
            else {
                question = new this.questionModel(Object.assign(Object.assign({}, createQuestionDto), { addedBy: user._id, status }));
            }
            return await question.save();
        }
        catch (error) {
            this.logger.error(`Error creating question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async createMultipleQuestions(createMultipleQuestionsDto, user) {
        try {
            await Promise.all(createMultipleQuestionsDto.questions.map(async (question) => {
                this.createSingleQuestion(Object.assign(Object.assign({}, question), { tags: createMultipleQuestionsDto.tags, questionLanguage: createMultipleQuestionsDto.questionLanguage }), user);
            }));
            return { message: "Questions added successfully" };
        }
        catch (error) {
            this.logger.error(`Error creating multiple question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getAllQuestions(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, status, tags, language, question, } = query;
            const queryObject = {};
            if (status)
                queryObject["status"] = status;
            if (tags)
                queryObject["tags"] = { $in: tags };
            if (language)
                queryObject["questionLanguage.label"] = language;
            if (question)
                queryObject["$text"] = { $search: question };
            const questions = this.questionModel
                .find(queryObject)
                .sort({ createdAt: -1 })
                .populate("addedBy", "name")
                .populate("approvedBy", "name")
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                questions.limit(limitOfDocuments);
            }
            const data = await questions.exec();
            const count = await this.questionModel.countDocuments(queryObject);
            return { data, count };
        }
        catch (error) {
            this.logger.error(`Error getting all questions: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getQuestionById(id) {
        try {
            const question = await this.questionModel.findById(id);
            if (!question) {
                throw new common_1.HttpException("Question not found", 404);
            }
            return question;
        }
        catch (error) {
            this.logger.error(`Error getting question by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateStatus(id, approvedBy, updateQuestionStatusDto) {
        try {
            const status = updateQuestionStatusDto.status;
            const question = await this.questionModel.findById(id);
            if (!question) {
                throw new common_1.HttpException("Question not found", 404);
            }
            if (status === question_status_enum_1.QuestionStatusEnum.APPROVED) {
                question.status = status;
                question.approvedBy = approvedBy;
                if (question.addedBy === approvedBy) {
                    throw new common_1.HttpException("You cannot approve your own question", 400);
                }
            }
            else {
                question.status = status;
                question.approvedBy = null;
            }
            return await question.save();
        }
        catch (error) {
            this.logger.error(`Error approving question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async search(question, language = "en") {
        try {
            question = question.toLowerCase().trim();
            const query = {
                $text: { $search: question, $language: language },
            };
            const questions = await this.questionModel
                .find(query)
                .sort({ score: { $meta: "textScore" } })
                .select("question answers")
                .limit(10);
            if (questions.length === 0) {
                return [];
            }
            return questions;
        }
        catch (error) {
            this.logger.error(`Error searching question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateQuestion(id, updateQuestionDto, user) {
        try {
            const { _id: userId, role } = user;
            const question = await this.questionModel.findById(id);
            if (!question) {
                throw new common_1.HttpException("Question not found", 404);
            }
            let keywords = [];
            if (updateQuestionDto.question) {
                question.question = updateQuestionDto.question;
                keywords = [...keywords, ...updateQuestionDto.question.split(" ")];
            }
            if (updateQuestionDto.keywords) {
                keywords = [...keywords, ...updateQuestionDto.keywords];
                question.keywords = updateQuestionDto.keywords;
            }
            if (updateQuestionDto.answers) {
                question.answers = updateQuestionDto.answers;
            }
            if (updateQuestionDto.tags) {
                question.tags = updateQuestionDto.tags;
            }
            question.status =
                role === agent_role_enum_1.RoleEnum.ADMIN
                    ? question_status_enum_1.QuestionStatusEnum.APPROVED
                    : question_status_enum_1.QuestionStatusEnum.UNDER_REVIEW;
            question.approvedBy = userId;
            question.questionLanguage = updateQuestionDto.questionLanguage;
            keywords = keywords
                .map((keyword) => {
                return keyword.replace(/[^\w\s]/gi, "");
            })
                .filter((keyword) => {
                return keyword !== "";
            });
            question.search_keywords = [...new Set(keywords)];
            return await question.save();
        }
        catch (error) {
            this.logger.error(`Error updating question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async deleteQuestion(id) {
        try {
            const question = await this.questionModel.findById(id);
            if (!question) {
                throw new common_1.HttpException("Question not found", 404);
            }
            return await question.remove();
        }
        catch (error) {
            this.logger.error(`Error deleting question: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAnswer(question, language = "english", tags) {
        try {
            question = question.toLowerCase().trim();
            const query = {
                $text: { $search: question, $language: language },
                status: question_status_enum_1.QuestionStatusEnum.APPROVED,
            };
            if (tags) {
                query["tags"] = { $all: tags };
            }
            const questionFound = await this.questionModel
                .find(query, {
                score: { $meta: "textScore" },
            })
                .sort({ score: { $meta: "textScore" } })
                .limit(1)
                .select("answers")
                .exec();
            if (!questionFound || !questionFound.length) {
                return null;
            }
            await this.questionModel
                .updateOne({ _id: questionFound[0]._id }, { $inc: { usedcount: 1 } })
                .exec();
            const randomAnswer = questionFound[0].answers[Math.floor(Math.random() * questionFound[0].answers.length)];
            return randomAnswer;
        }
        catch (error) {
            this.logger.error(`Error finding answer: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.questionModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.questionModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Questions",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "question",
        };
    }
    async getApprovedCount(days = 30) {
        const total = await this.questionModel.countDocuments({
            status: question_status_enum_1.QuestionStatusEnum.APPROVED,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.questionModel.countDocuments({
                status: question_status_enum_1.QuestionStatusEnum.APPROVED,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Approved Questions",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "question",
        };
    }
    async getUnderReviewCount(days = 30) {
        const total = await this.questionModel.countDocuments({
            status: question_status_enum_1.QuestionStatusEnum.UNDER_REVIEW,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.questionModel.countDocuments({
                status: question_status_enum_1.QuestionStatusEnum.UNDER_REVIEW,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Under Review Questions",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "question",
        };
    }
    async stats(days = 30) {
        try {
            const result = await Promise.all([
                this.getTotalCount(days),
                this.getApprovedCount(days),
                this.getUnderReviewCount(days),
            ]);
            return result;
        }
        catch (error) {
            this.logger.error(`Error getting stats: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getIntent(question) {
        try {
            const nlpUrl = `${this.configService.get("nlp.url")}/nlp/v1/findIntent`;
            const result = await (0, rxjs_1.firstValueFrom)(this.httpService.get(nlpUrl, {
                params: {
                    data: question,
                },
            }));
            if (result.data.found)
                return result.data.Intent;
            else
                return "";
        }
        catch (error) {
            this.logger.error(`Error getting intent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
QuestionsService = QuestionsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.QUESTION_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        axios_1.HttpService,
        config_1.ConfigService])
], QuestionsService);
exports.QuestionsService = QuestionsService;
//# sourceMappingURL=questions.service.js.map