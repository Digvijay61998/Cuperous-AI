"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateMultipleQuestionsDto = exports.CreateSingleQuestionDto = void 0;
const class_validator_1 = require("class-validator");
class CreateQuestionDto {
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateQuestionDto.prototype, "questionLanguage", void 0);
__decorate([
    (0, class_validator_1.IsString)({
        message: "Question must be a string",
    }),
    __metadata("design:type", String)
], CreateQuestionDto.prototype, "question", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsNotEmpty)({
        message: "Answers must be an array of strings",
    }),
    __metadata("design:type", Array)
], CreateQuestionDto.prototype, "answers", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], CreateQuestionDto.prototype, "keywords", void 0);
class CreateSingleQuestionDto extends CreateQuestionDto {
}
__decorate([
    (0, class_validator_1.IsArray)({
        message: "Tags must be an array",
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], CreateSingleQuestionDto.prototype, "tags", void 0);
exports.CreateSingleQuestionDto = CreateSingleQuestionDto;
class CreateMultipleQuestionsDto {
}
__decorate([
    (0, class_validator_1.IsArray)({
        message: "Questions must be an array",
    }),
    __metadata("design:type", Array)
], CreateMultipleQuestionsDto.prototype, "questions", void 0);
__decorate([
    (0, class_validator_1.IsArray)({
        message: "Tags must be an array",
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], CreateMultipleQuestionsDto.prototype, "tags", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateMultipleQuestionsDto.prototype, "questionLanguage", void 0);
exports.CreateMultipleQuestionsDto = CreateMultipleQuestionsDto;
//# sourceMappingURL=create-question.dto.js.map