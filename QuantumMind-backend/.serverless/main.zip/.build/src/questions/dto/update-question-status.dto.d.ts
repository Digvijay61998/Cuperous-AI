import { QuestionStatusEnum } from '../enums/question-status.enum';
export declare class UpdateQuestionStatusDto {
    status: QuestionStatusEnum;
}
