export declare class FindAnswerDto {
    readonly question: string;
    readonly tags: string[];
    readonly language: string;
}
