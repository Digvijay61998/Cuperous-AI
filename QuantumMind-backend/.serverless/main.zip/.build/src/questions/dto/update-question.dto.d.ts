import { CreateSingleQuestionDto } from './create-question.dto';
declare const UpdateQuestionDto_base: import("@nestjs/common").Type<Partial<CreateSingleQuestionDto>>;
export declare class UpdateQuestionDto extends UpdateQuestionDto_base {
}
export {};
