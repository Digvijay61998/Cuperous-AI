export interface QuestionLanguage {
    label: string;
    value: string;
}
declare class CreateQuestionDto {
    questionLanguage: QuestionLanguage;
    question: string;
    answers: string[];
    keywords: string[];
}
export declare class CreateSingleQuestionDto extends CreateQuestionDto {
    tags: string[];
}
export declare class CreateMultipleQuestionsDto {
    questions: CreateQuestionDto[];
    tags: string[];
    questionLanguage: QuestionLanguage;
}
export {};
