import * as mongoose from "mongoose";
import { QuestionLanguage } from "../dto/create-question.dto";
export declare class Question extends mongoose.Document {
    language: string;
    question: string;
    answers: string[];
    keywords: string[];
    tags: string[];
    status: string;
    addedBy: string;
    approvedBy: string;
    usedcount: number;
    search_keywords: string[];
    private: boolean;
    intent: string;
    questionLanguage: QuestionLanguage;
}
export declare const QuestionSchema: mongoose.Schema<Question, mongoose.Model<Question, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Question>;
export type QuestionDocument = Question & mongoose.Document;
