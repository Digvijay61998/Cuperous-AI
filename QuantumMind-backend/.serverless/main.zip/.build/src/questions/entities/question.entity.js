"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionSchema = exports.Question = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const question_status_enum_1 = require("../enums/question-status.enum");
const mongoose = __importStar(require("mongoose"));
let Question = class Question extends mongoose.Document {
};
__decorate([
    (0, mongoose_1.Prop)({
        default: "en",
    }),
    __metadata("design:type", String)
], Question.prototype, "language", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
        lowercase: true,
    }),
    __metadata("design:type", String)
], Question.prototype, "question", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
    }),
    __metadata("design:type", Array)
], Question.prototype, "answers", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [],
        lowercase: true,
    }),
    __metadata("design:type", Array)
], Question.prototype, "keywords", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Array)
], Question.prototype, "tags", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: question_status_enum_1.QuestionStatusEnum,
        default: question_status_enum_1.QuestionStatusEnum.UNDER_REVIEW,
    }),
    __metadata("design:type", String)
], Question.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: "Agent",
    }),
    __metadata("design:type", String)
], Question.prototype, "addedBy", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: "Agent",
    }),
    __metadata("design:type", String)
], Question.prototype, "approvedBy", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Question.prototype, "usedcount", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [],
    }),
    __metadata("design:type", Array)
], Question.prototype, "search_keywords", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Question.prototype, "private", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Question.prototype, "intent", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: {
            label: "English",
            value: "en",
        },
        type: mongoose.Schema.Types.Mixed,
    }),
    __metadata("design:type", Object)
], Question.prototype, "questionLanguage", void 0);
Question = __decorate([
    (0, mongoose_1.Schema)({
        virtuals: true,
        timestamps: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                delete ret.__v;
                delete ret.questionLanguage;
                delete ret.language;
                delete ret.search_keywords;
            },
        },
    })
], Question);
exports.Question = Question;
exports.QuestionSchema = mongoose_1.SchemaFactory.createForClass(Question);
exports.QuestionSchema.index({
    search_keywords: "text",
    question: "text",
    status: 1,
}, {
    weights: {
        question: 10,
        search_keywords: 5,
    },
    default_language: "english",
});
exports.QuestionSchema.pre("save", function (next) {
    let keywords = [...this.keywords, ...this.question.split(" ")];
    keywords = keywords
        .map((keyword) => {
        return keyword.replace(/[^\w\s]/gi, "");
    })
        .filter((keyword) => {
        return keyword !== "";
    });
    this.search_keywords = [...new Set(keywords)];
    this.language = "none";
    next();
});
exports.QuestionSchema.virtual("lang").get(function () {
    var _a;
    return ((_a = this.questionLanguage) === null || _a === void 0 ? void 0 : _a.label) || "";
});
//# sourceMappingURL=question.entity.js.map