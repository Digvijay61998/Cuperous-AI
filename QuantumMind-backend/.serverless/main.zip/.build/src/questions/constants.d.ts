export declare const QUESTION_PROVIDER = "QUESTION_MODEL";
