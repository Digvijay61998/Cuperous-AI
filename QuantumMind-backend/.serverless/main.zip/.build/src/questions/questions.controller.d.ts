import { QuestionsService } from './questions.service';
import { QuestionDocument } from './entities/question.entity';
import { CreateSingleQuestionDto, CreateMultipleQuestionsDto } from './dto/create-question.dto';
import { JwtPayload } from 'src/auth/strategy/jwt.strategy';
import { SearchParamDto } from './dto/search-param.dto';
import { UpdateQuestionDto } from './dto/update-question.dto';
import { FindAnswerDto } from './dto/find-answer.dto';
import { UpdateQuestionStatusDto } from './dto/update-question-status.dto';
export declare class QuestionsController {
    private readonly questionsService;
    constructor(questionsService: QuestionsService);
    createSingleQuestion(createQuestionDto: CreateSingleQuestionDto, user: JwtPayload): Promise<QuestionDocument>;
    createMultipleQuestions(createMultipleQuestionsDto: CreateMultipleQuestionsDto, user: JwtPayload): Promise<QuestionDocument[]>;
    searchQuestions({ question, language }: FindAnswerDto): Promise<QuestionDocument[]>;
    getAllQuestions(query: SearchParamDto): Promise<{
        data: QuestionDocument[];
        count: number;
    }>;
    getQuestionById(id: string): Promise<QuestionDocument>;
    updateQuestion(id: string, updateQuestionDto: UpdateQuestionDto, user: JwtPayload): Promise<QuestionDocument>;
    deleteQuestion(id: string): Promise<QuestionDocument>;
    approveQuestion(id: string, user: JwtPayload, updateStatus: UpdateQuestionStatusDto): Promise<QuestionDocument>;
    findAnswer(findAnswerDto: FindAnswerDto): Promise<string>;
    getReportStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
}
