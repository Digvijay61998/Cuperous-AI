export declare enum QuestionStatusEnum {
    APPROVED = "approved",
    UNDER_REVIEW = "under_review"
}
