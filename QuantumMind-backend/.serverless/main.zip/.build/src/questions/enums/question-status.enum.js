"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionStatusEnum = void 0;
var QuestionStatusEnum;
(function (QuestionStatusEnum) {
    QuestionStatusEnum["APPROVED"] = "approved";
    QuestionStatusEnum["UNDER_REVIEW"] = "under_review";
})(QuestionStatusEnum = exports.QuestionStatusEnum || (exports.QuestionStatusEnum = {}));
//# sourceMappingURL=question-status.enum.js.map