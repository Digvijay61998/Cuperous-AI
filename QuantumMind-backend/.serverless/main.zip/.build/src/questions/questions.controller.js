"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionsController = void 0;
const common_1 = require("@nestjs/common");
const questions_service_1 = require("./questions.service");
const create_question_dto_1 = require("./dto/create-question.dto");
const util_1 = require("src/util");
const search_param_dto_1 = require("./dto/search-param.dto");
const update_question_dto_1 = require("./dto/update-question.dto");
const swagger_1 = require("@nestjs/swagger");
const find_answer_dto_1 = require("./dto/find-answer.dto");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const update_question_status_dto_1 = require("./dto/update-question-status.dto");
let QuestionsController = class QuestionsController {
    constructor(questionsService) {
        this.questionsService = questionsService;
    }
    async createSingleQuestion(createQuestionDto, user) {
        return await this.questionsService.createSingleQuestion(createQuestionDto, user);
    }
    async createMultipleQuestions(createMultipleQuestionsDto, user) {
        return await this.questionsService.createMultipleQuestions(createMultipleQuestionsDto, user);
    }
    async searchQuestions({ question, language }) {
        return await this.questionsService.search(question, language);
    }
    async getAllQuestions(query) {
        return await this.questionsService.getAllQuestions(query);
    }
    async getQuestionById(id) {
        return await this.questionsService.getQuestionById(id);
    }
    async updateQuestion(id, updateQuestionDto, user) {
        return await this.questionsService.updateQuestion(id, updateQuestionDto, user);
    }
    async deleteQuestion(id) {
        return await this.questionsService.deleteQuestion(id);
    }
    async approveQuestion(id, user, updateStatus) {
        return await this.questionsService.updateStatus(id, user._id, updateStatus);
    }
    async findAnswer(findAnswerDto) {
        return await this.questionsService.findAnswer(findAnswerDto.question, findAnswerDto.language, findAnswerDto.tags);
    }
    async getReportStats() {
        return await this.questionsService.stats();
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_question_dto_1.CreateSingleQuestionDto, Object]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "createSingleQuestion", null);
__decorate([
    (0, common_1.Post)('multiple'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_question_dto_1.CreateMultipleQuestionsDto, Object]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "createMultipleQuestions", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('search'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [find_answer_dto_1.FindAnswerDto]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "searchQuestions", null);
__decorate([
    (0, common_1.Get)(),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "getAllQuestions", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "getQuestionById", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_question_dto_1.UpdateQuestionDto, Object]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "updateQuestion", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "deleteQuestion", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, util_1.CurrentUser)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, update_question_status_dto_1.UpdateQuestionStatusDto]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "approveQuestion", null);
__decorate([
    (0, common_1.Post)('find-answer'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [find_answer_dto_1.FindAnswerDto]),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "findAnswer", null);
__decorate([
    (0, common_1.Get)('report/stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], QuestionsController.prototype, "getReportStats", null);
QuestionsController = __decorate([
    (0, common_1.Controller)('questions'),
    (0, swagger_1.ApiTags)('questions'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [questions_service_1.QuestionsService])
], QuestionsController);
exports.QuestionsController = QuestionsController;
//# sourceMappingURL=questions.controller.js.map