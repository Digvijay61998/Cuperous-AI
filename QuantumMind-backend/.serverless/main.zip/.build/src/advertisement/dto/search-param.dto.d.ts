export declare class SearchParamDto {
    skip?: number;
    limit?: number;
    status?: string;
    bot?: string;
}
