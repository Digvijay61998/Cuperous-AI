import { AdvertisementStatus } from '../enums/advertisement-status.enum';
import { CreateAdvertisementDto } from './create-advertisement.dto';
declare const UpdateAdvertisementDto_base: import("@nestjs/common").Type<Partial<CreateAdvertisementDto>>;
export declare class UpdateAdvertisementDto extends UpdateAdvertisementDto_base {
    unassignedToBots: string[];
    status: AdvertisementStatus;
}
export {};
