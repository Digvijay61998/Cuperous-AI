import { Posters } from '../entities/advertisement.entity';
export declare class CreateAdvertisementDto {
    title: string;
    assignedToBots: string[];
    posters: Posters[];
}
