export declare class incrementClicksDto {
    advertisementId: string;
    botId: any;
    tag: string;
}
