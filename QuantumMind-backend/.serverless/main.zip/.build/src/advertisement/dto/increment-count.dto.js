"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.incrementClicksDto = void 0;
class incrementClicksDto {
}
exports.incrementClicksDto = incrementClicksDto;
//# sourceMappingURL=increment-count.dto.js.map