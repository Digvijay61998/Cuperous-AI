export declare class AdvertisementQueryParams {
    advertisementId?: string;
    compareAdvertisementId?: string;
    startDate?: string;
    endDate?: string;
}
