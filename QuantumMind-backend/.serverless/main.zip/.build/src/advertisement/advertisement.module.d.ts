export declare class AdvertisementModule {
}
