"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdvertisementController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const advertisement_service_1 = require("./advertisement.service");
const create_advertisement_dto_1 = require("./dto/create-advertisement.dto");
const search_param_dto_1 = require("./dto/search-param.dto");
const get_advertisement_params_dto_1 = require("./dto/get-advertisement.params.dto");
const comparison_dto_1 = require("src/util/comparison.dto");
const update_advertisement_dto_1 = require("./dto/update-advertisement.dto");
let AdvertisementController = class AdvertisementController {
    constructor(advertisementService) {
        this.advertisementService = advertisementService;
    }
    async create(createAdvertisementDto) {
        return await this.advertisementService.create(createAdvertisementDto);
    }
    async findAll(query) {
        return await this.advertisementService.findAll(query);
    }
    async getStats() {
        return await this.advertisementService.stats();
    }
    async advertisementsClickCount() {
        return this.advertisementService.findAdvertisementsClickCount();
    }
    async botClicksCountData(query) {
        return this.advertisementService.findBotClicksCount(query);
    }
    async tagsClicksCountData(query) {
        return this.advertisementService.findTagsClicksCount(query);
    }
    async advertisementsSummaryStats(query) {
        return this.advertisementService.getDateWisePerformance(query);
    }
    async advertisementsDateWiseStats(query) {
        return this.advertisementService.getDayWisePerformance(query);
    }
    async advertisementsDateWiseCompare(query) {
        return this.advertisementService.dateWiseComparison(query);
    }
    async findOne(id) {
        return await this.advertisementService.findOne(id);
    }
    async update(id, updateAdvertisementDto) {
        return await this.advertisementService.update(id, updateAdvertisementDto);
    }
    async remove(id) {
        return await this.advertisementService.remove(id);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_advertisement_dto_1.CreateAdvertisementDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "getStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/count'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "advertisementsClickCount", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/bots-total-clicks'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "botClicksCountData", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/tags-total-clicks'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "tagsClicksCountData", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_advertisement_params_dto_1.AdvertisementQueryParams]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "advertisementsSummaryStats", null);
__decorate([
    (0, common_1.Get)('report/day-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_advertisement_params_dto_1.AdvertisementQueryParams]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "advertisementsDateWiseStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-compare'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [comparison_dto_1.ComparisonDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "advertisementsDateWiseCompare", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_advertisement_dto_1.UpdateAdvertisementDto]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdvertisementController.prototype, "remove", null);
AdvertisementController = __decorate([
    (0, common_1.Controller)('advertisement'),
    (0, swagger_1.ApiTags)('Advertisement'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [advertisement_service_1.AdvertisementService])
], AdvertisementController);
exports.AdvertisementController = AdvertisementController;
//# sourceMappingURL=advertisement.controller.js.map