import mongoose, { Document } from 'mongoose';
import { AdvertisementStatus } from '../enums/advertisement-status.enum';
interface Clicks {
    botId: {
        type: mongoose.Schema.Types.ObjectId;
        ref: 'Bot';
    };
    date: Date;
    tag: string;
}
export interface Posters {
    image: string;
    link: string;
}
export declare class Advertisement {
    title: string;
    posters: Posters[];
    assignedToBots: string[];
    clicks: Clicks[];
    status: AdvertisementStatus;
}
export declare const AdvertisementSchema: mongoose.Schema<Advertisement, mongoose.Model<Advertisement, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Advertisement>;
export type AdvertisementDocument = Advertisement & Document;
export {};
