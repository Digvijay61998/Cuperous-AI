"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdvertisementSchema = exports.Advertisement = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = __importDefault(require("mongoose"));
const advertisement_status_enum_1 = require("../enums/advertisement-status.enum");
let Advertisement = class Advertisement {
};
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Advertisement.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Array)
], Advertisement.prototype, "posters", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose_2.default.Schema.Types.ObjectId, ref: 'Bot' }],
        ref: 'Bot',
    }),
    __metadata("design:type", Array)
], Advertisement.prototype, "assignedToBots", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                botId: {
                    type: mongoose_2.default.Schema.Types.ObjectId,
                    ref: 'Bot',
                },
                date: {
                    type: Date,
                    default: Date.now,
                },
                tag: String,
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Advertisement.prototype, "clicks", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: advertisement_status_enum_1.AdvertisementStatus.DRAFT,
        enum: advertisement_status_enum_1.AdvertisementStatus,
    }),
    __metadata("design:type", String)
], Advertisement.prototype, "status", void 0);
Advertisement = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret.__v;
                delete ret._id;
                delete ret.clicks;
            },
        },
    })
], Advertisement);
exports.Advertisement = Advertisement;
exports.AdvertisementSchema = mongoose_1.SchemaFactory.createForClass(Advertisement);
exports.AdvertisementSchema.virtual('clicksCount').get(function () {
    var _a;
    return (_a = this.clicks) === null || _a === void 0 ? void 0 : _a.length;
});
exports.AdvertisementSchema.pre('remove', async function (next) {
    const advertisement = this;
    const Bot = mongoose_2.default.model('Bot');
    await Bot.updateMany({ advertisement: advertisement._id }, { $unset: { advertisement: '' } });
    next();
});
exports.AdvertisementSchema.pre('save', async function (next) {
    const advertisement = this;
    if (advertisement.status === advertisement_status_enum_1.AdvertisementStatus.PUBLISHED) {
        const Bot = mongoose_2.default.model('Bot');
        await Bot.updateMany({ advertisement: advertisement._id }, { $set: { advertisement: advertisement._id } });
    }
    next();
});
exports.AdvertisementSchema.pre('findOneAndUpdate', async function (next) {
    const advertisement = this.getUpdate();
    const Bot = mongoose_2.default.model('Bot');
    const id = this.getQuery()._id.toString();
    if (advertisement.assignedToBots) {
        const newBots = advertisement.assignedToBots;
        const oldBots = await this.model
            .findById(this.getQuery())
            .exec()
            .then((doc) => doc.assignedToBots.map((bot) => bot.toString()));
        const botTounassign = oldBots.filter((bot) => !newBots.includes(bot));
        const Bot = mongoose_2.default.model('Bot');
        await Bot.updateMany({ _id: { $in: botTounassign } }, { $unset: { advertisement: '' } });
    }
    if (advertisement.status) {
        const bots = await this.model
            .findById(this.getQuery())
            .exec()
            .then((doc) => doc.assignedToBots.map((bot) => bot.toString()));
        if (advertisement.status === advertisement_status_enum_1.AdvertisementStatus.PUBLISHED) {
            await Bot.updateMany({ _id: { $in: bots } }, { $set: { advertisement: id, showAdvertisement: true } });
        }
        if (advertisement.status === advertisement_status_enum_1.AdvertisementStatus.DRAFT) {
            await Bot.updateMany({ _id: { $in: bots } }, { $unset: { advertisement: '' }, showAdvertisement: false });
        }
    }
    next();
});
//# sourceMappingURL=advertisement.entity.js.map