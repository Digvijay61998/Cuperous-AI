import { Provider } from '@nestjs/common';
export declare const advertisementProviders: Provider[];
