"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.advertisementProviders = void 0;
const constants_1 = require("src/constants");
const constatnts_1 = require("./constatnts");
const advertisement_entity_1 = require("./entities/advertisement.entity");
exports.advertisementProviders = [
    {
        provide: constatnts_1.ADVERTISEMENT_PROVIDER,
        useFactory: (connection) => connection.model(advertisement_entity_1.Advertisement.name, advertisement_entity_1.AdvertisementSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=advertisement.provider.js.map