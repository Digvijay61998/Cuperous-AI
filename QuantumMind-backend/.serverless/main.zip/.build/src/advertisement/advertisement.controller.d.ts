/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { AdvertisementService } from './advertisement.service';
import { CreateAdvertisementDto } from './dto/create-advertisement.dto';
import { SearchParamDto } from './dto/search-param.dto';
import { AdvertisementQueryParams } from './dto/get-advertisement.params.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
import { UpdateAdvertisementDto } from './dto/update-advertisement.dto';
export declare class AdvertisementController {
    private readonly advertisementService;
    constructor(advertisementService: AdvertisementService);
    create(createAdvertisementDto: CreateAdvertisementDto): Promise<import("./entities/advertisement.entity").Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query: SearchParamDto): Promise<{
        data: Omit<import("./entities/advertisement.entity").Advertisement & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>[];
        count: number;
    }>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    advertisementsClickCount(): Promise<any[]>;
    botClicksCountData(query: SearchParamDto): Promise<any[]>;
    tagsClicksCountData(query: SearchParamDto): Promise<any[]>;
    advertisementsSummaryStats(query: AdvertisementQueryParams): Promise<any[]>;
    advertisementsDateWiseStats(query: AdvertisementQueryParams): Promise<any[]>;
    advertisementsDateWiseCompare(query: ComparisonDto): Promise<any[]>;
    findOne(id: string): Promise<import("./entities/advertisement.entity").Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, updateAdvertisementDto: UpdateAdvertisementDto): Promise<import("./entities/advertisement.entity").Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string): Promise<import("./entities/advertisement.entity").Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
