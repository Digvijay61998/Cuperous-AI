/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { CreateAdvertisementDto } from './dto/create-advertisement.dto';
import { SearchParamDto } from './dto/search-param.dto';
import { UpdateAdvertisementDto } from './dto/update-advertisement.dto';
import { Model } from 'mongoose';
import { BotsService } from 'src/bots/bots.service';
import { Advertisement, AdvertisementDocument } from './entities/advertisement.entity';
import { incrementClicksDto } from './dto/increment-count.dto';
import { AdvertisementQueryParams } from './dto/get-advertisement.params.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
export declare class AdvertisementService {
    private readonly advertisementModel;
    private readonly botsService;
    private logger;
    constructor(advertisementModel: Model<AdvertisementDocument>, botsService: BotsService);
    create(createAdvertisementDto: CreateAdvertisementDto): Promise<Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query?: SearchParamDto): Promise<{
        data: Omit<Advertisement & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>[];
        count: number;
    }>;
    findOne(id: string): Promise<Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, updateAdvertisementDto: UpdateAdvertisementDto): Promise<Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string): Promise<Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    incrementClicks(data: incrementClicksDto): Promise<void>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getPublishedCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getDraftCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    findAdvertisementsClickCount(): Promise<any[]>;
    findAdvertisementsVisitorsStats(query: AdvertisementQueryParams): Promise<(Advertisement & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    })[]>;
    getDateWisePerformance(params: AdvertisementQueryParams): Promise<any[]>;
    getDayWisePerformance(params: AdvertisementQueryParams): Promise<any[]>;
    findBotClicksCount(query?: SearchParamDto): Promise<any[]>;
    findTagsClicksCount(query?: SearchParamDto): Promise<any[]>;
    dateWiseComparison(query: ComparisonDto): Promise<any[]>;
}
