"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdvertisementStatus = void 0;
var AdvertisementStatus;
(function (AdvertisementStatus) {
    AdvertisementStatus["PUBLISHED"] = "published";
    AdvertisementStatus["DRAFT"] = "draft";
})(AdvertisementStatus = exports.AdvertisementStatus || (exports.AdvertisementStatus = {}));
//# sourceMappingURL=advertisement-status.enum.js.map