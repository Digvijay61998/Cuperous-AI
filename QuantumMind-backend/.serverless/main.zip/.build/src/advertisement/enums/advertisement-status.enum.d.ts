export declare enum AdvertisementStatus {
    PUBLISHED = "published",
    DRAFT = "draft"
}
