"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ADVERTISEMENT_PROVIDER = void 0;
exports.ADVERTISEMENT_PROVIDER = 'ADVERTISEMENT_PROVIDER';
//# sourceMappingURL=constatnts.js.map