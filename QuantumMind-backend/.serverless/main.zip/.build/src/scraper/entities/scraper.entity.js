"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScraperSchema = exports.Scraper = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const scrape_status_enum_1 = require("../enum/scrape-status.enum");
let Scraper = class Scraper {
};
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
    }),
    __metadata("design:type", String)
], Scraper.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
    }),
    __metadata("design:type", String)
], Scraper.prototype, "url", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
    }),
    __metadata("design:type", Array)
], Scraper.prototype, "data", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: scrape_status_enum_1.ScrapeStatusEnum.DRAFT,
    }),
    __metadata("design:type", String)
], Scraper.prototype, "status", void 0);
Scraper = __decorate([
    (0, mongoose_1.Schema)({
        virtuals: true,
        timestamps: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret._id;
                delete ret.__v;
            },
        },
    })
], Scraper);
exports.Scraper = Scraper;
exports.ScraperSchema = mongoose_1.SchemaFactory.createForClass(Scraper);
//# sourceMappingURL=scraper.entity.js.map