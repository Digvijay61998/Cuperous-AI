import * as mongoose from "mongoose";
export type ScraperDocument = Scraper & mongoose.Document;
export declare class Scraper {
    title: string;
    url: string;
    data: string[];
    status: string;
}
export declare const ScraperSchema: mongoose.Schema<Scraper, mongoose.Model<Scraper, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Scraper>;
