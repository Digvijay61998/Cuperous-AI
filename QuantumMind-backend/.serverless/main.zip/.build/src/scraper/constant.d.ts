export declare const SCRAPER_PROVIDER = "SCRAPE_MODEL";
