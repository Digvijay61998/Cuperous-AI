"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCRAPER_PROVIDER = void 0;
exports.SCRAPER_PROVIDER = "SCRAPE_MODEL";
//# sourceMappingURL=constant.js.map