export declare class ScrapeModule {
}
