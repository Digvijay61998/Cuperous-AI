"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScraperProviders = void 0;
const constants_1 = require("src/constants");
const constant_1 = require("./constant");
const scraper_entity_1 = require("./entities/scraper.entity");
exports.ScraperProviders = [
    {
        provide: constant_1.SCRAPER_PROVIDER,
        useFactory: (connection) => connection.model(scraper_entity_1.Scraper.name, scraper_entity_1.ScraperSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=scraper.provider.js.map