export declare class SearchParamDto {
    skip?: number;
    limit?: number;
    status?: string;
    tags?: string[];
}
