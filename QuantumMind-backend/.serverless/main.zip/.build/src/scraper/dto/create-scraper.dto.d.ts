export declare class CreateScrapeDto {
    url: string;
    tags: [];
}
