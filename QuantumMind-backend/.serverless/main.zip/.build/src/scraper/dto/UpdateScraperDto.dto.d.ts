export declare class UpdateScrapeDto {
    status: string;
}
