"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScrapeModule = void 0;
const common_1 = require("@nestjs/common");
const scraper_service_1 = require("./scraper.service");
const scraper_controller_1 = require("./scraper.controller");
const scraper_provider_1 = require("./scraper.provider");
const axios_1 = require("@nestjs/axios");
let ScrapeModule = class ScrapeModule {
};
ScrapeModule = __decorate([
    (0, common_1.Module)({
        imports: [axios_1.HttpModule.register({})],
        controllers: [scraper_controller_1.ScraperController],
        providers: [scraper_service_1.ScraperService, ...scraper_provider_1.ScraperProviders],
        exports: [scraper_service_1.ScraperService],
    })
], ScrapeModule);
exports.ScrapeModule = ScrapeModule;
//# sourceMappingURL=scraper.module.js.map