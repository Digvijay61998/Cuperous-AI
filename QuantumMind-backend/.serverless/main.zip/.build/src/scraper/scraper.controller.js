"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScraperController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const create_scraper_dto_1 = require("./dto/create-scraper.dto");
const search_param_dto_1 = require("./dto/search-param.dto");
const scraper_service_1 = require("./scraper.service");
let ScraperController = class ScraperController {
    constructor(ScraperService) {
        this.ScraperService = ScraperService;
    }
    async create(CreateScrapeDto) {
        return await this.ScraperService.create(CreateScrapeDto);
    }
    async findAll(query) {
        return await this.ScraperService.findAll(query);
    }
    getParams() {
        return this.ScraperService.getParams();
    }
    async findOne(id) {
        return await this.ScraperService.findOne(id);
    }
    remove(id) {
        return this.ScraperService.remove(id);
    }
};
__decorate([
    (0, common_1.Post)(),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_scraper_dto_1.CreateScrapeDto]),
    __metadata("design:returntype", Promise)
], ScraperController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], ScraperController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)("params"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ScraperController.prototype, "getParams", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ScraperController.prototype, "findOne", null);
__decorate([
    (0, common_1.Delete)(":id"),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ScraperController.prototype, "remove", null);
ScraperController = __decorate([
    (0, common_1.Controller)("scraper"),
    (0, swagger_1.ApiTags)("Scraper"),
    __metadata("design:paramtypes", [scraper_service_1.ScraperService])
], ScraperController);
exports.ScraperController = ScraperController;
//# sourceMappingURL=scraper.controller.js.map