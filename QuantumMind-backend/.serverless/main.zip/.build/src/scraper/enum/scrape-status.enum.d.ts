export declare const ScrapeStatusEnum: {
    readonly DRAFT: "draft";
    readonly SUSPENDED: "suspended";
    readonly DELETED: "deleted";
};
export declare const ScrapeStatusPagesEnum: {
    readonly PENDING: "pending";
    readonly FAILED: "failed";
    readonly COMPLETED: "completed";
};
export declare const ScrapeStatusEnumList: string[];
export declare const ScrapeStatusAllPagesList: string[];
