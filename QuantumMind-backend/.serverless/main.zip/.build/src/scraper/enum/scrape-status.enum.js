"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScrapeStatusAllPagesList = exports.ScrapeStatusEnumList = exports.ScrapeStatusPagesEnum = exports.ScrapeStatusEnum = void 0;
exports.ScrapeStatusEnum = {
    DRAFT: 'draft',
    SUSPENDED: 'suspended',
    DELETED: 'deleted',
};
exports.ScrapeStatusPagesEnum = {
    PENDING: 'pending',
    FAILED: 'failed',
    COMPLETED: 'completed',
};
exports.ScrapeStatusEnumList = Object.values(exports.ScrapeStatusEnum);
exports.ScrapeStatusAllPagesList = Object.values(exports.ScrapeStatusPagesEnum);
//# sourceMappingURL=scrape-status.enum.js.map