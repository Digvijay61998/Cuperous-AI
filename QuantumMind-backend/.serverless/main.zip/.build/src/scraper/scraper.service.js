"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ScraperService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScraperService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const constant_1 = require("./constant");
const axios_1 = require("@nestjs/axios");
const scrape_status_enum_1 = require("./enum/scrape-status.enum");
const rxjs_1 = require("rxjs");
const config_1 = require("@nestjs/config");
let ScraperService = ScraperService_1 = class ScraperService {
    constructor(scraperModel, httpService, configService) {
        this.scraperModel = scraperModel;
        this.httpService = httpService;
        this.configService = configService;
        this.logger = new common_1.Logger(ScraperService_1.name);
    }
    async create(CreateScrapeDto) {
        const url = this.configService.get("scraper.url");
        try {
            const res = await (0, rxjs_1.firstValueFrom)(this.httpService.post(`${url}/api/scraper`, CreateScrapeDto));
            return res.data;
        }
        catch (error) {
            this.logger.error(`Error creating tag: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll(query) {
        try {
            const { skip, limit, status, tags } = query;
            const queryObj = {};
            if (status) {
                queryObj["status"] = status;
            }
            if (tags)
                queryObj["tags"] = { $in: tags };
            const scrape = this.scraperModel
                .find(queryObj)
                .skip(skip)
                .sort({ createdAt: -1 });
            if (limit)
                scrape.limit(limit);
            const count = await this.scraperModel.countDocuments(queryObj);
            const data = await scrape;
            return { data, count };
        }
        catch (error) {
            this.logger.error(`Error while getting all webhooks : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    getParams() {
        return {
            status: scrape_status_enum_1.ScrapeStatusEnumList,
            sync: scrape_status_enum_1.ScrapeStatusAllPagesList,
        };
    }
    async findOne(scrapeId) {
        try {
            const scrape = await this.scraperModel.findById(scrapeId);
            return scrape;
        }
        catch (error) {
            this.logger.error(`Error while getting scrape with id ${scrapeId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async remove(id) {
        try {
            const data = await this.scraperModel.findByIdAndDelete(id);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while deleting webhook with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
ScraperService = ScraperService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.SCRAPER_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        axios_1.HttpService,
        config_1.ConfigService])
], ScraperService);
exports.ScraperService = ScraperService;
//# sourceMappingURL=scraper.service.js.map