export declare class TagModule {
}
