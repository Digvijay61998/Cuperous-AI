/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { CreateTagDto } from './dto/create-tag.dto';
import { TagService } from './tag.service';
export declare class TagController {
    private readonly tagService;
    constructor(tagService: TagService);
    findAll(): Promise<{
        default: (import("./entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        })[];
        custom: (import("./entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        })[];
    }>;
    findAlltagsWithCount(): Promise<{
        default: {
            botCount: number;
            agentCount: number;
            offerCount: number;
            advertisementCount: number;
            questionCount: number;
            serviceRequests: number;
            _id: unknown;
        }[];
        custom: {
            botCount: number;
            agentCount: number;
            offerCount: number;
            advertisementCount: number;
            questionCount: number;
            serviceRequests: number;
            _id: unknown;
        }[];
    }>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    create(createTagDto: CreateTagDto): Promise<import("./entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string): Promise<import("./entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
