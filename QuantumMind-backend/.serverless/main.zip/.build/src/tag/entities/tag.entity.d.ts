import * as mongoose from 'mongoose';
import { TagTypesEnum } from '../enum/tag-types.enum';
export type TagDocument = Tag & mongoose.Document;
export declare class Tag {
    name: string;
    type: TagTypesEnum;
}
export declare const TagSchema: mongoose.Schema<Tag, mongoose.Model<Tag, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Tag>;
