"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TagService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TagService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const mongoose_1 = __importStar(require("mongoose"));
const get_subtitle_1 = require("src/util/get-subtitle");
const constant_1 = require("./constant");
const tag_types_enum_1 = require("./enum/tag-types.enum");
let TagService = TagService_1 = class TagService {
    constructor(tagModel, configService) {
        this.tagModel = tagModel;
        this.configService = configService;
        this.logger = new common_1.Logger(TagService_1.name);
    }
    async onModuleInit() {
        const tagList = this.configService.get('tags.defaultTags');
        let Tags = [];
        if (typeof tagList === 'string') {
            Tags = tagList.split(',');
        }
        else
            Tags = tagList;
        Tags.forEach(async (tag) => {
            const tagExist = await this.tagModel.findOne({ name: tag });
            if (!tagExist) {
                await this.tagModel.create({
                    name: tag,
                    type: tag_types_enum_1.TagTypesEnum.DEFAULT,
                });
            }
        });
        this.logger.debug(`Default tags created successfully: ${Tags.join(',')}`);
    }
    async create(createTagDto) {
        try {
            const tag = await this.tagModel.create(Object.assign(Object.assign({}, createTagDto), { type: tag_types_enum_1.TagTypesEnum.CUSTOM }));
            return tag;
        }
        catch (error) {
            this.logger.error(`Error creating tag: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTagList() {
        try {
            const tags = await this.tagModel
                .find()
                .select('name type')
                .sort({ name: 1 });
            const defaultTags = tags.filter((tag) => tag.type === tag_types_enum_1.TagTypesEnum.DEFAULT);
            const customTags = tags.filter((tag) => tag.type === tag_types_enum_1.TagTypesEnum.CUSTOM);
            return { default: defaultTags, custom: customTags };
        }
        catch (error) {
            this.logger.error(`Error getting tag list: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll() {
        try {
            const tickets = mongoose_1.default.model('Ticket');
            const bots = mongoose_1.default.model('Bot');
            const agents = mongoose_1.default.model('Agent');
            const offers = mongoose_1.default.model('Offer');
            const questions = mongoose_1.default.model('Question');
            const advertisements = mongoose_1.default.model('Advertisement');
            const tags = await this.tagModel
                .find()
                .select('name type')
                .sort({ name: 1 });
            const data = await Promise.all(tags.map(async (tag) => {
                const botCount = await bots.countDocuments({
                    tags: { $in: [tag._id] },
                });
                const agentCount = await agents.countDocuments({
                    tags: { $in: [tag._id] },
                });
                const offerCount = await offers.countDocuments({
                    'cards.tag': { $in: [tag.name] },
                });
                const advertisementCount = await advertisements.countDocuments({
                    'posters.tag': { $in: [tag.name] },
                });
                const questionCount = await questions.countDocuments({
                    tags: { $in: [tag.name] },
                });
                const ticketCount = await tickets.countDocuments({
                    tags: { $in: [tag.name] },
                });
                return Object.assign(Object.assign({}, tag.toObject()), { botCount,
                    agentCount,
                    offerCount,
                    advertisementCount,
                    questionCount, serviceRequests: ticketCount });
            }));
            const defaultTags = data.filter((tag) => tag.type === tag_types_enum_1.TagTypesEnum.DEFAULT);
            const customTags = data.filter((tag) => tag.type === tag_types_enum_1.TagTypesEnum.CUSTOM);
            return {
                default: defaultTags,
                custom: customTags,
            };
        }
        catch (error) {
            this.logger.error(`Error finding tags: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async deleteTag(tagId) {
        try {
            const tag = await this.tagModel.findOne({
                _id: tagId,
            });
            if (!tag) {
                throw new common_1.HttpException('Tag not found', 404);
            }
            await tag.remove();
            return tag;
        }
        catch (error) {
            this.logger.error(`Error deleting tag: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.tagModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.tagModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Total Tags',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'tag',
        };
    }
    async getDefaultCount(days = 30) {
        const total = await this.tagModel.countDocuments({
            type: tag_types_enum_1.TagTypesEnum.DEFAULT,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.tagModel.countDocuments({
                type: tag_types_enum_1.TagTypesEnum.DEFAULT,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Default Tags',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'tag',
        };
    }
    async getCustomCount(days = 30) {
        const total = await this.tagModel.countDocuments({
            type: tag_types_enum_1.TagTypesEnum.CUSTOM,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.tagModel.countDocuments({
                type: tag_types_enum_1.TagTypesEnum.CUSTOM,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? 'positive' : 'negative',
            title: 'Custom Tags',
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: 'tag',
        };
    }
    async stats(days = 30) {
        try {
            const result = await Promise.all([
                this.getTotalCount(days),
                this.getDefaultCount(days),
                this.getCustomCount(days),
            ]);
            return result;
        }
        catch (error) {
            this.logger.error(`Error getting stats: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
TagService = TagService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.TAG_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        config_1.ConfigService])
], TagService);
exports.TagService = TagService;
//# sourceMappingURL=tag.service.js.map