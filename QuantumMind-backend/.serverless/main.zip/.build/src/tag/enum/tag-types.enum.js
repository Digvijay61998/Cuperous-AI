"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TagTypesEnum = void 0;
var TagTypesEnum;
(function (TagTypesEnum) {
    TagTypesEnum["DEFAULT"] = "DEFAULT";
    TagTypesEnum["CUSTOM"] = "CUSTOM";
})(TagTypesEnum = exports.TagTypesEnum || (exports.TagTypesEnum = {}));
//# sourceMappingURL=tag-types.enum.js.map