export declare enum TagTypesEnum {
    DEFAULT = "DEFAULT",
    CUSTOM = "CUSTOM"
}
