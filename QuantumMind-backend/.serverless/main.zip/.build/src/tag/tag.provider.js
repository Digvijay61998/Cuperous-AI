"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TagProviders = void 0;
const constants_1 = require("src/constants");
const constant_1 = require("./constant");
const tag_entity_1 = require("./entities/tag.entity");
exports.TagProviders = [
    {
        provide: constant_1.TAG_PROVIDER,
        useFactory: (connection) => connection.model(tag_entity_1.Tag.name, tag_entity_1.TagSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=tag.provider.js.map