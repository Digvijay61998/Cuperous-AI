"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TAG_PROVIDER = void 0;
exports.TAG_PROVIDER = 'TAG_MODEL';
//# sourceMappingURL=constant.js.map