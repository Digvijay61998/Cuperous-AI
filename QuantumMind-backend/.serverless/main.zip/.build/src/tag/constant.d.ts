export declare const TAG_PROVIDER = "TAG_MODEL";
