import { OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import mongoose, { Model } from 'mongoose';
import { CreateTagDto } from './dto/create-tag.dto';
import { TagDocument } from './entities/tag.entity';
export declare class TagService implements OnModuleInit {
    private readonly tagModel;
    private readonly configService;
    private logger;
    constructor(tagModel: Model<TagDocument>, configService: ConfigService);
    onModuleInit(): Promise<void>;
    create(createTagDto: CreateTagDto): Promise<import("./entities/tag.entity").Tag & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    getTagList(): Promise<{
        default: (import("./entities/tag.entity").Tag & mongoose.Document<any, any, any> & {
            _id: mongoose.Types.ObjectId;
        })[];
        custom: (import("./entities/tag.entity").Tag & mongoose.Document<any, any, any> & {
            _id: mongoose.Types.ObjectId;
        })[];
    }>;
    findAll(): Promise<{
        default: {
            botCount: number;
            agentCount: number;
            offerCount: number;
            advertisementCount: number;
            questionCount: number;
            serviceRequests: number;
            _id: unknown;
        }[];
        custom: {
            botCount: number;
            agentCount: number;
            offerCount: number;
            advertisementCount: number;
            questionCount: number;
            serviceRequests: number;
            _id: unknown;
        }[];
    }>;
    deleteTag(tagId: string): Promise<import("./entities/tag.entity").Tag & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getDefaultCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getCustomCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
}
