"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MailsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailsService = void 0;
const mailer_1 = require("@nestjs-modules/mailer");
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const conversation_service_1 = require("src/conversation/conversation.service");
const send_transcript_dto_1 = require("./dto/send-transcript.dto");
let MailsService = MailsService_1 = class MailsService {
    constructor(mailerService, conversationService) {
        this.mailerService = mailerService;
        this.conversationService = conversationService;
        this.logger = new common_1.Logger(MailsService_1.name);
    }
    async sendMail({ email, name, conversationId, visitorId, }) {
        try {
            const chats = await this.conversationService.getChats(conversationId, visitorId);
            return await this.mailerService.sendMail({
                to: email,
                subject: 'Greeting from Engage Bot',
                template: './mail-transcript.template.hbs',
                context: {
                    name: name,
                    transcript: chats,
                },
            });
        }
        catch (err) {
            this.logger.error('Error in sending mail', err.message);
        }
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)('send-transcript-to-visitor', { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_transcript_dto_1.SendTranscriptDto]),
    __metadata("design:returntype", Promise)
], MailsService.prototype, "sendMail", null);
MailsService = MailsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [mailer_1.MailerService,
        conversation_service_1.ConversationService])
], MailsService);
exports.MailsService = MailsService;
//# sourceMappingURL=mails.service.js.map