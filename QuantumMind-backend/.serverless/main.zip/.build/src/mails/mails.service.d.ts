import { MailerService } from '@nestjs-modules/mailer';
import { ConversationService } from 'src/conversation/conversation.service';
import { SendTranscriptDto } from './dto/send-transcript.dto';
export declare class MailsService {
    private mailerService;
    private readonly conversationService;
    private readonly logger;
    constructor(mailerService: MailerService, conversationService: ConversationService);
    sendMail({ email, name, conversationId, visitorId, }: SendTranscriptDto): Promise<SentMessageInfo>;
}
