import { SendTranscriptDto } from './dto/send-transcript.dto';
import { MailsService } from './mails.service';
export declare class MailsController {
    private readonly mailsService;
    constructor(mailsService: MailsService);
    sendEmail(Body: SendTranscriptDto): Promise<SentMessageInfo>;
}
