export declare class MailsModule {
}
