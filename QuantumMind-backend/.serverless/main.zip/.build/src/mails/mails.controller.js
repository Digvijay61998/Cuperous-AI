"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const send_transcript_dto_1 = require("./dto/send-transcript.dto");
const mails_service_1 = require("./mails.service");
let MailsController = class MailsController {
    constructor(mailsService) {
        this.mailsService = mailsService;
    }
    async sendEmail(Body) {
        return this.mailsService.sendMail(Body);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_transcript_dto_1.SendTranscriptDto]),
    __metadata("design:returntype", Promise)
], MailsController.prototype, "sendEmail", null);
MailsController = __decorate([
    (0, common_1.Controller)('mail'),
    (0, swagger_1.ApiTags)('Mail'),
    __metadata("design:paramtypes", [mails_service_1.MailsService])
], MailsController);
exports.MailsController = MailsController;
//# sourceMappingURL=mails.controller.js.map