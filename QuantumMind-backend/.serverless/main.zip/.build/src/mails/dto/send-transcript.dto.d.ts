export declare class SendTranscriptDto {
    name: string;
    email: string;
    conversationId: string;
    visitorId: string;
}
