import { HttpService } from "@nestjs/axios";
import { Request } from "express";
import mongoose, { Model } from "mongoose";
import { CreateVisitorDto } from "./dto/create-visitor.dto";
import { VisitorQueryParams } from "./dto/visitor-query.params.dto";
import { VisitorDetailsDocument } from "./entities/visitor-details.entity";
import { VisitorDocument } from "./entities/visitor.entity";
import { VisitorStatusEnum } from "./enums/visitor-status.enum";
import { ConversationService } from "src/conversation/conversation.service";
import { ReportParamsDto } from "src/util/report-params.dto";
export declare class VisitorService {
    private visitorModel;
    private visitorDetailsModel;
    private httpService;
    private conversationService;
    private readonly logger;
    private userData;
    constructor(visitorModel: Model<VisitorDocument>, visitorDetailsModel: Model<VisitorDetailsDocument>, httpService: HttpService, conversationService: ConversationService);
    createVisitor(createVisitorDto: CreateVisitorDto, req: any): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    getVisitor(visitorId: string): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    getAllVisitors(query: VisitorQueryParams): Promise<{
        count: number;
        data: Omit<Omit<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
            _id: mongoose.Types.ObjectId;
        }, never>, never>[];
        search: {
            bots: any[];
            status: ("online" | "offline")[];
        };
    }>;
    addServiceRequests(visitorId: string, serviceRequestId: string): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    addConversations({ visitorId, conversationId, }: {
        visitorId: string;
        conversationId: string;
    }): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    getDemographics(req: Request): Promise<any>;
    addAgents({ visitorId, agentId, }: {
        visitorId: string;
        agentId: string;
    }): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    updateStatus(visitorId: string, status: VisitorStatusEnum): Promise<import("./entities/visitor.entity").Visitor & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    updateFeedback(visitorId: string, feedbackId: string): Promise<void>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getActiveCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getStats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    handledByAgentCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    handledByBotCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getVisiorPattern(): Promise<any>;
    getVisitorReport(): Promise<any>;
    CreateVisitorfromSocialMedia(visitor: CreateVisitorDto): Promise<string>;
    getHandledByAgentReport(query: ReportParamsDto): Promise<any[]>;
    getHandledByBotReport(query: ReportParamsDto): Promise<any[]>;
    homeVisitorCount(filter: any): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
    monthWiseVisitor(): Promise<{
        chart: any[];
        yearWise: any[];
    }>;
}
