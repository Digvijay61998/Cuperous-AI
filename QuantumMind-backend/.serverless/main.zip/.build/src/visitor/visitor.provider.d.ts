/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { Connection } from 'mongoose';
import { Visitor } from './entities/visitor.entity';
import { VisitorDetails } from './entities/visitor-details.entity';
export declare const VisitorProviders: ({
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<Visitor, {}, {}, {}, import("mongoose").Schema<Visitor, import("mongoose").Model<Visitor, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Visitor>>;
    inject: string[];
} | {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<VisitorDetails, {}, {}, {}, import("mongoose").Schema<VisitorDetails, import("mongoose").Model<VisitorDetails, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, VisitorDetails>>;
    inject: string[];
})[];
