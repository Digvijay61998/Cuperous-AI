"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const create_visitor_dto_1 = require("./dto/create-visitor.dto");
const visitor_query_params_dto_1 = require("./dto/visitor-query.params.dto");
const visitor_service_1 = require("./visitor.service");
const report_params_dto_1 = require("src/util/report-params.dto");
let VisitorController = class VisitorController {
    constructor(visitorService) {
        this.visitorService = visitorService;
    }
    async findAll(query) {
        return this.visitorService.getAllVisitors(query);
    }
    async getHomeVisitorsStats(time) {
        return await this.visitorService.homeVisitorCount(time);
    }
    async getMonthWiseReport() {
        return await this.visitorService.monthWiseVisitor();
    }
    async totalVisitors() {
        return await this.visitorService.getVisitorReport();
    }
    async visitorDetails() {
        return await this.visitorService.getVisiorPattern();
    }
    async handledByBot(query) {
        return await this.visitorService.getHandledByBotReport(query);
    }
    async handledByAgent(query) {
        return await this.visitorService.getHandledByAgentReport(query);
    }
    async getStats() {
        return await this.visitorService.getStats();
    }
    async findOne(id) {
        return this.visitorService.getVisitor(id);
    }
    async create(body, req) {
        return await this.visitorService.createVisitor(body, req);
    }
};
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [visitor_query_params_dto_1.VisitorQueryParams]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('/stat/home'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)('time')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "getHomeVisitorsStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/month-wise'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "getMonthWiseReport", null);
__decorate([
    (0, common_1.Get)('report/total'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "totalVisitors", null);
__decorate([
    (0, common_1.Get)('report/details'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "visitorDetails", null);
__decorate([
    (0, common_1.Get)('report/total/handel-by-bot'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "handledByBot", null);
__decorate([
    (0, common_1.Get)('report/total/handel-by-agent'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "handledByAgent", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_visitor_dto_1.CreateVisitorDto, Object]),
    __metadata("design:returntype", Promise)
], VisitorController.prototype, "create", null);
VisitorController = __decorate([
    (0, common_1.Controller)('visitor'),
    (0, swagger_1.ApiTags)('Visitor'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [visitor_service_1.VisitorService])
], VisitorController);
exports.VisitorController = VisitorController;
//# sourceMappingURL=visitor.controller.js.map