export declare const VisitorStatusEnum: {
    readonly ONLINE: "online";
    readonly OFFLINE: "offline";
};
export type VisitorStatusEnum = (typeof VisitorStatusEnum)[keyof typeof VisitorStatusEnum];
export declare const VisitorStatusEnumList: ("online" | "offline")[];
