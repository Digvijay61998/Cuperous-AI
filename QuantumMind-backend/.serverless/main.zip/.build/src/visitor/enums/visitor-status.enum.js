"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorStatusEnumList = exports.VisitorStatusEnum = void 0;
exports.VisitorStatusEnum = {
    ONLINE: "online",
    OFFLINE: "offline",
};
exports.VisitorStatusEnumList = Object.values(exports.VisitorStatusEnum);
//# sourceMappingURL=visitor-status.enum.js.map