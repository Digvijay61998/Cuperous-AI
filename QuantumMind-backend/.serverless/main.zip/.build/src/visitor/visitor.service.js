"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var VisitorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const class_validator_1 = require("class-validator");
const mongoose_1 = __importStar(require("mongoose"));
const rxjs_1 = require("rxjs");
const util_1 = require("src/util");
const get_subtitle_1 = require("src/util/get-subtitle");
const constant_1 = require("./constant");
const visitor_status_enum_1 = require("./enums/visitor-status.enum");
const conversation_service_1 = require("src/conversation/conversation.service");
const moment_1 = __importDefault(require("moment"));
let VisitorService = VisitorService_1 = class VisitorService {
    constructor(visitorModel, visitorDetailsModel, httpService, conversationService) {
        this.visitorModel = visitorModel;
        this.visitorDetailsModel = visitorDetailsModel;
        this.httpService = httpService;
        this.conversationService = conversationService;
        this.logger = new common_1.Logger(VisitorService_1.name);
        this.userData = new Map();
    }
    async createVisitor(createVisitorDto, req) {
        if (req) {
        }
        const visitorId = (0, util_1.generateId)("visitor", 10);
        const email = createVisitorDto.email || `${visitorId}@nomemail.com`;
        const phone = createVisitorDto.phone || "0000000000";
        const name = createVisitorDto.name || "Anonymous";
        let visitor = await this.visitorModel.findOne({
            email,
            bot: createVisitorDto.bot,
        });
        if (!visitor) {
            visitor = await this.visitorModel.create({
                email,
                name,
                phone,
                bot: createVisitorDto.bot,
                visitorId,
            });
        }
        if (req) {
            const ua = req.headers["user-agent"];
            const demographics = await this.getDemographics(req);
            this.logger.debug(`Demographics : ${JSON.stringify(demographics)}`);
            const visitorDetails = await this.visitorDetailsModel.create(Object.assign(Object.assign({ ua }, demographics), { visitorId: visitor._id }));
            visitor.visitorDetails.push(visitorDetails._id);
        }
        await visitor.save();
        return visitor;
    }
    async getVisitor(visitorId) {
        try {
            const visitor = await this.visitorModel
                .findById(visitorId)
                .populate("serviceRequests", "subject status priority conversationId description tags")
                .populate("bot", "name")
                .populate("agents", "name email status rating ")
                .populate("feedbacks", "rating comment")
                .populate({
                path: "conversations",
                populate: {
                    path: "bot",
                    select: "name",
                },
                select: "-chats -activities",
            })
                .populate("visitorDetails");
            return visitor;
        }
        catch (error) {
            this.logger.error(`Error while getting visitor with id ${visitorId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getAllVisitors(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, bot, status, startDate, endDate, text, } = query;
            const queryObject = {};
            if (status)
                queryObject["status"] = status;
            if (bot)
                queryObject["bot"] = bot;
            if (startDate)
                queryObject["createdAt"] = { $gte: startDate };
            if (endDate)
                queryObject["createdAt"] = { $lte: endDate };
            if (startDate && endDate)
                queryObject["createdAt"] = { $gte: startDate, $lte: endDate };
            if (text) {
                const regex = new RegExp(text, "i");
                queryObject["$or"] = [
                    { name: { $regex: regex } },
                    { email: { $regex: regex } },
                    { phone: { $regex: regex } },
                ];
            }
            const visitors = this.visitorModel
                .find(queryObject)
                .populate("bot", "name")
                .populate("visitorDetails")
                .sort({ createdAt: -1 })
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                visitors.limit(limitOfDocuments);
            }
            const data = await visitors;
            const queryObject2 = {};
            if (status)
                queryObject2["status"] = status;
            if (bot)
                queryObject2["bot"] = new mongoose_1.default.Types.ObjectId(bot);
            if (startDate)
                queryObject2["createdAt"] = { $gte: startDate };
            if (endDate)
                queryObject2["createdAt"] = { $lte: endDate };
            if (startDate && endDate)
                queryObject2["createdAt"] = { $gte: startDate, $lte: endDate };
            if (text) {
                const regex = new RegExp(text, "i");
                queryObject2["$or"] = [
                    { name: { $regex: regex } },
                    { email: { $regex: regex } },
                    { phone: { $regex: regex } },
                ];
            }
            const bots = await this.visitorModel.aggregate([
                {
                    $match: queryObject2,
                },
                {
                    $lookup: {
                        from: "bots",
                        localField: "bot",
                        foreignField: "_id",
                        as: "bot",
                    },
                },
                {
                    $unwind: {
                        path: "$bot",
                    },
                },
                {
                    $group: {
                        _id: "$bot._id",
                        name: { $first: "$bot.name" },
                    },
                },
            ]);
            const count = await this.visitorModel.countDocuments(queryObject);
            return {
                count,
                data,
                search: {
                    bots,
                    status: visitor_status_enum_1.VisitorStatusEnumList,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error while getting all visitors : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async addServiceRequests(visitorId, serviceRequestId) {
        try {
            const visitor = await this.visitorModel.findById(visitorId);
            if (visitor && visitor.serviceRequests.indexOf(serviceRequestId) === -1) {
                visitor.serviceRequests.push(serviceRequestId);
                visitor.save();
                return visitor;
            }
        }
        catch (error) {
            this.logger.error(`Error while adding service request to visitor with id ${visitorId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async addConversations({ visitorId, conversationId, }) {
        try {
            const visitor = await this.visitorModel.findById(visitorId);
            if (!visitor)
                return;
            visitor.conversations.push(conversationId);
            visitor.save();
            return visitor;
        }
        catch (error) {
            this.logger.error(`Error while adding conversation to visitor with id ${visitorId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getDemographics(req) {
        var _a, _b, _c, _d, _e;
        const ua = req.headers["user-agent"];
        const { browser, os, device } = (0, util_1.parseUserAgent)(ua);
        let ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "";
        ip = ip.toString().split(",")[0];
        this.logger.debug(`Visitor IP : ${ip}`);
        let data = this.userData.get(ip) || {};
        if ((0, class_validator_1.isIP)(ip)) {
            if (!data.country) {
                try {
                    const response = await (0, rxjs_1.firstValueFrom)(this.httpService.get(`http://ip-api.com/json/${ip}`));
                    this.logger.debug(`Visitor IP API Response : ${JSON.stringify(response.data)}`);
                    data = {
                        country: ((_a = response.data) === null || _a === void 0 ? void 0 : _a.country) || "Unknown",
                        city: ((_b = response.data) === null || _b === void 0 ? void 0 : _b.city) || ((_c = response.data) === null || _c === void 0 ? void 0 : _c.regionName) || "Unknown",
                        lat: ((_d = response.data) === null || _d === void 0 ? void 0 : _d.lat) || 0,
                        lon: ((_e = response.data) === null || _e === void 0 ? void 0 : _e.lon) || 0,
                    };
                    this.userData.set(ip, data);
                }
                catch (e) {
                    data = {
                        country: "Unknown",
                        city: "Unknown",
                        lat: 0,
                        lon: 0,
                    };
                }
            }
        }
        return Object.assign(Object.assign({}, data), { device,
            os,
            browser,
            ip });
    }
    async addAgents({ visitorId, agentId, }) {
        const visitor = await this.visitorModel.findById(visitorId);
        if (!visitor)
            return;
        if (!visitor.agents || !visitor.agents.length) {
            visitor.agents = [agentId];
        }
        else if (visitor.agents &&
            visitor.agents.length > 0 &&
            visitor.agents.indexOf(agentId) === -1) {
            visitor.agents.push(agentId);
        }
        visitor.save();
        return visitor;
    }
    async updateStatus(visitorId, status) {
        const visitor = await this.visitorModel.findById(visitorId);
        if (visitor) {
            visitor.status = status;
            visitor.save();
            return visitor;
        }
    }
    async updateFeedback(visitorId, feedbackId) {
        try {
            const visitor = await this.visitorModel.findById(visitorId);
            if (visitor) {
                visitor.feedbacks.push(feedbackId);
                await visitor.save();
            }
        }
        catch (error) {
            this.logger.error(`Error while adding rating and feedback to visitor with id ${visitorId} : ${error.message}`);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.visitorModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.visitorModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Visitors",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "total",
        };
    }
    async getActiveCount(days = 30) {
        const total = await this.visitorModel.countDocuments({
            status: visitor_status_enum_1.VisitorStatusEnum.ONLINE,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.visitorModel.countDocuments({
                status: visitor_status_enum_1.VisitorStatusEnum.ONLINE,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Active visitors",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "active",
        };
    }
    async getStats(days = 30) {
        try {
            const result = await Promise.all([
                this.getTotalCount(days),
                this.getActiveCount(days),
                this.handledByAgentCount(days),
                this.handledByBotCount(days),
            ]);
            return result;
        }
        catch (error) {
            this.logger.error(`Error while getting visitor stats : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async handledByAgentCount(days = 30) {
        const total = await this.visitorModel.countDocuments({
            agents: { $exists: true, $not: { $size: 0 } },
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.visitorModel.countDocuments({
                agents: { $exists: true, $not: { $size: 0 } },
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Handled by agent",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "agent",
        };
    }
    async handledByBotCount(days = 30) {
        const total = await this.visitorModel.countDocuments({
            agents: { $size: 0 },
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.visitorModel.countDocuments({
                agents: { $size: 0 },
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Handled by bot",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "bot",
        };
    }
    async getVisiorPattern() {
        try {
            const response = await this.visitorDetailsModel.aggregate([
                {
                    $facet: {
                        countries: [
                            {
                                $group: {
                                    _id: "$country",
                                    count: { $sum: 1 },
                                },
                            },
                            {
                                $project: {
                                    _id: 0,
                                    name: "$_id",
                                    count: 1,
                                },
                            },
                        ],
                        browsers: [
                            {
                                $group: {
                                    _id: "$browser",
                                    count: { $sum: 1 },
                                },
                            },
                            {
                                $project: {
                                    _id: 0,
                                    name: "$_id",
                                    count: 1,
                                },
                            },
                        ],
                        os: [
                            {
                                $group: {
                                    _id: "$os",
                                    count: { $sum: 1 },
                                },
                            },
                            {
                                $project: {
                                    _id: 0,
                                    name: "$_id",
                                    count: 1,
                                },
                            },
                        ],
                    },
                },
            ]);
            return response[0];
        }
        catch (error) {
            this.logger.error(`Error while getting total visitor : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getVisitorReport() {
        try {
            const response = await this.visitorModel.aggregate([
                {
                    $group: {
                        _id: null,
                        total: { $sum: 1 },
                        active: {
                            $sum: {
                                $cond: [{ $eq: ["$status", visitor_status_enum_1.VisitorStatusEnum.ONLINE] }, 1, 0],
                            },
                        },
                        inactive: {
                            $sum: {
                                $cond: [{ $eq: ["$status", visitor_status_enum_1.VisitorStatusEnum.OFFLINE] }, 1, 0],
                            },
                        },
                    },
                },
                {
                    $project: {
                        _id: 0,
                    },
                },
            ]);
            return response[0];
        }
        catch (error) {
            this.logger.error(`Error while getting total visitor : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async CreateVisitorfromSocialMedia(visitor) {
        const username = visitor.username;
        const visitorData = await this.visitorModel.findOne({ username });
        if (visitorData) {
            return visitorData.id;
        }
        const result = await this.visitorModel.create(visitor);
        return result.id;
    }
    async getHandledByAgentReport(query) {
        return await this.conversationService.getDateWiseConversations(query, true);
    }
    async getHandledByBotReport(query) {
        return await this.conversationService.getDateWiseConversations(query, false);
    }
    async homeVisitorCount(filter) {
        if (!filter)
            filter = "day";
        try {
            const total = await this.visitorModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().startOf(filter).toISOString()),
                },
            });
            let percentageChange = 0;
            const previousTotal = await this.visitorModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().subtract(1, filter).startOf(filter).toISOString()),
                },
            });
            if (previousTotal) {
                percentageChange = Math.round(((total - previousTotal) / previousTotal) * 100);
            }
            return {
                stats: total,
                trendNumber: Math.abs(percentageChange),
                trend: percentageChange > 0 ? "positive" : "negative",
                title: "Total Visitors",
                type: "visitor",
            };
        }
        catch (error) {
            this.logger.error(`Error while getting home conversation count ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async monthWiseVisitor() {
        try {
            const totalVisitor = await this.visitorModel.countDocuments({});
            const chart = await this.visitorModel.aggregate([
                {
                    $match: {
                        createdAt: {
                            $gte: new Date(new Date().getFullYear(), 0, 1),
                        },
                    },
                },
                {
                    $group: {
                        _id: {
                            $month: "$createdAt",
                        },
                        count: { $sum: 1 },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        _id: 0,
                        month: "$_id",
                        count: 1,
                        years: 1,
                    },
                },
            ]);
            const yearWise = await this.visitorModel.aggregate([
                {
                    $group: {
                        _id: {
                            $year: "$createdAt",
                        },
                        handledByAgent: {
                            $sum: {
                                $cond: [{ $eq: ["$agents", []] }, 0, 1],
                            },
                        },
                        handledByBot: {
                            $sum: {
                                $cond: [{ $eq: ["$agents", []] }, 1, 0],
                            },
                        },
                        total: { $sum: 1 },
                    },
                },
                {
                    $project: {
                        year: "$_id",
                        handledByAgent: 1,
                        handledByBot: 1,
                        total: 1,
                        _id: 0,
                    },
                },
            ]);
            const yearWiseData = yearWise.map((year) => {
                const growth = year.total / totalVisitor;
                return Object.assign(Object.assign({}, year), { growth: growth > 1 ? 100 : Math.round(growth * 100) });
            });
            return { chart, yearWise: yearWiseData };
        }
        catch (error) {
            this.logger.error(`Error while getting total month wise visitor : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)("conversation.created.visitor", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VisitorService.prototype, "addConversations", null);
__decorate([
    (0, event_emitter_1.OnEvent)("agent.added.visitor", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VisitorService.prototype, "addAgents", null);
VisitorService = VisitorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.VISITOR_PROVIDER)),
    __param(1, (0, common_1.Inject)(constant_1.VISITOR_DETAILS_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        mongoose_1.Model,
        axios_1.HttpService,
        conversation_service_1.ConversationService])
], VisitorService);
exports.VisitorService = VisitorService;
//# sourceMappingURL=visitor.service.js.map