"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VISITOR_DETAILS_PROVIDER = exports.VISITOR_PROVIDER = void 0;
exports.VISITOR_PROVIDER = 'VISITOR_MODEL';
exports.VISITOR_DETAILS_PROVIDER = 'VISITOR_DETAILS_MODEL';
//# sourceMappingURL=constant.js.map