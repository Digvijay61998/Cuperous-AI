export declare class VisitorModule {
}
