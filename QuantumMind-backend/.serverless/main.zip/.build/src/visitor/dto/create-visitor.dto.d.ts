export declare class CreateVisitorDto {
    name: string;
    email?: string;
    phone?: string;
    bot: string;
    username?: string;
    platform?: string;
}
