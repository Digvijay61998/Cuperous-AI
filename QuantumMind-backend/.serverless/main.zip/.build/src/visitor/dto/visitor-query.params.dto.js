"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorQueryParams = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const visitor_status_enum_1 = require("../enums/visitor-status.enum");
class VisitorQueryParams {
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, swagger_1.ApiPropertyOptional)({
        default: 0,
    }),
    __metadata("design:type", Number)
], VisitorQueryParams.prototype, "skip", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    (0, swagger_1.ApiPropertyOptional)({
        default: 10,
    }),
    __metadata("design:type", Number)
], VisitorQueryParams.prototype, "limit", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, swagger_1.ApiPropertyOptional)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], VisitorQueryParams.prototype, "bot", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, class_validator_1.IsEnum)(visitor_status_enum_1.VisitorStatusEnum),
    (0, swagger_1.ApiPropertyOptional)({
        enum: visitor_status_enum_1.VisitorStatusEnum,
    }),
    __metadata("design:type", String)
], VisitorQueryParams.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, swagger_1.ApiPropertyOptional)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], VisitorQueryParams.prototype, "startDate", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, swagger_1.ApiPropertyOptional)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], VisitorQueryParams.prototype, "endDate", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], VisitorQueryParams.prototype, "text", void 0);
exports.VisitorQueryParams = VisitorQueryParams;
//# sourceMappingURL=visitor-query.params.dto.js.map