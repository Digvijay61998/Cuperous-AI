export declare class VisitorQueryParams {
    skip?: number;
    limit?: number;
    bot?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    text?: string;
}
