/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { CreateVisitorDto } from './dto/create-visitor.dto';
import { VisitorQueryParams } from './dto/visitor-query.params.dto';
import { VisitorService } from './visitor.service';
import { ReportParamsDto } from 'src/util/report-params.dto';
export declare class VisitorController {
    private readonly visitorService;
    constructor(visitorService: VisitorService);
    findAll(query: VisitorQueryParams): Promise<{
        count: number;
        data: Omit<Omit<import("./entities/visitor.entity").Visitor & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>, never>[];
        search: {
            bots: any[];
            status: ("online" | "offline")[];
        };
    }>;
    getHomeVisitorsStats(time: string): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
    getMonthWiseReport(): Promise<{
        chart: any[];
        yearWise: any[];
    }>;
    totalVisitors(): Promise<any>;
    visitorDetails(): Promise<any>;
    handledByBot(query: ReportParamsDto): Promise<any[]>;
    handledByAgent(query: ReportParamsDto): Promise<any[]>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    findOne(id: string): Promise<import("./entities/visitor.entity").Visitor & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    create(body: CreateVisitorDto, req: any): Promise<import("./entities/visitor.entity").Visitor & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
