import * as mongoose from "mongoose";
export type VisitorDetailsDocument = VisitorDetails & mongoose.Document;
export declare class VisitorDetails {
    visitorId: string;
    ua: string;
    ip: string;
    country: string;
    city: string;
    device: string;
    os: string;
    browser: string;
    lat: number;
    lon: number;
    agent: string;
}
export declare const VisitorDetailsSchema: mongoose.Schema<VisitorDetails, mongoose.Model<VisitorDetails, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, VisitorDetails>;
