import * as mongoose from "mongoose";
import { Bot } from "src/bots/entities";
import { VisitorDetails } from "./visitor-details.entity";
export type VisitorDocument = Visitor & mongoose.Document;
export declare class Visitor {
    _id: mongoose.Schema.Types.ObjectId;
    name: string;
    email: string;
    phone: string;
    bot: Bot;
    serviceRequests: string[];
    conversations: string[];
    visitorDetails: VisitorDetails[];
    status: string;
    agents: string[];
    reportedCount: number;
    feedbacks: string[];
    platform: string;
    username: string;
}
export declare const VisitorSchema: mongoose.Schema<Visitor, mongoose.Model<Visitor, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Visitor>;
