"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorSchema = exports.Visitor = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const entities_1 = require("src/bots/entities");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
const visitor_status_enum_1 = require("../enums/visitor-status.enum");
const visitor_details_entity_1 = require("./visitor-details.entity");
let Visitor = class Visitor {
};
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Visitor.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        lowercase: true,
    }),
    __metadata("design:type", String)
], Visitor.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Visitor.prototype, "phone", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: entities_1.Bot.name,
    }),
    __metadata("design:type", entities_1.Bot)
], Visitor.prototype, "bot", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Ticket",
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Visitor.prototype, "serviceRequests", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Conversation",
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Visitor.prototype, "conversations", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: visitor_details_entity_1.VisitorDetails.name,
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Visitor.prototype, "visitorDetails", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: visitor_status_enum_1.VisitorStatusEnum.OFFLINE,
    }),
    __metadata("design:type", String)
], Visitor.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Agent",
            },
        ],
    }),
    __metadata("design:type", Array)
], Visitor.prototype, "agents", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Visitor.prototype, "reportedCount", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Feedback" }],
        default: [],
    }),
    __metadata("design:type", Array)
], Visitor.prototype, "feedbacks", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: platform_enum_1.PlatformEnum.WIDGET,
        enum: platform_enum_1.PlatformEnum,
    }),
    __metadata("design:type", String)
], Visitor.prototype, "platform", void 0);
__decorate([
    (0, mongoose_1.Prop)({}),
    __metadata("design:type", String)
], Visitor.prototype, "username", void 0);
Visitor = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret.__v;
                delete ret.visitorDetails;
                delete ret.totalRating;
                delete ret.totalRatingCount;
                return ret;
            },
        },
    })
], Visitor);
exports.Visitor = Visitor;
exports.VisitorSchema = mongoose_1.SchemaFactory.createForClass(Visitor);
exports.VisitorSchema.index({
    name: "text",
    email: "text",
    phone: "text",
});
exports.VisitorSchema.virtual("details").get(function () {
    if (!this.visitorDetails || this.visitorDetails.length === 0)
        return null;
    return this.visitorDetails[this.visitorDetails.length - 1];
});
//# sourceMappingURL=visitor.entity.js.map