"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisitorProviders = void 0;
const constant_1 = require("./constant");
const visitor_entity_1 = require("./entities/visitor.entity");
const visitor_details_entity_1 = require("./entities/visitor-details.entity");
const constants_1 = require("src/constants");
exports.VisitorProviders = [
    {
        provide: constant_1.VISITOR_PROVIDER,
        useFactory: (connection) => connection.model(visitor_entity_1.Visitor.name, visitor_entity_1.VisitorSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.VISITOR_DETAILS_PROVIDER,
        useFactory: (connection) => connection.model(visitor_details_entity_1.VisitorDetails.name, visitor_details_entity_1.VisitorDetailsSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=visitor.provider.js.map