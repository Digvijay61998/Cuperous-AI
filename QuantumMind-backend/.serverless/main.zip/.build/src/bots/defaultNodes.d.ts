export declare const defaultNodes: {
    nodes: ({
        id: string;
        data: {
            label: string;
            icon: string;
            title: string;
        };
        position: {
            x: number;
            y: number;
        };
        type: string;
        className: string;
        width: number;
        height: number;
        nodeType: string;
        selected?: undefined;
        positionAbsolute?: undefined;
        dragging?: undefined;
    } | {
        data: {
            label: string;
            icon: string;
            title: string;
        };
        position: {
            x: number;
            y: number;
        };
        id: string;
        type: string;
        nodeType: string;
        width: number;
        height: number;
        selected: boolean;
        positionAbsolute: {
            x: number;
            y: number;
        };
        dragging: boolean;
        className?: undefined;
    })[];
    edges: {
        id: string;
        source: string;
        target: string;
    }[];
};
