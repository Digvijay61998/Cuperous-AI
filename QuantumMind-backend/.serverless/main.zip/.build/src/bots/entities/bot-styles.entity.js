"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotStylesSchema = exports.BotStyles = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const widget_position_enum_1 = require("../enums/widget-position.enum");
let BotStyles = class BotStyles {
};
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: "Bot",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "botId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#FFFFFF",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "textColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#3F51B5",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "primaryColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#f44336",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "secondaryColor", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], BotStyles.prototype, "avatar", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], BotStyles.prototype, "widgetAvatar", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#FFFFFF",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "headerTextColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#3F51B5",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "headerBackgroundColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#3F51B5",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "buttonColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "#FFFFFF",
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "buttonTextColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: widget_position_enum_1.WidgetPosition.LEFT,
    }),
    __metadata("design:type", String)
], BotStyles.prototype, "widgetPosition", void 0);
BotStyles = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
    })
], BotStyles);
exports.BotStyles = BotStyles;
exports.BotStylesSchema = mongoose_1.SchemaFactory.createForClass(BotStyles);
//# sourceMappingURL=bot-styles.entity.js.map