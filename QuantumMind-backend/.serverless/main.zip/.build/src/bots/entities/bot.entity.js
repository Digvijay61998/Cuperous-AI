"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotSchema = exports.Bot = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const agent_entity_1 = require("src/agent/entities/agent.entity");
const util_1 = require("src/util");
const bot_setting_entity_1 = require("./bot-setting.entity");
const bot_styles_entity_1 = require("./bot-styles.entity");
const bot_status_enum_1 = require("../enums/bot-status.enum");
const bot_flow_entity_1 = require("./bot-flow.entity");
const tag_entity_1 = require("src/tag/entities/tag.entity");
let Bot = class Bot {
};
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Bot.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: agent_entity_1.Agent.name }],
    }),
    __metadata("design:type", Array)
], Bot.prototype, "agents", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: bot_status_enum_1.BotStatusEnum.ACTIVE,
    }),
    __metadata("design:type", String)
], Bot.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Bot.prototype, "published", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: () => (0, util_1.generateId)('bot', 15),
    }),
    __metadata("design:type", String)
], Bot.prototype, "botId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: mongoose.Schema.Types.ObjectId, ref: bot_styles_entity_1.BotStyles.name }),
    __metadata("design:type", bot_styles_entity_1.BotStyles)
], Bot.prototype, "botStyles", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: mongoose.Schema.Types.ObjectId, ref: bot_setting_entity_1.BotSetting.name }),
    __metadata("design:type", bot_setting_entity_1.BotSetting)
], Bot.prototype, "botSetting", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: bot_flow_entity_1.BotFlow.name,
    }),
    __metadata("design:type", bot_flow_entity_1.BotFlow)
], Bot.prototype, "botFlow", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: tag_entity_1.Tag.name }],
        default: [],
    }),
    __metadata("design:type", Array)
], Bot.prototype, "tags", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Bot.prototype, "questionBank", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Bot.prototype, "saveUnansweredQuestions", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Advertisement',
    }),
    __metadata("design:type", String)
], Bot.prototype, "advertisement", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Offer',
    }),
    __metadata("design:type", String)
], Bot.prototype, "offer", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Bot.prototype, "showAdvertisement", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Bot.prototype, "showOffer", void 0);
Bot = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        toJSON: {
            virtuals: true,
        },
    })
], Bot);
exports.Bot = Bot;
exports.BotSchema = mongoose_1.SchemaFactory.createForClass(Bot);
//# sourceMappingURL=bot.entity.js.map