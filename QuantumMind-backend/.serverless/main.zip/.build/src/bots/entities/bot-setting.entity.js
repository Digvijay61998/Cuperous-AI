"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotSettingSchema = exports.BotSetting = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const bot_entity_1 = require("./bot.entity");
let BotSetting = class BotSetting {
};
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bot',
    }),
    __metadata("design:type", bot_entity_1.Bot)
], BotSetting.prototype, "botId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: ['all'],
    }),
    __metadata("design:type", Array)
], BotSetting.prototype, "domains", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: "Hi, Hope you're doing well. How can I help you?",
    }),
    __metadata("design:type", String)
], BotSetting.prototype, "welcomeMessages", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [],
    }),
    __metadata("design:type", Array)
], BotSetting.prototype, "blockedContent", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [],
    }),
    __metadata("design:type", Array)
], BotSetting.prototype, "blockedCountries", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], BotSetting.prototype, "askForFeedback", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], BotSetting.prototype, "getVisitorInfo", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], BotSetting.prototype, "typingIndicator", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], BotSetting.prototype, "storeVisitorInfoInCookies", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 'Sorry, I did not understand that. Please try again.',
    }),
    __metadata("design:type", String)
], BotSetting.prototype, "fallbackMessage", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 'Thank you for contacting us. Have a nice day.',
    }),
    __metadata("design:type", String)
], BotSetting.prototype, "thankyoumsg", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [
            {
                label: 'English',
                value: 'en',
            },
        ],
    }),
    __metadata("design:type", Array)
], BotSetting.prototype, "languages", void 0);
BotSetting = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
    })
], BotSetting);
exports.BotSetting = BotSetting;
exports.BotSettingSchema = mongoose_1.SchemaFactory.createForClass(BotSetting);
//# sourceMappingURL=bot-setting.entity.js.map