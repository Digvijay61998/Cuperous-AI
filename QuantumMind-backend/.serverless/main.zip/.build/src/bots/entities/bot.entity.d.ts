import * as mongoose from 'mongoose';
import { Agent } from 'src/agent/entities/agent.entity';
import { BotSetting } from './bot-setting.entity';
import { BotStyles } from './bot-styles.entity';
import { BotStatusEnum } from '../enums/bot-status.enum';
import { BotFlow } from './bot-flow.entity';
import { Tag } from 'src/tag/entities/tag.entity';
export type BotDocument = Bot & mongoose.Document;
export declare class Bot {
    name: string;
    agents: Agent[];
    status: BotStatusEnum;
    published: boolean;
    botId: string;
    botStyles: BotStyles;
    botSetting: BotSetting;
    botFlow: BotFlow;
    tags: Tag[];
    questionBank: boolean;
    saveUnansweredQuestions: boolean;
    advertisement: string;
    offer: string;
    showAdvertisement: boolean;
    showOffer: boolean;
}
export declare const BotSchema: mongoose.Schema<Bot, mongoose.Model<Bot, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Bot>;
