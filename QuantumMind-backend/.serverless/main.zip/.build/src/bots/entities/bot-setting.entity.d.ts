import * as mongoose from 'mongoose';
export type BotSettingDocument = BotSetting & mongoose.Document;
import { Bot } from './bot.entity';
export declare class BotSetting {
    botId: Bot;
    domains: string[];
    welcomeMessages: string;
    blockedContent: string[];
    blockedCountries: string[];
    askForFeedback: boolean;
    getVisitorInfo: boolean;
    typingIndicator: boolean;
    storeVisitorInfoInCookies: boolean;
    fallbackMessage: string;
    thankyoumsg: string;
    languages: any[];
}
export declare const BotSettingSchema: mongoose.Schema<BotSetting, mongoose.Model<BotSetting, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, BotSetting>;
