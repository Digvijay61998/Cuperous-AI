import * as mongoose from "mongoose";
export type BotFlowNodeDocument = BotFlowNode & mongoose.Document;
export interface BotPayload {
    webhookId?: string;
    segmentId?: string;
    ticketSubject?: string;
    blockId?: string;
    elements?: elements[];
    alias?: string;
    entity?: string;
    attributes?: [];
    eventField?: string;
    secure?: boolean;
}
interface elements {
    actionOnFailure?: string;
    alias?: string;
    entity?: string;
    lifespan?: number;
    prompt?: string;
    secure?: boolean;
}
export declare class BotFlowNode {
    id: string;
    nodeType: string;
    utterance: [string];
    next: [string];
    payload: BotPayload;
    keywords: [string];
    title: string;
    responses: [];
    botId: string;
}
export declare const BotFlowNodeSchema: mongoose.Schema<BotFlowNode, mongoose.Model<BotFlowNode, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, BotFlowNode>;
export {};
