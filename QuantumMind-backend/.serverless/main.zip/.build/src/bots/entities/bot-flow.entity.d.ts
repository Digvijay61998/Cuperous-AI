import * as mongoose from "mongoose";
import { Bot } from "./bot.entity";
export type BotFlowDocument = BotFlow & mongoose.Document;
export declare class BotFlow {
    botId: Bot;
    edges: [];
    nodes: [];
    startNode: string;
    customAttributes: any[];
}
export declare const BotFlowSchema: mongoose.Schema<BotFlow, mongoose.Model<BotFlow, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, BotFlow>;
