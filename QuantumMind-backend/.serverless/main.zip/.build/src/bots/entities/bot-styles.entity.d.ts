import * as mongoose from "mongoose";
export type BotStylesDocument = BotStyles & mongoose.Document;
export declare class BotStyles {
    botId: string;
    textColor: string;
    primaryColor: string;
    secondaryColor: string;
    avatar: string;
    widgetAvatar: string;
    headerTextColor: string;
    headerBackgroundColor: string;
    buttonColor: string;
    buttonTextColor: string;
    widgetPosition: string;
}
export declare const BotStylesSchema: mongoose.Schema<BotStyles, mongoose.Model<BotStyles, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, BotStyles>;
