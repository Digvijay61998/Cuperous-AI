/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { Model } from "mongoose";
import { CreateBotDto } from "./dto/create-bot.dto";
import { UpdateBotFlowDto } from "./dto/update-bot-flow.dto";
import { UpdateBotDto } from "./dto/update-bot.dto";
import { ConfigService } from "@nestjs/config";
import { AgentService } from "src/agent/agent.service";
import { SegmentsService } from "src/segments/segments.service";
import { WebhookService } from "src/webhook/webhook.service";
import { BotQueryParams } from "./dto/search-bot.dto";
import { BotDocument, BotFlowDocument, BotFlowNodeDocument, BotSettingDocument, BotStylesDocument } from "./entities";
import { TicketsService } from "src/tickets/tickets.service";
import { ConversationService } from "src/conversation/conversation.service";
import { ReportParamsDto } from "src/util/report-params.dto";
import { TagService } from "src/tag/tag.service";
export declare class BotsService {
    private readonly botModel;
    private readonly botStyleModel;
    private readonly botSettingModel;
    private readonly botFlowModel;
    private readonly botNodeModel;
    private readonly webhookService;
    private readonly segmentService;
    private readonly configService;
    private readonly agentService;
    private readonly ticketService;
    private readonly conversationService;
    private readonly tagsService;
    private readonly logger;
    constructor(botModel: Model<BotDocument>, botStyleModel: Model<BotStylesDocument>, botSettingModel: Model<BotSettingDocument>, botFlowModel: Model<BotFlowDocument>, botNodeModel: Model<BotFlowNodeDocument>, webhookService: WebhookService, segmentService: SegmentsService, configService: ConfigService, agentService: AgentService, ticketService: TicketsService, conversationService: ConversationService, tagsService: TagService);
    generateNodeAndEdegs(): {
        nodes: any[];
        edges: any[];
    };
    generateEdges(tree: any): any[];
    createNodes({ nodes, edges }: {
        nodes: any[];
        edges: any[];
    }): Promise<void>;
    botlist(): Promise<any[]>;
    create(createBotDto: CreateBotDto): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotById(id: string): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getAllBots(query?: BotQueryParams): Promise<Omit<Omit<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>, never>[]>;
    update(id: string, updateBotDto: UpdateBotDto): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotSettingById(id: string): Promise<import("./entities").BotSetting & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotStylesById(id: string): Promise<import("./entities").BotStyles & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotSetting(id: string, updateBotSettingDto: any): Promise<import("./entities").BotSetting & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotStyle(id: string, updateBotStyleDto: any): Promise<import("./entities").BotStyles & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotFlow(id: string): Promise<import("./entities").BotFlow & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotFlow(id: string, updateBotFlowDto: UpdateBotFlowDto): Promise<import("./entities").BotFlow & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateNode(id: string, updateNodeDto: any): Promise<import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotNodeForApi(id: string): Promise<{
        node: import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        };
        embed: {
            attributes: any;
            validationList: {
                value: import("src/message-handler/enums/user-input-validation.enums").UserInputValidationEnum;
                label: string;
            }[];
            customAttributes: any[];
            tags: {
                default: (import("../tag/entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
                    _id: import("mongoose").Types.ObjectId;
                })[];
                custom: (import("../tag/entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
                    _id: import("mongoose").Types.ObjectId;
                })[];
            };
        };
    }>;
    getBotNode(id: string): Promise<import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    assignAdvertisementToBots(bots: string[], advertisementId: string): Promise<any[]>;
    unassignAdvertisementFromBots(bots: string[]): Promise<void>;
    removeNode(id: string): Promise<import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    stats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getBotDataForWidget(id: string): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    totalBots(): Promise<any>;
    dayWisePerformance(query: ReportParamsDto): Promise<any[]>;
    dateWiseConversations(query: ReportParamsDto): Promise<any[]>;
    getLanguages(): Promise<any>;
}
