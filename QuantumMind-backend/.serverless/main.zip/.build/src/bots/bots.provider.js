"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.botsProviders = void 0;
const entities_1 = require("./entities");
const constants_1 = require("src/constants");
const constant_1 = require("./constant");
exports.botsProviders = [
    {
        provide: constant_1.BOTS_PROVIDER,
        useFactory: (connection) => connection.model(entities_1.Bot.name, entities_1.BotSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.BOTS_STYLE_PROVIDER,
        useFactory: (connection) => connection.model(entities_1.BotStyles.name, entities_1.BotStylesSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.BOTS_SETTING_PROVIDER,
        useFactory: (connection) => connection.model(entities_1.BotSetting.name, entities_1.BotSettingSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.BOTS_FLOW_PROVIDER,
        useFactory: (connection) => connection.model(entities_1.BotFlow.name, entities_1.BotFlowSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.BOTS_NODE_PROVIDER,
        useFactory: (connection) => connection.model(entities_1.BotFlowNode.name, entities_1.BotFlowNodeSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=bots.provider.js.map