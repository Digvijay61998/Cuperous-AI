"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const bots_service_1 = require("./bots.service");
const create_bot_dto_1 = require("./dto/create-bot.dto");
const search_bot_dto_1 = require("./dto/search-bot.dto");
const update_bot_dto_1 = require("./dto/update-bot.dto");
const report_params_dto_1 = require("src/util/report-params.dto");
let BotsController = class BotsController {
    constructor(botsService) {
        this.botsService = botsService;
    }
    async create(createBotDto) {
        return await this.botsService.create(createBotDto);
    }
    async getBots(query) {
        return await this.botsService.getAllBots(query);
    }
    async getBotsList() {
        return await this.botsService.botlist();
    }
    async getBotsStats() {
        return await this.botsService.stats();
    }
    async getLanguages() {
        return await this.botsService.getLanguages();
    }
    async totalReport() {
        return await this.botsService.totalBots();
    }
    async dayWisePerformanceReport(query) {
        return await this.botsService.dayWisePerformance(query);
    }
    async dateWisePerformanceReport(query) {
        return await this.botsService.dateWiseConversations(query);
    }
    async updateBot(id, body) {
        return await this.botsService.update(id, body);
    }
    async getBotById(id) {
        return await this.botsService.getBotById(id);
    }
    async getBotSetting(id) {
        return await this.botsService.getBotSettingById(id);
    }
    async updateBotSetting(id, body) {
        return await this.botsService.updateBotSetting(id, body);
    }
    async getBotStyle(id) {
        return await this.botsService.getBotStylesById(id);
    }
    async updateBotStyle(id, body) {
        return await this.botsService.updateBotStyle(id, body);
    }
    async getBotFlow(id) {
        return await this.botsService.getBotFlow(id);
    }
    async updateBotFlow(id, body) {
        return await this.botsService.updateBotFlow(id, body);
    }
    async deleteBot(id) {
        return await this.botsService.remove(id);
    }
    async getBotNodeForApi(id) {
        return await this.botsService.getBotNodeForApi(id);
    }
    async updateBotFlowNode(id, body) {
        return await this.botsService.updateNode(id, body);
    }
    async deleteBotFlowNode(id) {
        return await this.botsService.removeNode(id);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_bot_dto_1.CreateBotDto]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_bot_dto_1.BotQueryParams]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBots", null);
__decorate([
    (0, common_1.Get)('list'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotsList", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotsStats", null);
__decorate([
    (0, common_1.Get)('languages'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getLanguages", null);
__decorate([
    (0, common_1.Get)('report/total'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "totalReport", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/day-wise-performance'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "dayWisePerformanceReport", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-performance'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "dateWisePerformanceReport", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_bot_dto_1.UpdateBotDto]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "updateBot", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotById", null);
__decorate([
    (0, common_1.Get)(':id/setting'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotSetting", null);
__decorate([
    (0, common_1.Patch)(':id/setting'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "updateBotSetting", null);
__decorate([
    (0, common_1.Get)(':id/style'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotStyle", null);
__decorate([
    (0, common_1.Patch)(':id/style'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "updateBotStyle", null);
__decorate([
    (0, common_1.Get)(':id/flow'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotFlow", null);
__decorate([
    (0, common_1.Patch)(':id/flow'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "updateBotFlow", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "deleteBot", null);
__decorate([
    (0, common_1.Get)('flow/node/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "getBotNodeForApi", null);
__decorate([
    (0, common_1.Patch)('flow/node/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "updateBotFlowNode", null);
__decorate([
    (0, common_1.Delete)('flow/node/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotsController.prototype, "deleteBotFlowNode", null);
BotsController = __decorate([
    (0, common_1.Controller)('bots'),
    (0, swagger_1.ApiTags)('Bots'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [bots_service_1.BotsService])
], BotsController);
exports.BotsController = BotsController;
//# sourceMappingURL=bots.controller.js.map