/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { Connection } from 'mongoose';
import { Bot, BotSetting, BotStyles, BotFlow, BotFlowNode } from './entities';
export declare const botsProviders: ({
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<Bot, {}, {}, {}, import("mongoose").Schema<Bot, import("mongoose").Model<Bot, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Bot>>;
    inject: string[];
} | {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<BotStyles, {}, {}, {}, import("mongoose").Schema<BotStyles, import("mongoose").Model<BotStyles, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, BotStyles>>;
    inject: string[];
} | {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<BotSetting, {}, {}, {}, import("mongoose").Schema<BotSetting, import("mongoose").Model<BotSetting, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, BotSetting>>;
    inject: string[];
} | {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<BotFlow, {}, {}, {}, import("mongoose").Schema<BotFlow, import("mongoose").Model<BotFlow, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, BotFlow>>;
    inject: string[];
} | {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<BotFlowNode, {}, {}, {}, import("mongoose").Schema<BotFlowNode, import("mongoose").Model<BotFlowNode, any, any, any, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, BotFlowNode>>;
    inject: string[];
})[];
