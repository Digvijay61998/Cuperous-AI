export declare class BotsModule {
}
