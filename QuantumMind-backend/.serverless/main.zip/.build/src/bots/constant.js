"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOTS_NODE_PROVIDER = exports.BOTS_FLOW_PROVIDER = exports.BOTS_SETTING_PROVIDER = exports.BOTS_STYLE_PROVIDER = exports.BOTS_PROVIDER = void 0;
exports.BOTS_PROVIDER = 'BOTS_PROVIDER';
exports.BOTS_STYLE_PROVIDER = 'BOTS_STYLE_PROVIDER';
exports.BOTS_SETTING_PROVIDER = 'BOTS_SETTING_PROVIDER';
exports.BOTS_FLOW_PROVIDER = 'BOTS_FLOW_PROVIDER';
exports.BOTS_NODE_PROVIDER = 'BOTS_NODE_PROVIDER';
//# sourceMappingURL=constant.js.map