export declare class CreateBotDto {
    name: string;
    primaryColor: string;
    agents: [string];
    tags: [string];
}
