import { ObjectId } from 'mongoose';
export declare class BotQueryParams {
    skip?: number;
    limit?: number;
    status?: string;
    tags?: ObjectId[];
}
