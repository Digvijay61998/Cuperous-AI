export declare class UpdateBotFlowDto {
    edges: [];
    nodes: [];
    customAttributes?: any[];
}
