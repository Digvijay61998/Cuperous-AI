/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { BotsService } from './bots.service';
import { CreateBotDto } from './dto/create-bot.dto';
import { BotQueryParams } from './dto/search-bot.dto';
import { UpdateBotDto } from './dto/update-bot.dto';
import { ReportParamsDto } from 'src/util/report-params.dto';
export declare class BotsController {
    private readonly botsService;
    constructor(botsService: BotsService);
    create(createBotDto: CreateBotDto): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBots(query: BotQueryParams): Promise<Omit<Omit<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>, never>[]>;
    getBotsList(): Promise<any[]>;
    getBotsStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getLanguages(): Promise<any>;
    totalReport(): Promise<any>;
    dayWisePerformanceReport(query: ReportParamsDto): Promise<any[]>;
    dateWisePerformanceReport(query: ReportParamsDto): Promise<any[]>;
    updateBot(id: string, body: UpdateBotDto): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotById(id: string): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotSetting(id: string): Promise<import("./entities").BotSetting & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotSetting(id: string, body: any): Promise<import("./entities").BotSetting & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotStyle(id: string): Promise<import("./entities").BotStyles & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotStyle(id: string, body: any): Promise<import("./entities").BotStyles & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotFlow(id: string): Promise<import("./entities").BotFlow & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateBotFlow(id: string, body: any): Promise<import("./entities").BotFlow & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    deleteBot(id: string): Promise<import("./entities").Bot & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getBotNodeForApi(id: string): Promise<{
        node: import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        };
        embed: {
            attributes: any;
            validationList: {
                value: import("../message-handler/enums/user-input-validation.enums").UserInputValidationEnum;
                label: string;
            }[];
            customAttributes: any[];
            tags: {
                default: (import("../tag/entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
                    _id: import("mongoose").Types.ObjectId;
                })[];
                custom: (import("../tag/entities/tag.entity").Tag & import("mongoose").Document<any, any, any> & {
                    _id: import("mongoose").Types.ObjectId;
                })[];
            };
        };
    }>;
    updateBotFlowNode(id: string, body: any): Promise<import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    deleteBotFlowNode(id: string): Promise<import("./entities").BotFlowNode & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
