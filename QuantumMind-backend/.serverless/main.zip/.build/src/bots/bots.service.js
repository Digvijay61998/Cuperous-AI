"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const constant_1 = require("./constant");
const config_1 = require("@nestjs/config");
const agent_service_1 = require("src/agent/agent.service");
const user_input_validation_enums_1 = require("src/message-handler/enums/user-input-validation.enums");
const segments_service_1 = require("src/segments/segments.service");
const util_1 = require("src/util");
const webhook_service_1 = require("src/webhook/webhook.service");
const defaultNodes_1 = require("./defaultNodes");
const bot_status_enum_1 = require("./enums/bot-status.enum");
const node_type_enum_1 = require("./enums/node-type.enum");
const tickets_service_1 = require("src/tickets/tickets.service");
const conversation_service_1 = require("src/conversation/conversation.service");
const get_subtitle_1 = require("src/util/get-subtitle");
const ticket_priority_1 = require("src/tickets/enums/ticket-priority");
const tag_service_1 = require("src/tag/tag.service");
let BotsService = BotsService_1 = class BotsService {
    constructor(botModel, botStyleModel, botSettingModel, botFlowModel, botNodeModel, webhookService, segmentService, configService, agentService, ticketService, conversationService, tagsService) {
        this.botModel = botModel;
        this.botStyleModel = botStyleModel;
        this.botSettingModel = botSettingModel;
        this.botFlowModel = botFlowModel;
        this.botNodeModel = botNodeModel;
        this.webhookService = webhookService;
        this.segmentService = segmentService;
        this.configService = configService;
        this.agentService = agentService;
        this.ticketService = ticketService;
        this.conversationService = conversationService;
        this.tagsService = tagsService;
        this.logger = new common_1.Logger(BotsService_1.name);
    }
    generateNodeAndEdegs() {
        const nodes = defaultNodes_1.defaultNodes.nodes.map((node) => {
            return Object.assign(Object.assign({}, node), { id: (0, util_1.generateId)("node", 15), title: node.data.title });
        });
        const tree = [
            {
                source: nodes[0],
                target: nodes[1],
                children: [],
            },
            {
                source: nodes[0],
                target: nodes[2],
                children: [
                    {
                        source: nodes[2],
                        target: nodes[3],
                        children: [],
                    },
                ],
            },
        ];
        const edges = this.generateEdges(tree);
        return { nodes, edges };
    }
    generateEdges(tree) {
        const edges = [];
        const traverse = (node) => {
            node.forEach((child) => {
                edges.push({
                    id: (0, util_1.generateId)("edge", 15),
                    source: child.source.id,
                    target: child.target.id,
                });
                if (child.children.length) {
                    traverse(child.children);
                }
            });
        };
        traverse(tree);
        return edges;
    }
    async createNodes({ nodes, edges }) {
        const edgesList = edges.reduce((acc, edge) => {
            acc[edge.source] = acc[edge.source] || [];
            acc[edge.source].push(edge.target);
            return acc;
        }, {});
        await Promise.all(nodes.map(async (node) => {
            const checkNode = await this.botNodeModel.findOne({ id: node.id });
            if (!checkNode) {
                await this.botNodeModel.create(Object.assign(Object.assign({}, node), { next: edgesList[node.id] || [] }));
            }
            else {
                const lastNodes = checkNode.next;
                checkNode.next = edgesList[node.id] || [];
                checkNode.title = node.data.title;
                await checkNode.save();
                await Promise.all(lastNodes.map(async (lastNode) => {
                    const checkLastNode = await this.botNodeModel.findOne({
                        next: { $in: [lastNode] },
                    });
                    if (!checkLastNode) {
                        await this.botNodeModel.deleteOne({ id: lastNode });
                    }
                }));
            }
        }));
    }
    async botlist() {
        return await this.botModel.aggregate([
            {
                $match: {
                    _id: { $ne: null },
                },
            },
            {
                $project: {
                    name: 1,
                    id: "$_id",
                    _id: 0,
                },
            },
        ]);
    }
    async create(createBotDto) {
        try {
            this.logger.log(`Creating bot ${createBotDto.name}`);
            const bot = await this.botModel.create(Object.assign({}, createBotDto));
            const botStyle = await this.botStyleModel.create({
                botId: bot._id,
                primaryColor: createBotDto.primaryColor,
            });
            const botSetting = await this.botSettingModel.create({
                botId: bot._id,
            });
            const { nodes, edges } = this.generateNodeAndEdegs();
            await this.createNodes({ nodes, edges });
            const botFlow = await this.botFlowModel.create({
                botId: bot._id,
                nodes,
                edges,
                startNode: nodes.filter((node) => node.nodeType === node_type_enum_1.NodeTypeEnum.START_NODE)[0].id,
            });
            bot.botFlow = botFlow._id;
            bot.botStyles = botStyle._id;
            bot.botSetting = botSetting._id;
            if (createBotDto.agents) {
                await this.agentService.addBotToAgent(bot._id, createBotDto.agents);
            }
            await bot.save();
            return bot;
        }
        catch (error) {
            this.logger.error(`Error in create bot: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotById(id) {
        try {
            const bot = await this.botModel
                .findOne({
                $or: [{ _id: id }, { botId: id }],
            })
                .populate("agents", "name")
                .populate("botStyles")
                .populate("botFlow")
                .populate("botSetting");
            if (!bot) {
                throw new common_1.HttpException("No Bot Found by this Id", 404);
            }
            return bot;
        }
        catch (error) {
            this.logger.error(`Error in get bot by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getAllBots(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, tags, status, } = query;
            const queryObject = {};
            if (status)
                queryObject["status"] = status;
            if (tags)
                queryObject["tags"] = { $in: tags };
            const agents = this.botModel
                .find(queryObject)
                .populate("tags", "name")
                .populate("agents", "name")
                .sort({ createdAt: -1 })
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                agents.limit(limitOfDocuments);
            }
            const data = await agents;
            return data;
        }
        catch (error) {
            this.logger.error(`Error in get all bots: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async update(id, updateBotDto) {
        try {
            const bot = await this.botModel.findOneAndUpdate({ _id: id }, updateBotDto, { new: true });
            if (updateBotDto.agents) {
                await this.agentService.addBotToAgent(bot._id, updateBotDto.agents);
            }
            if (!bot) {
                throw new common_1.HttpException("No Bot Found by this Id", 404);
            }
            return bot;
        }
        catch (error) {
            this.logger.error(`Error in update bot: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async remove(id) {
        try {
            const bot = await this.botModel.findOne({
                _id: id,
            });
            if (!bot) {
                throw new common_1.HttpException("No Bot Found by this Id", 404);
            }
            bot.status = bot_status_enum_1.BotStatusEnum.DELETED;
            await bot.save();
            return bot;
        }
        catch (error) {
            this.logger.error(`Error in delete bot: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotSettingById(id) {
        try {
            const botSetting = await this.botSettingModel.findOne({ botId: id });
            if (!botSetting) {
                throw new common_1.HttpException("No Bot setting Found by this Id", 404);
            }
            return botSetting;
        }
        catch (error) {
            this.logger.error(`Error in get bot setting by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotStylesById(id) {
        try {
            const botStyles = await this.botStyleModel.findOne({ botId: id });
            if (!botStyles) {
                throw new common_1.HttpException("No Bot Styles Found by this Id", 404);
            }
            return botStyles;
        }
        catch (error) {
            this.logger.error(`Error in get bot styles by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateBotSetting(id, updateBotSettingDto) {
        try {
            const botSetting = await this.botSettingModel.findOneAndUpdate({ botId: id }, updateBotSettingDto, { new: true });
            if (!botSetting) {
                throw new common_1.HttpException("No Bot setting Found by this Id", 404);
            }
            return botSetting;
        }
        catch (error) {
            this.logger.error(`Error in update bot setting: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateBotStyle(id, updateBotStyleDto) {
        try {
            const botStyle = await this.botStyleModel.findOneAndUpdate({ botId: id }, updateBotStyleDto, { new: true });
            if (!botStyle) {
                throw new common_1.HttpException("No Bot style Found by this Id", 404);
            }
            return botStyle;
        }
        catch (error) {
            this.logger.error(`Error in update bot style: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotFlow(id) {
        try {
            const botFlow = await this.botFlowModel.findOne({ botId: id });
            if (!botFlow) {
                throw new common_1.HttpException("No Bot Flow Found by this Id", 404);
            }
            return botFlow;
        }
        catch (error) {
            this.logger.error(`Error in get bot flow by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateBotFlow(id, updateBotFlowDto) {
        try {
            const botFlow = await this.botFlowModel.findOneAndUpdate({ botId: id }, updateBotFlowDto, { new: true });
            if (!botFlow) {
                throw new common_1.HttpException("No Bot Flow Found by this Id", 404);
            }
            await this.createNodes(updateBotFlowDto);
            return botFlow;
        }
        catch (error) {
            this.logger.error(`Error in update bot flow: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateNode(id, updateNodeDto) {
        try {
            const node = await this.botNodeModel.findOneAndUpdate({
                id,
            }, updateNodeDto, { new: true });
            if (!node) {
                throw new common_1.HttpException("No Node Found by this Id", 404);
            }
            return node;
        }
        catch (error) {
            this.logger.error(`Error in update node: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotNodeForApi(id) {
        try {
            const node = await this.botNodeModel.findOne({ id });
            if (!node) {
                throw new common_1.HttpException("No Node Found by this Id", 404);
            }
            const tags = await this.tagsService.getTagList();
            let customAttributes = [];
            if (node.botId) {
                const botFlow = await this.botFlowModel.findOne({ botId: node.botId });
                customAttributes = botFlow.customAttributes;
            }
            const embed = {
                attributes: this.configService.get("attributesList"),
                validationList: user_input_validation_enums_1.ValidationInputList,
                customAttributes,
                tags: tags,
            };
            if (node.nodeType === node_type_enum_1.NodeTypeEnum.WEBHOOK) {
                const webhooks = await this.webhookService.getWebhooksListForNode();
                embed["webhooks"] = webhooks;
            }
            if (node.nodeType === node_type_enum_1.NodeTypeEnum.TICKET) {
                embed["priorities"] = ticket_priority_1.TicketPriorityEnumList;
            }
            if (node.nodeType === node_type_enum_1.NodeTypeEnum.ADD_TO_SEGMENT ||
                node.nodeType === node_type_enum_1.NodeTypeEnum.REMOVE_FROM_SEGMENT) {
                const segments = await this.segmentService.getSegmentsForNode();
                embed["segments"] = segments;
            }
            return { node, embed };
        }
        catch (error) {
            this.logger.error(`Error in get node by id: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getBotNode(id) {
        if (!id) {
            return;
        }
        const node = await this.botNodeModel.findOne({ id });
        if (!node) {
            throw new common_1.HttpException("No Node Found by this Id", 404);
        }
        return node;
    }
    async assignAdvertisementToBots(bots, advertisementId) {
        const error = [];
        await Promise.all(bots.map(async (botId) => {
            const bot = await this.botModel.findOne({ id: botId });
            if (bot) {
                if (bot.advertisement !== advertisementId) {
                    error.push({
                        botId,
                        name: bot.name,
                    });
                }
                else {
                    bot.advertisement = advertisementId;
                    await bot.save();
                }
            }
        }));
        return error;
    }
    async unassignAdvertisementFromBots(bots) {
        try {
            await this.botModel.updateMany({ id: { $in: bots } }, { $unset: { advertisement: "" } });
        }
        catch (error) {
            this.logger.error(`Error in unassign advertisement from bots: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async removeNode(id) {
        try {
            const node = await this.botNodeModel.findOneAndDelete({ id });
            if (!node) {
                throw new common_1.HttpException("No Node Found by this Id", 404);
            }
            return node;
        }
        catch (error) {
            this.logger.error(`Error in delete node: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.botModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.botFlowModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - 60)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Bots",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "bot",
        };
    }
    async stats() {
        const result = await Promise.all([
            this.getTotalCount(),
            this.conversationService.getTotalCount(),
            this.ticketService.getTotalCount(),
        ]);
        return result;
    }
    async getBotDataForWidget(id) {
        try {
            const bot = await this.botModel
                .findOne({ _id: id })
                .populate("botSetting", "-_id -botId -createdAt -updatedAt -__v")
                .populate("botStyles", "-_id -botId -createdAt -updatedAt -__v")
                .populate("advertisement", "title posters")
                .populate("offer", "title cards")
                .populate("botFlow", "startNode")
                .select(" -createdAt -updatedAt -__v ");
            if (!bot) {
                throw new common_1.HttpException("No Bot Found by this Id", 404);
            }
            return bot;
        }
        catch (error) {
            this.logger.error(`Error in get bot data for widget: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async totalBots() {
        try {
            const result = await this.botModel.aggregate([
                {
                    $facet: {
                        total: [
                            {
                                $count: "total",
                            },
                        ],
                        active: [
                            {
                                $match: {
                                    status: bot_status_enum_1.BotStatusEnum.ACTIVE,
                                },
                            },
                            {
                                $count: "active",
                            },
                        ],
                        suspended: [
                            {
                                $match: {
                                    status: bot_status_enum_1.BotStatusEnum.SUSPENDED,
                                },
                            },
                            {
                                $count: "suspended",
                            },
                        ],
                        deleted: [
                            {
                                $match: {
                                    status: bot_status_enum_1.BotStatusEnum.DELETED,
                                },
                            },
                            {
                                $count: "deleted",
                            },
                        ],
                    },
                },
                {
                    $project: {
                        total: {
                            $arrayElemAt: ["$total.total", 0],
                        },
                        active: {
                            $arrayElemAt: ["$active.active", 0],
                        },
                        suspended: {
                            $arrayElemAt: ["$suspended.suspended", 0] || 0,
                        },
                        deleted: {
                            $arrayElemAt: ["$deleted.deleted", 0],
                        },
                    },
                },
            ]);
            return result[0];
        }
        catch (error) {
            this.logger.error(`Error in get bot data for widget: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async dayWisePerformance(query) {
        return await this.conversationService.getDayWisePerformance(query);
    }
    async dateWiseConversations(query) {
        return await this.conversationService.getDateWiseConversations(query);
    }
    async getLanguages() {
        return this.configService.get("languages");
    }
};
BotsService = BotsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.BOTS_PROVIDER)),
    __param(1, (0, common_1.Inject)(constant_1.BOTS_STYLE_PROVIDER)),
    __param(2, (0, common_1.Inject)(constant_1.BOTS_SETTING_PROVIDER)),
    __param(3, (0, common_1.Inject)(constant_1.BOTS_FLOW_PROVIDER)),
    __param(4, (0, common_1.Inject)(constant_1.BOTS_NODE_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        mongoose_1.Model,
        mongoose_1.Model,
        mongoose_1.Model,
        mongoose_1.Model,
        webhook_service_1.WebhookService,
        segments_service_1.SegmentsService,
        config_1.ConfigService,
        agent_service_1.AgentService,
        tickets_service_1.TicketsService,
        conversation_service_1.ConversationService,
        tag_service_1.TagService])
], BotsService);
exports.BotsService = BotsService;
//# sourceMappingURL=bots.service.js.map