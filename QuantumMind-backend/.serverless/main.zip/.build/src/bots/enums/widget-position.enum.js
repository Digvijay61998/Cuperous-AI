"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WidgetPosition = void 0;
exports.WidgetPosition = {
    LEFT: "left",
    RIGHT: "right",
};
//# sourceMappingURL=widget-position.enum.js.map