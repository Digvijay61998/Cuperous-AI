"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotStatusEnum = void 0;
var BotStatusEnum;
(function (BotStatusEnum) {
    BotStatusEnum["ACTIVE"] = "active";
    BotStatusEnum["SUSPENDED"] = "suspended";
    BotStatusEnum["DELETED"] = "deleted";
})(BotStatusEnum = exports.BotStatusEnum || (exports.BotStatusEnum = {}));
//# sourceMappingURL=bot-status.enum.js.map