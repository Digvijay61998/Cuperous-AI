export declare enum BotStatusEnum {
    ACTIVE = "active",
    SUSPENDED = "suspended",
    DELETED = "deleted"
}
