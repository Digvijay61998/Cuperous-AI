"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NodeTypeEnum = void 0;
var NodeTypeEnum;
(function (NodeTypeEnum) {
    NodeTypeEnum["START_NODE"] = "START_NODE";
    NodeTypeEnum["USER_INPUT"] = "USER_INPUT";
    NodeTypeEnum["BOT_RESPONSE"] = "BOT_RESPONSE";
    NodeTypeEnum["TICKET"] = "TICKET";
    NodeTypeEnum["SET_ATTRIBUTES"] = "SET_ATTRIBUTES";
    NodeTypeEnum["CLOSE_CHAT"] = "CLOSE_CHAT";
    NodeTypeEnum["FILE_ATTACHMENT"] = "FILE_ATTACHMENT";
    NodeTypeEnum["QUESTIONS"] = "QUESTIONS";
    NodeTypeEnum["FAQ"] = "FAQ";
    NodeTypeEnum["WEBHOOK"] = "WEBHOOK";
    NodeTypeEnum["ADD_TO_SEGMENT"] = "ADD_TO_SEGMENT";
    NodeTypeEnum["REMOVE_FROM_SEGMENT"] = "REMOVE_FROM_SEGMENT";
    NodeTypeEnum["TRANSFER_TO_AGENT"] = "TRANSFER_TO_AGENT";
    NodeTypeEnum["GO_TO_STEP"] = "GO_TO_STEP";
    NodeTypeEnum["FALL_BACK"] = "FALL_BACK";
    NodeTypeEnum["SUCCESS"] = "SUCCESS";
    NodeTypeEnum["FAILURE"] = "FAILURE";
})(NodeTypeEnum = exports.NodeTypeEnum || (exports.NodeTypeEnum = {}));
//# sourceMappingURL=node-type.enum.js.map