export declare const WidgetPosition: {
    readonly LEFT: "left";
    readonly RIGHT: "right";
};
