"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var UnansweredService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnansweredService = void 0;
const common_1 = require("@nestjs/common");
const json2csv_1 = require("json2csv");
const mongoose_1 = require("mongoose");
const constants_1 = require("./constants");
const moment_1 = __importDefault(require("moment"));
let UnansweredService = UnansweredService_1 = class UnansweredService {
    constructor(unansweredModel, unansweredQuestionModel) {
        this.unansweredModel = unansweredModel;
        this.unansweredQuestionModel = unansweredQuestionModel;
        this.logger = new common_1.Logger(UnansweredService_1.name);
    }
    async create(unanswered) {
        let unansweredQuestions = await this.unansweredModel.findOne({
            botId: unanswered.botId,
        });
        if (!unansweredQuestions) {
            unansweredQuestions = await this.unansweredModel.create({
                botId: unanswered.botId,
            });
        }
        const questions = await this.unansweredQuestionModel.create(Object.assign(Object.assign({}, unanswered.questions), { time: new Date(), botid: unanswered.botId }));
        unansweredQuestions.questions.push(questions.id);
        return await unansweredQuestions.save();
    }
    async findOne(botId) {
        const questions = await this.unansweredModel
            .findOne({
            botId: botId,
        })
            .populate({
            path: 'questions',
            populate: {
                path: 'askedBy',
                select: 'name email -_id',
            },
            select: 'question time askedBy id',
        });
        if (!questions) {
            return {
                botId: botId,
                questions: [],
            };
        }
        return questions;
    }
    async removeQuestion(questionId) {
        try {
            const question = await this.unansweredQuestionModel.deleteOne({
                _id: questionId,
            });
            if (!question) {
                throw new common_1.HttpException('Question not found', 404);
            }
            return question;
        }
        catch (error) {
            throw new common_1.HttpException(error.message, 500);
        }
    }
    async getAllQuestionsInCSV(res, botId) {
        try {
            const questions = await this.unansweredQuestionModel
                .find({
                botid: botId,
            })
                .populate('askedBy', 'name email ')
                .select('question time askedBy');
            const rows = questions.map((question) => {
                var _a, _b;
                return {
                    question: question.question,
                    time: question.time,
                    visitor_name: ((_a = question.askedBy) === null || _a === void 0 ? void 0 : _a.name) || '',
                    visitor_email: ((_b = question.askedBy) === null || _b === void 0 ? void 0 : _b.email) || '',
                };
            });
            const fields = ['question', 'time', 'visitor_name', 'visitor_email'];
            const opts = { fields };
            const parser = new json2csv_1.Parser(opts);
            const csv = parser.parse(rows);
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', 'attachment; filename=questions.csv');
            res.status(200).send(csv);
        }
        catch (error) {
            this.logger.error(`Error in getAllQuestionsInCSV: ${error.message}`);
            throw new common_1.HttpException(error.message, 500);
        }
    }
    async homeQuestionCount(filter) {
        if (!filter)
            filter = 'day';
        try {
            const total = await this.unansweredModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().startOf(filter).toISOString()),
                },
            });
            let percentageChange = 0;
            const previousTotal = await this.unansweredModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().subtract(1, filter).startOf(filter).toISOString()),
                },
            });
            if (previousTotal) {
                percentageChange = Math.round(((total - previousTotal) / previousTotal) * 100);
            }
            return {
                stats: total,
                trendNumber: Math.abs(percentageChange),
                trend: percentageChange > 0 ? 'positive' : 'negative',
                title: 'Total Unanswered',
                type: 'service_request',
            };
        }
        catch (error) {
            this.logger.error(`Error while getting home  count ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
UnansweredService = UnansweredService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.UNANSWERED_PROVIDER_MODEL)),
    __param(1, (0, common_1.Inject)(constants_1.UNANSWERED_QUESTION_MODEL)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        mongoose_1.Model])
], UnansweredService);
exports.UnansweredService = UnansweredService;
//# sourceMappingURL=unanswered.service.js.map