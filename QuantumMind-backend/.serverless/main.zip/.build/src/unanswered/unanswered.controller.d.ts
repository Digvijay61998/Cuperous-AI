import { CreateUnansweredDto } from './dto/create-unanswered.dto';
import { UnansweredService } from './unanswered.service';
import { Response } from 'express';
import { QueryParamDto } from './dto/query-param.dto';
export declare class UnansweredController {
    private readonly unansweredService;
    constructor(unansweredService: UnansweredService);
    create(createUnansweredDto: CreateUnansweredDto): Promise<any>;
    getHomeStats(time: string): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
    download(res: Response, query: QueryParamDto): Promise<void>;
    findByBotId(botId: string): Promise<any>;
    delete(questionId: string): Promise<import("mongodb").DeleteResult>;
}
