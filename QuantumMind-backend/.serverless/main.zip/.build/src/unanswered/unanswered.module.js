"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnansweredModule = void 0;
const common_1 = require("@nestjs/common");
const unanswered_service_1 = require("./unanswered.service");
const unanswered_controller_1 = require("./unanswered.controller");
const unanswered_provider_1 = require("./unanswered.provider");
let UnansweredModule = class UnansweredModule {
};
UnansweredModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        controllers: [unanswered_controller_1.UnansweredController],
        providers: [unanswered_service_1.UnansweredService, ...unanswered_provider_1.UnansweredProvider],
        exports: [unanswered_service_1.UnansweredService],
    })
], UnansweredModule);
exports.UnansweredModule = UnansweredModule;
//# sourceMappingURL=unanswered.module.js.map