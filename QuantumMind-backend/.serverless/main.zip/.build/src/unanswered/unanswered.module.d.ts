export declare class UnansweredModule {
}
