"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnansweredProvider = void 0;
const unanswered_entity_1 = require("./entities/unanswered.entity");
const constants_1 = require("src/constants");
const constants_2 = require("./constants");
const unanswered_question_entity_1 = require("./entities/unanswered-question.entity");
exports.UnansweredProvider = [
    {
        provide: constants_2.UNANSWERED_PROVIDER_MODEL,
        useFactory: (connection) => connection.model(unanswered_entity_1.Unanswered.name, unanswered_entity_1.UnansweredSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constants_2.UNANSWERED_QUESTION_MODEL,
        useFactory: (connection) => connection.model(unanswered_question_entity_1.UnansweredQuestion.name, unanswered_question_entity_1.UnansweredQuestionSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=unanswered.provider.js.map