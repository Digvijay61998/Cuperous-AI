import { Provider } from '@nestjs/common';
export declare const UnansweredProvider: Provider[];
