"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UNANSWERED_QUESTION_MODEL = exports.UNANSWERED_PROVIDER_MODEL = void 0;
exports.UNANSWERED_PROVIDER_MODEL = 'UNANSWERED_PROVIDER_MODEL';
exports.UNANSWERED_QUESTION_MODEL = 'UNANSWERED_QUESTION_MODE';
//# sourceMappingURL=constants.js.map