import { Logger } from '@nestjs/common';
import { Response } from 'express';
import { Model } from 'mongoose';
import { CreateUnansweredDto } from './dto/create-unanswered.dto';
import { UnansweredQuestionDocument } from './entities/unanswered-question.entity';
import { UnansweredDocument } from './entities/unanswered.entity';
export declare class UnansweredService {
    private readonly unansweredModel;
    private readonly unansweredQuestionModel;
    readonly logger: Logger;
    constructor(unansweredModel: Model<UnansweredDocument>, unansweredQuestionModel: Model<UnansweredQuestionDocument>);
    create(unanswered: CreateUnansweredDto): Promise<any>;
    findOne(botId: string): Promise<any>;
    removeQuestion(questionId: string): Promise<import("mongodb").DeleteResult>;
    getAllQuestionsInCSV(res: Response, botId?: string): Promise<void>;
    homeQuestionCount(filter: any): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
}
