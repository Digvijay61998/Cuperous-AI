export declare class QueryParamDto {
    botId: string;
}
