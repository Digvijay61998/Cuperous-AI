declare class QuestionsDto {
    question: string;
    askedBy: string;
    time: Date;
}
export declare class CreateUnansweredDto {
    botId: string;
    questions: QuestionsDto;
}
export {};
