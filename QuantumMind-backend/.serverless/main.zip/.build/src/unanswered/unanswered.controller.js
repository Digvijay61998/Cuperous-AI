"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnansweredController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const create_unanswered_dto_1 = require("./dto/create-unanswered.dto");
const unanswered_service_1 = require("./unanswered.service");
const query_param_dto_1 = require("./dto/query-param.dto");
let UnansweredController = class UnansweredController {
    constructor(unansweredService) {
        this.unansweredService = unansweredService;
    }
    async create(createUnansweredDto) {
        return await this.unansweredService.create(createUnansweredDto);
    }
    async getHomeStats(time) {
        return await this.unansweredService.homeQuestionCount(time);
    }
    async download(res, query) {
        return await this.unansweredService.getAllQuestionsInCSV(res, query.botId);
    }
    async findByBotId(botId) {
        return await this.unansweredService.findOne(botId);
    }
    async delete(questionId) {
        return await this.unansweredService.removeQuestion(questionId);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_unanswered_dto_1.CreateUnansweredDto]),
    __metadata("design:returntype", Promise)
], UnansweredController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('stats/home'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)('time')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UnansweredController.prototype, "getHomeStats", null);
__decorate([
    (0, common_1.Get)('download'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, query_param_dto_1.QueryParamDto]),
    __metadata("design:returntype", Promise)
], UnansweredController.prototype, "download", null);
__decorate([
    (0, common_1.Get)(':botId'),
    __param(0, (0, common_1.Param)('botId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UnansweredController.prototype, "findByBotId", null);
__decorate([
    (0, common_1.Delete)(':questionId'),
    __param(0, (0, common_1.Param)('questionId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UnansweredController.prototype, "delete", null);
UnansweredController = __decorate([
    (0, common_1.Controller)('unanswered'),
    (0, swagger_1.ApiTags)('Unanswered Questions'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [unanswered_service_1.UnansweredService])
], UnansweredController);
exports.UnansweredController = UnansweredController;
//# sourceMappingURL=unanswered.controller.js.map