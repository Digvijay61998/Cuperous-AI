import mongoose, { Document } from 'mongoose';
import { UnansweredQuestionDocument } from './unanswered-question.entity';
export interface Questions {
    question: string;
    askedBy: string;
    time: Date;
}
export declare class Unanswered {
    questions: UnansweredQuestionDocument[];
    botId: string;
}
export type UnansweredDocument = Unanswered & Document;
export declare const UnansweredSchema: mongoose.Schema<Unanswered, mongoose.Model<Unanswered, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Unanswered>;
