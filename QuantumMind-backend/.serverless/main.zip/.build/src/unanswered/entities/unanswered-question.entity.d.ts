import { Visitor } from 'src/visitor/entities/visitor.entity';
import * as mongoose from 'mongoose';
export declare class UnansweredQuestion {
    question: string;
    askedBy: Visitor;
    time: Date;
    botid: string;
}
export declare const UnansweredQuestionSchema: mongoose.Schema<UnansweredQuestion, mongoose.Model<UnansweredQuestion, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, UnansweredQuestion>;
export type UnansweredQuestionDocument = mongoose.Document & UnansweredQuestion;
