import { AgentService } from 'src/agent/agent.service';
import { TokenService } from 'src/token/token.service';
import { LoginDto } from './dto/login.dto';
export interface AuthResponse {
    accessToken: string;
    refreshToken?: string;
}
export declare class AuthService {
    private readonly tokenService;
    private readonly agentService;
    constructor(tokenService: TokenService, agentService: AgentService);
    validateUser(loginDto: LoginDto): Promise<AuthResponse>;
    refreshToken(body: {
        token: string;
    }): Promise<AuthResponse>;
}
