"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthRole = void 0;
var AuthRole;
(function (AuthRole) {
    AuthRole["ADMIN"] = "admin";
    AuthRole["AGENT"] = "agent";
})(AuthRole = exports.AuthRole || (exports.AuthRole = {}));
//# sourceMappingURL=role.enum.js.map