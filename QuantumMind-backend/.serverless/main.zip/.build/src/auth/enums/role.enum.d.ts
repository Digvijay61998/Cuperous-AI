export declare enum AuthRole {
    ADMIN = "admin",
    AGENT = "agent"
}
