"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const agent_service_1 = require("src/agent/agent.service");
const token_service_1 = require("src/token/token.service");
let AuthService = class AuthService {
    constructor(tokenService, agentService) {
        this.tokenService = tokenService;
        this.agentService = agentService;
    }
    async validateUser(loginDto) {
        try {
            const user = await this.agentService.authenticateAgent(loginDto.email, loginDto.password);
            if (!user) {
                throw new common_1.HttpException('Invalid credentials', 400);
            }
            const accessToken = await this.tokenService.sign({
                sub: user._id,
                _id: user._id,
                role: user.role,
                email: user.email,
            });
            const refreshToken = await this.tokenService.createRefreshToken({
                _id: user._id,
                email: user.email,
                role: user.role,
            });
            return {
                accessToken,
                refreshToken,
            };
        }
        catch (error) {
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async refreshToken(body) {
        try {
            const { token } = body;
            const accessToken = await this.tokenService.refreshAccessToken(token);
            if (!accessToken)
                throw new common_1.HttpException('Invalid refresh token', 400);
            return {
                accessToken,
                refreshToken: token,
            };
        }
        catch (error) {
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [token_service_1.TokenService,
        agent_service_1.AgentService])
], AuthService);
exports.AuthService = AuthService;
//# sourceMappingURL=auth.service.js.map