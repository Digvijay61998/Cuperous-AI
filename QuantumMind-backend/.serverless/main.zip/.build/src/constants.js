"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.API_KEY_PROVIDER = exports.TOKEN_PROVIDER = exports.CHATBOT_PROVIDER = exports.MESSAGE_PROVIDER = exports.CHAT_PROVIDER = exports.AGENT_PROVIDER = exports.VISITOR_PROVIDER = exports.ADMIN_PROVIDER = exports.DATABASE_PROVIDER = void 0;
exports.DATABASE_PROVIDER = 'DATABASE_CONNECTION';
exports.ADMIN_PROVIDER = 'ADMIN_MODEL';
exports.VISITOR_PROVIDER = 'VISITOR_MODEL';
exports.AGENT_PROVIDER = 'AGENT_MODEL';
exports.CHAT_PROVIDER = 'CHAT_MODEL';
exports.MESSAGE_PROVIDER = 'MESSAGE_MODEL';
exports.CHATBOT_PROVIDER = 'CHATBOT_MODEL';
exports.TOKEN_PROVIDER = 'TOKEN_MODEL';
exports.API_KEY_PROVIDER = 'API_KEY_MODEL';
//# sourceMappingURL=constants.js.map