/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { Model } from "mongoose";
import { CreateChatDto } from "./dto/create-chat.dto";
import { CreateConversationDto } from "./dto/create-conversation.dto";
import { ChatDocument } from "./entities/chat.entity";
import { ConversationDocument } from "./entities/conversation.entity";
import { ConversationTypeEnum } from "./enums/conversation-type.enum";
import { EventEmitter2 } from "@nestjs/event-emitter";
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { ReportParamsDto } from "src/util/report-params.dto";
import { ConversationActivitiesDocument } from "./entities/conversation-activities.entity";
import { ConversationStatusEnum } from "./enums/conversation-status.enum";
export declare class ConversationService {
    private readonly conversationModel;
    private readonly chatModel;
    private readonly conversationActivitiesModel;
    private readonly eventEmitter;
    private logger;
    constructor(conversationModel: Model<ConversationDocument>, chatModel: Model<ChatDocument>, conversationActivitiesModel: Model<ConversationActivitiesDocument>, eventEmitter: EventEmitter2);
    createChat(createChatDto: CreateChatDto): Promise<import("./entities/chat.entity").Chat & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    maskMessage(message: string): string;
    maskChat(chatId: string): Promise<import("./entities/chat.entity").Chat & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    createConversation(createConversationDto: CreateConversationDto): Promise<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    closeConversation({ conversationId }: {
        conversationId: string;
    }): Promise<void>;
    endConversation(id: string, status?: ConversationStatusEnum): Promise<void>;
    pushChatToConversation(id: string, chatId: string): Promise<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getConversationByAgentId(id: string): Promise<Omit<Omit<Omit<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>, never>, never>[]>;
    getConversationByVisitorId(id: string): Promise<Omit<Omit<Omit<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>, never>, never>[]>;
    getConversationById(id: string): Promise<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getConversationByBotId(id: string): Promise<Omit<Omit<Omit<import("./entities/conversation.entity").Conversation & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>, never>, never>[]>;
    getAllConversations(query?: {
        status?: ConversationStatusEnum;
        type?: ConversationTypeEnum;
    }): Promise<any[]>;
    addattributes(id: string, attributes: any): Promise<void>;
    getActiveConversations(user: JwtPayload): Promise<any[]>;
    updateConversationFeedback(id: string, feedback: any): Promise<void>;
    transferConversationToAgent(conversationId: string, agentId: string): Promise<void>;
    markConversationExpiredAfter2Hours(): Promise<void>;
    getTotalCount(days?: number, handledByAgent?: boolean, title?: string, status?: ConversationStatusEnum, all?: boolean, isHistorical?: boolean): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getDayWisePerformance(params: ReportParamsDto, agent?: boolean): Promise<any[]>;
    getDateWiseConversations(params: ReportParamsDto, agent?: boolean): Promise<any[]>;
    TotalCountPlatform(): Promise<any>;
    DayWisePlatform(params: ReportParamsDto): Promise<any[]>;
    DateWisePlatform(params: ReportParamsDto): Promise<any[]>;
    getActiveCount(query: {
        agentId?: string;
        anonymous?: boolean;
    }, title?: string): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getActiveStats(user: JwtPayload): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getHistoryStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getBlockStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    endConversationByAgent(data: {
        conversationId: string;
    }): Promise<void>;
    reportConversation(data: {
        conversationId: string;
    }): Promise<void>;
    getChats(conversationId: string, visitorId: string): Promise<{
        message: string;
        label: any;
    }[]>;
    homeConversationCount(filter: any, status?: ConversationStatusEnum): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
}
