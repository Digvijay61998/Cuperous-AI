"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const util_1 = require("src/util");
const conversation_service_1 = require("./conversation.service");
const search_conv_dto_1 = require("./dto/search-conv.dto");
const conversation_status_enum_1 = require("./enums/conversation-status.enum");
let ConversationController = class ConversationController {
    constructor(conversationService) {
        this.conversationService = conversationService;
    }
    async findAll(query) {
        return await this.conversationService.getAllConversations(query);
    }
    async getActiveConversations(user) {
        return await this.conversationService.getActiveConversations(user);
    }
    async getActiveConversationsStats(user) {
        return await this.conversationService.getActiveStats(user);
    }
    async getHomeConversationsStats(time) {
        return await this.conversationService.homeConversationCount(time);
    }
    async getHomeBlockedConversationsStats(time) {
        return await this.conversationService.homeConversationCount(time, conversation_status_enum_1.ConversationStatusEnum.BLOCKED);
    }
    async getHistoryConversationsStats() {
        return await this.conversationService.getHistoryStats();
    }
    async getBlockConversationsStats() {
        return await this.conversationService.getBlockStats();
    }
    async findOne(id) {
        return await this.conversationService.getConversationById(id);
    }
    async getConversationByVisitorId(visitorId) {
        return await this.conversationService.getConversationByVisitorId(visitorId);
    }
    async getConversationByAgentId(agentId) {
        return await this.conversationService.getConversationByAgentId(agentId);
    }
    async getConversationByBotId(botId) {
        return await this.conversationService.getConversationByBotId(botId);
    }
};
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_conv_dto_1.SearchConversationDto]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)("active-conversations"),
    __param(0, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getActiveConversations", null);
__decorate([
    (0, common_1.Get)("stats/active"),
    __param(0, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getActiveConversationsStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)("stats/home"),
    __param(0, (0, common_1.Query)("time")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getHomeConversationsStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)("stats/home/blocked"),
    __param(0, (0, common_1.Query)("time")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getHomeBlockedConversationsStats", null);
__decorate([
    (0, common_1.Get)("stats/history"),
    (0, public_decorator_1.Public)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getHistoryConversationsStats", null);
__decorate([
    (0, common_1.Get)("stats/block"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getBlockConversationsStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(":id"),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)("visitor/:visitorId"),
    __param(0, (0, common_1.Param)("visitorId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getConversationByVisitorId", null);
__decorate([
    (0, common_1.Get)("agent/:agentId"),
    __param(0, (0, common_1.Param)("agentId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getConversationByAgentId", null);
__decorate([
    (0, common_1.Get)("bot/:botId"),
    __param(0, (0, common_1.Param)("botId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getConversationByBotId", null);
ConversationController = __decorate([
    (0, common_1.Controller)("conversation"),
    (0, swagger_1.ApiTags)("Conversation"),
    (0, swagger_1.ApiSecurity)("bearer"),
    __metadata("design:paramtypes", [conversation_service_1.ConversationService])
], ConversationController);
exports.ConversationController = ConversationController;
//# sourceMappingURL=conversation.controller.js.map