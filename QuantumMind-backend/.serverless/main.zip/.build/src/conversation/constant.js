"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONVERSATION_ACTIVITIES_PROVIDER = exports.CHAT_PROVIDER = exports.CONVERSATION_PROVIDER = void 0;
exports.CONVERSATION_PROVIDER = 'CONVERSATION_PROVIDER';
exports.CHAT_PROVIDER = 'CHAT_PROVIDER';
exports.CONVERSATION_ACTIVITIES_PROVIDER = 'CONVERSATION_ACTIVITIES_PROVIDER';
//# sourceMappingURL=constant.js.map