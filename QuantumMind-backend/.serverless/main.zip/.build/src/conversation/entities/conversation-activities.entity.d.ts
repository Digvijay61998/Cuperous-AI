import * as mongoose from 'mongoose';
export declare class ConversationActivities {
    conversationId: string;
    startedAt: Date;
    endedAt: Date;
    timeSpent: number;
    attributes: Record<string, any>;
}
export type ConversationActivitiesDocument = ConversationActivities & mongoose.Document;
export declare const ConversationActivitiesSchema: mongoose.Schema<ConversationActivities, mongoose.Model<ConversationActivities, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, ConversationActivities>;
