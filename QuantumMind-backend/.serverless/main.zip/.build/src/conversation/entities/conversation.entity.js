"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationSchema = exports.Conversation = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = __importDefault(require("mongoose"));
const agent_entity_1 = require("src/agent/entities/agent.entity");
const entities_1 = require("src/bots/entities");
const visitor_entity_1 = require("src/visitor/entities/visitor.entity");
const conversation_status_enum_1 = require("../enums/conversation-status.enum");
const conversation_type_enum_1 = require("../enums/conversation-type.enum");
const platform_enum_1 = require("../enums/platform.enum");
let Conversation = class Conversation {
};
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose_2.default.Schema.Types.ObjectId,
                ref: 'Chat',
            },
        ],
    }),
    __metadata("design:type", Array)
], Conversation.prototype, "chats", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: agent_entity_1.Agent.name,
    }),
    __metadata("design:type", Object)
], Conversation.prototype, "agent", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: visitor_entity_1.Visitor.name,
    }),
    __metadata("design:type", visitor_entity_1.Visitor)
], Conversation.prototype, "visitor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: conversation_status_enum_1.ConversationStatusEnum,
        default: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
    }),
    __metadata("design:type", String)
], Conversation.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: entities_1.Bot.name,
    }),
    __metadata("design:type", Object)
], Conversation.prototype, "bot", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
        enum: conversation_type_enum_1.ConversationTypeEnum,
    }),
    __metadata("design:type", String)
], Conversation.prototype, "type", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose_2.default.Schema.Types.ObjectId,
                ref: 'ConversationActivities',
            },
        ],
    }),
    __metadata("design:type", Array)
], Conversation.prototype, "activities", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose_2.default.Schema.Types.ObjectId,
                ref: 'Feedback',
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Conversation.prototype, "feedbacks", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: false,
    }),
    __metadata("design:type", Boolean)
], Conversation.prototype, "transferredToAgent", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], Conversation.prototype, "transferredAt", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], Conversation.prototype, "agentCallEndedAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], Conversation.prototype, "anonymous", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: platform_enum_1.PlatformEnum,
        default: platform_enum_1.PlatformEnum.WIDGET,
    }),
    __metadata("design:type", String)
], Conversation.prototype, "platform", void 0);
Conversation = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
    })
], Conversation);
exports.Conversation = Conversation;
exports.ConversationSchema = mongoose_1.SchemaFactory.createForClass(Conversation);
//# sourceMappingURL=conversation.entity.js.map