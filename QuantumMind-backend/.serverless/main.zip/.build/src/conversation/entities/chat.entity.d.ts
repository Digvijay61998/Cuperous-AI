import * as mongoose from 'mongoose';
import { Conversation } from './conversation.entity';
export type ChatDocument = Chat & mongoose.Document;
export declare class Chat {
    message: string;
    sender: string;
    conversationId: Conversation;
    type: string;
    time: Date;
    chatId: string;
    secured: boolean;
}
export declare const ChatSchema: mongoose.Schema<Chat, mongoose.Model<Chat, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Chat>;
