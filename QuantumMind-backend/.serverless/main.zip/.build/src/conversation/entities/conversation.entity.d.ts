import mongoose, { Document } from 'mongoose';
import { BotDocument } from 'src/bots/entities';
import { Visitor } from 'src/visitor/entities/visitor.entity';
import { Chat } from './chat.entity';
import { ConversationActivities } from './conversation-activities.entity';
export type ConversationDocument = Conversation & Document;
export declare class Conversation {
    chats: Chat[];
    agent: any;
    visitor: Visitor;
    status: string;
    bot: BotDocument;
    type: string;
    activities: ConversationActivities[];
    feedbacks: string[];
    transferredToAgent: boolean;
    transferredAt: Date;
    agentCallEndedAt: Date;
    anonymous: boolean;
    platform: string;
}
export declare const ConversationSchema: mongoose.Schema<Conversation, mongoose.Model<Conversation, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Conversation>;
