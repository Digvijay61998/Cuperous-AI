"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.conversationProvider = void 0;
const constants_1 = require("src/constants");
const chat_entity_1 = require("./entities/chat.entity");
const conversation_entity_1 = require("./entities/conversation.entity");
const conversation_activities_entity_1 = require("./entities/conversation-activities.entity");
const constant_1 = require("./constant");
exports.conversationProvider = [
    {
        provide: constant_1.CONVERSATION_PROVIDER,
        useFactory: (connection) => connection.model(conversation_entity_1.Conversation.name, conversation_entity_1.ConversationSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.CHAT_PROVIDER,
        useFactory: (connection) => connection.model(chat_entity_1.Chat.name, chat_entity_1.ChatSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.CONVERSATION_ACTIVITIES_PROVIDER,
        useFactory: (connection) => connection.model(conversation_activities_entity_1.ConversationActivities.name, conversation_activities_entity_1.ConversationActivitiesSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=conversation.provider.js.map