"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationStatusEnum = void 0;
var ConversationStatusEnum;
(function (ConversationStatusEnum) {
    ConversationStatusEnum["COMPLETED"] = "completed";
    ConversationStatusEnum["IN_PROGRESS"] = "in_progress";
    ConversationStatusEnum["EXPIRED"] = "expired";
    ConversationStatusEnum["BLOCKED"] = "blocked";
})(ConversationStatusEnum = exports.ConversationStatusEnum || (exports.ConversationStatusEnum = {}));
//# sourceMappingURL=conversation-status.enum.js.map