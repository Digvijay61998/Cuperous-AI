"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationTypeEnum = void 0;
var ConversationTypeEnum;
(function (ConversationTypeEnum) {
    ConversationTypeEnum["REALTIME"] = "realtime";
    ConversationTypeEnum["BOT"] = "bot";
})(ConversationTypeEnum = exports.ConversationTypeEnum || (exports.ConversationTypeEnum = {}));
//# sourceMappingURL=conversation-type.enum.js.map