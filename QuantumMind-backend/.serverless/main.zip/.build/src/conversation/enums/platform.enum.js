"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformEnumList = exports.PlatformEnum = void 0;
exports.PlatformEnum = {
    FACEBOOK: 'facebook',
    TELEGRAM: 'telegram',
    WHATSAPP: 'whatsapp',
    WIDGET: 'widget',
};
exports.PlatformEnumList = Object.values(exports.PlatformEnum);
//# sourceMappingURL=platform.enum.js.map