export declare enum ConversationTypeEnum {
    REALTIME = "realtime",
    BOT = "bot"
}
