export declare const PlatformEnum: {
    readonly FACEBOOK: "facebook";
    readonly TELEGRAM: "telegram";
    readonly WHATSAPP: "whatsapp";
    readonly WIDGET: "widget";
};
export declare const PlatformEnumList: ("facebook" | "telegram" | "whatsapp" | "widget")[];
