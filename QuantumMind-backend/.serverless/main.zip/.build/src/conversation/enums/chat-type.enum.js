"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatTypeEnum = void 0;
var ChatTypeEnum;
(function (ChatTypeEnum) {
    ChatTypeEnum["TEXT"] = "text";
    ChatTypeEnum["IMAGE"] = "image";
    ChatTypeEnum["VIDEO"] = "video";
    ChatTypeEnum["AUDIO"] = "audio";
    ChatTypeEnum["FILE"] = "file";
    ChatTypeEnum["BUTTONS"] = "buttons";
    ChatTypeEnum["QUICK_REPLY"] = "quick_reply";
    ChatTypeEnum["GOTO"] = "goto";
    ChatTypeEnum["RANDOM_TEXT"] = "random_text";
    ChatTypeEnum["MAPS"] = "maps";
    ChatTypeEnum["GALLERY"] = "gallery";
})(ChatTypeEnum = exports.ChatTypeEnum || (exports.ChatTypeEnum = {}));
//# sourceMappingURL=chat-type.enum.js.map