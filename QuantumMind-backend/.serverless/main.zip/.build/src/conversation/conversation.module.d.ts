export declare class ConversationModule {
}
