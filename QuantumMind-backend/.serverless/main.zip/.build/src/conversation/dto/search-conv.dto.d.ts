import { ConversationStatusEnum } from '../enums/conversation-status.enum';
import { ConversationTypeEnum } from '../enums/conversation-type.enum';
export declare class SearchConversationDto {
    status: ConversationStatusEnum;
    type: ConversationTypeEnum;
}
