export declare class CreateConversationDto {
    agent?: string;
    visitor: string;
    type: string;
    bot: string;
    status?: string;
    chats?: string[];
    anonymous?: boolean;
    platform?: string;
}
