export declare class CreateChatDto {
    conversationId: string;
    message: string;
    sender: string;
    type: string;
    chatId?: string;
}
