"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationService = void 0;
const common_1 = require("@nestjs/common");
const bson_1 = require("bson");
const mongoose_1 = require("mongoose");
const constant_1 = require("./constant");
const create_chat_dto_1 = require("./dto/create-chat.dto");
const conversation_type_enum_1 = require("./enums/conversation-type.enum");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
const class_validator_1 = require("class-validator");
const moment_1 = __importDefault(require("moment"));
const get_subtitle_1 = require("src/util/get-subtitle");
const conversation_status_enum_1 = require("./enums/conversation-status.enum");
const platform_enum_1 = require("./enums/platform.enum");
let ConversationService = class ConversationService {
    constructor(conversationModel, chatModel, conversationActivitiesModel, eventEmitter) {
        this.conversationModel = conversationModel;
        this.chatModel = chatModel;
        this.conversationActivitiesModel = conversationActivitiesModel;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger("ConversationService");
    }
    async createChat(createChatDto) {
        try {
            if (!createChatDto.conversationId)
                return;
            const chat = await this.chatModel.create(Object.assign(Object.assign({}, createChatDto), { time: new Date() }));
            await this.pushChatToConversation(createChatDto.conversationId, chat._id);
            return chat;
        }
        catch (error) {
            this.logger.error(`Error in creating chat ${error.message}`);
            throw error;
        }
    }
    maskMessage(message) {
        if (!message || message.length < 1)
            return message;
        const length = message.length;
        if ((0, class_validator_1.isEmail)(message)) {
            const [email, domain] = message.split("@");
            return `${email.slice(0, 2)}*****@${domain}`;
        }
        if ((0, class_validator_1.isCreditCard)(message)) {
            return `****${message.slice(-4)}`;
        }
        if (length < 4)
            return `${message.slice(0, 1)}${"*".repeat(length - 1)}`;
        if (length < 10)
            return `${message.slice(0, 2)}${"*".repeat(length - 4)}${message.slice(-2)}`;
        if (length < 16)
            return `${message.slice(0, 4)}${"*".repeat(length - 8)}${message.slice(-4)}`;
        else
            return `${message.slice(0, 6)}${"*".repeat(length - 12)}${message.slice(-6)}`;
    }
    async maskChat(chatId) {
        try {
            const chat = await this.chatModel.findOne({ chatId });
            if (!chat)
                return;
            chat.message = this.maskMessage(chat.message);
            chat.secured = true;
            await chat.save();
            return chat;
        }
        catch (error) {
            this.logger.error(`Error in masking chat ${error.message}`);
            throw error;
        }
    }
    async createConversation(createConversationDto) {
        try {
            const query = {
                visitor: createConversationDto.visitor,
                type: createConversationDto.type,
            };
            if (createConversationDto.type === conversation_type_enum_1.ConversationTypeEnum.REALTIME) {
                query["agent"] = createConversationDto.agent;
            }
            let conversation = await this.conversationModel.findOne(query);
            if (!conversation ||
                conversation.status !== conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS) {
                conversation = await this.conversationModel.create(createConversationDto);
            }
            this.eventEmitter.emit("conversation.created.visitor", {
                visitorId: query.visitor,
                conversationId: conversation._id,
            });
            if (createConversationDto.type === conversation_type_enum_1.ConversationTypeEnum.REALTIME) {
                this.eventEmitter.emit("conversation.created.agent", {
                    agentId: conversation.agent,
                    conversationId: conversation._id,
                });
            }
            const activity = await this.conversationActivitiesModel.create({
                conversation: conversation._id,
                startedAt: new Date(),
                timeSpent: 0,
            });
            conversation.activities.push(activity._id);
            await conversation.save();
            return conversation;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async closeConversation({ conversationId }) {
        await this.endConversation(conversationId);
    }
    async endConversation(id, status) {
        try {
            const conversation = await this.conversationModel.findById(id);
            if (!conversation) {
                throw new Error("Conversation not found");
            }
            const activity = await this.conversationActivitiesModel.findOne({
                _id: conversation.activities[conversation.activities.length - 1],
            });
            activity.endedAt = new Date();
            activity.timeSpent =
                new Date(activity.endedAt).getTime() -
                    new Date(activity.startedAt).getTime();
            await activity.save();
            conversation.status = status || conversation_status_enum_1.ConversationStatusEnum.COMPLETED;
            await conversation.save();
        }
        catch (error) {
            this.logger.error(error);
        }
    }
    async pushChatToConversation(id, chatId) {
        try {
            const conversation = await this.conversationModel.findByIdAndUpdate(id, { $push: { chats: chatId } }, { new: true });
            return conversation;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async getConversationByAgentId(id) {
        try {
            const conversations = await this.conversationModel
                .find({ agent: id })
                .populate("visitor", "name")
                .populate("bot", "name")
                .populate("agent", "name")
                .sort({ updatedAt: -1 });
            return conversations;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async getConversationByVisitorId(id) {
        try {
            const conversations = await this.conversationModel
                .find({ visitor: id })
                .populate("visitor", "name")
                .populate("bot", "name")
                .populate("agent", "name")
                .sort({ updatedAt: -1 });
            return conversations;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async getConversationById(id) {
        try {
            const conversation = await this.conversationModel
                .findOne({ _id: id })
                .populate("chats", {
                message: 1,
                time: 1,
                sender: 1,
                type: 1,
            })
                .populate("visitor")
                .populate("bot", "name")
                .populate("feedbacks", "rating comment")
                .populate("activities", "attributes", null, {
                sort: { startedAt: -1 },
                $limit: 1,
                $project: { activity: 1 },
            })
                .select("-__v  -updatedAt -createdAt -conversationId")
                .sort({ updatedAt: -1 });
            return conversation;
        }
        catch (error) {
            this.logger.error(error);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getConversationByBotId(id) {
        try {
            const conversations = await this.conversationModel
                .find({
                bot: id,
            })
                .populate("visitor", "name")
                .populate("bot", "name")
                .populate("agent", "name")
                .sort({ updatedAt: -1 });
            return conversations;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async getAllConversations(query) {
        try {
            const queryObj = {
                $match: { _id: { $ne: null } },
            };
            if (query.status === conversation_status_enum_1.ConversationStatusEnum.BLOCKED) {
                queryObj.$match["status"] = query.status;
            }
            else {
                queryObj.$match["status"] = { $ne: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS };
            }
            if (query.type) {
                queryObj.$match["type"] = query.type;
            }
            const conversations = await this.conversationModel.aggregate([
                queryObj,
                {
                    $lookup: {
                        from: "visitors",
                        localField: "visitor",
                        foreignField: "_id",
                        as: "visitor",
                    },
                },
                {
                    $lookup: {
                        from: "bots",
                        localField: "bot",
                        foreignField: "_id",
                        as: "bot",
                    },
                },
                {
                    $lookup: {
                        from: "conversationactivities",
                        localField: "activities",
                        foreignField: "_id",
                        as: "activities",
                    },
                },
                {
                    $lookup: {
                        from: "chats",
                        localField: "chats",
                        foreignField: "_id",
                        as: "lastMessage",
                        let: { chats: "$chats" },
                        pipeline: [
                            {
                                $match: {
                                    _id: { $ne: null },
                                },
                            },
                            {
                                $sort: { time: -1 },
                            },
                            {
                                $limit: 1,
                            },
                            {
                                $project: {
                                    _id: 1,
                                    message: 1,
                                    time: 1,
                                    type: 1,
                                    sender: 1,
                                },
                            },
                        ],
                    },
                },
                {
                    $unwind: "$visitor",
                },
                {
                    $unwind: "$bot",
                },
                {
                    $unwind: {
                        path: "$lastMessage",
                        preserveNullAndEmptyArrays: false,
                    },
                },
                {
                    $sort: { updatedAt: -1 },
                },
                {
                    $project: {
                        _id: 1,
                        type: 1,
                        status: 1,
                        "visitor._id": 1,
                        "visitor.name": 1,
                        "bot.name": 1,
                        "bot.id": "$bot._id",
                        lastMessage: 1,
                        activity: { $arrayElemAt: ["$activities", -1] },
                    },
                },
            ]);
            return conversations;
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async addattributes(id, attributes) {
        const conversation = await this.conversationActivitiesModel.findOne({
            conversationId: id,
        });
        if (conversation) {
            conversation.attributes = Object.assign(Object.assign({}, conversation.attributes), attributes);
            await conversation.save();
        }
    }
    async getActiveConversations(user) {
        try {
            const conversations = await this.conversationModel.aggregate([
                {
                    $match: {
                        status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
                        type: conversation_type_enum_1.ConversationTypeEnum.REALTIME,
                        agent: new bson_1.ObjectId(user._id),
                    },
                },
                {
                    $lookup: {
                        from: "visitors",
                        localField: "visitor",
                        foreignField: "_id",
                        as: "visitor",
                    },
                },
                {
                    $lookup: {
                        from: "bots",
                        localField: "bot",
                        foreignField: "_id",
                        as: "bot",
                    },
                },
                {
                    $lookup: {
                        from: "conversationactivities",
                        localField: "activities",
                        foreignField: "_id",
                        as: "activities",
                    },
                },
                {
                    $lookup: {
                        from: "chats",
                        localField: "chats",
                        foreignField: "_id",
                        as: "chats",
                        let: { chats: "$chats" },
                        pipeline: [
                            {
                                $match: {
                                    _id: { $ne: null },
                                },
                            },
                            {
                                $sort: { time: -1 },
                            },
                            {
                                $limit: 40,
                            },
                            {
                                $sort: { time: 1 },
                            },
                        ],
                    },
                },
                {
                    $addFields: {
                        lastMessage: {
                            $arrayElemAt: ["$chats", -1],
                        },
                    },
                },
                {
                    $unwind: "$visitor",
                },
                {
                    $unwind: "$bot",
                },
                {
                    $unwind: {
                        path: "$lastMessage",
                        preserveNullAndEmptyArrays: false,
                    },
                },
                {
                    $sort: { updatedAt: -1 },
                },
                {
                    $project: {
                        chats: 1,
                        _id: 1,
                        type: 1,
                        status: 1,
                        "visitor._id": 1,
                        "visitor.name": 1,
                        "bot.name": 1,
                        "bot.id": "$bot._id",
                        lastMessage: 1,
                        activity: { $arrayElemAt: ["$activities", -1] },
                    },
                },
            ]);
            return conversations;
        }
        catch (error) {
            this.logger.error(error);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateConversationFeedback(id, feedback) {
        try {
            const conversation = await this.conversationModel.findById(id);
            if (conversation) {
                conversation.feedbacks.push(feedback);
                await conversation.save();
            }
        }
        catch (error) {
            this.logger.error(`Error while updating conversation feedback ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async transferConversationToAgent(conversationId, agentId) {
        try {
            const conversation = await this.conversationModel.findById(conversationId);
            if (conversation) {
                conversation.agent = agentId;
                conversation.type = conversation_type_enum_1.ConversationTypeEnum.REALTIME;
                conversation.transferredToAgent = true;
                conversation.transferredAt = new Date();
                await conversation.save();
            }
        }
        catch (error) {
            this.logger.error(`Error while updating conversation feedback ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async markConversationExpiredAfter2Hours() {
        await this.conversationModel.updateMany({
            status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
            createdAt: {
                $lte: new Date(new Date().setHours(new Date().getHours() - 2)),
            },
        }, {
            status: conversation_status_enum_1.ConversationStatusEnum.EXPIRED,
        });
    }
    async getTotalCount(days = 30, handledByAgent, title, status, all, isHistorical) {
        const query = {};
        if (!handledByAgent) {
            query["transferredToAgent"] = { $ne: true };
        }
        else
            query["transferredToAgent"] = { $eq: true };
        if (status) {
            query["status"] = status;
        }
        if (all) {
            delete query["transferredToAgent"];
        }
        if (isHistorical) {
            query["status"] = { $ne: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS };
        }
        const total = await this.conversationModel.countDocuments(query);
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.conversationModel.countDocuments(Object.assign(Object.assign({}, query), { createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                } }));
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: title || "Total Conversations",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "conversation",
        };
    }
    async getDayWisePerformance(params, agent = false) {
        const { id: botId, startDate, agentId } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = new bson_1.ObjectId(botId);
        }
        if (agentId) {
            match["agent"] = new bson_1.ObjectId(agentId);
        }
        if (agent) {
            match["transferredToAgent"] = true;
        }
        try {
            const data = await this.conversationModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $isoDayOfWeek: "$createdAt",
                        },
                        total: { $sum: 1 },
                        completed: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$status", conversation_status_enum_1.ConversationStatusEnum.COMPLETED] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        expired: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$status", conversation_status_enum_1.ConversationStatusEnum.EXPIRED] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        day: {
                            $switch: {
                                branches: [
                                    { case: { $eq: ["$_id", 1] }, then: "MON" },
                                    { case: { $eq: ["$_id", 2] }, then: "TUE" },
                                    { case: { $eq: ["$_id", 3] }, then: "WED" },
                                    { case: { $eq: ["$_id", 4] }, then: "THU" },
                                    { case: { $eq: ["$_id", 5] }, then: "FRI" },
                                    { case: { $eq: ["$_id", 6] }, then: "SAT" },
                                    { case: { $eq: ["$_id", 7] }, then: "SUN" },
                                ],
                            },
                        },
                        total: 1,
                        completed: 1,
                        expired: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting bot conversation performance ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getDateWiseConversations(params, agent = false) {
        const { id: botId, startDate, agentId } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = new bson_1.ObjectId(botId);
        }
        if (agentId) {
            match["agent"] = new bson_1.ObjectId(agentId);
        }
        if (agent) {
            match["transferredToAgent"] = true;
        }
        try {
            const data = await this.conversationModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$createdAt",
                            },
                        },
                        total: { $sum: 1 },
                        completed: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$status", conversation_status_enum_1.ConversationStatusEnum.COMPLETED] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        expired: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$status", conversation_status_enum_1.ConversationStatusEnum.EXPIRED] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        date: "$_id",
                        total: 1,
                        completed: 1,
                        expired: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting date wise conversations ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async TotalCountPlatform() {
        try {
            const result = await this.conversationModel.aggregate([
                {
                    $facet: {
                        total: [
                            {
                                $count: "total",
                            },
                        ],
                        facebook: [
                            {
                                $match: {
                                    platform: platform_enum_1.PlatformEnum.FACEBOOK,
                                },
                            },
                            {
                                $count: "facebook",
                            },
                        ],
                        whatsapp: [
                            {
                                $match: {
                                    platform: platform_enum_1.PlatformEnum.WHATSAPP,
                                },
                            },
                            {
                                $count: "whatsapp",
                            },
                        ],
                        telegram: [
                            {
                                $match: {
                                    platform: platform_enum_1.PlatformEnum.TELEGRAM,
                                },
                            },
                            {
                                $count: "telegram",
                            },
                        ],
                        widget: [
                            {
                                $match: {
                                    platform: platform_enum_1.PlatformEnum.WIDGET,
                                },
                            },
                            {
                                $count: "widget",
                            },
                        ],
                    },
                },
                {
                    $project: {
                        facebook: {
                            $arrayElemAt: ["$facebook.facebook", 0],
                        },
                        whatsapp: {
                            $arrayElemAt: ["$whatsapp.whatsapp", 0],
                        },
                        telegram: {
                            $arrayElemAt: ["$telegram.telegram", 0],
                        },
                        widget: {
                            $arrayElemAt: ["$widget.widget", 0],
                        },
                    },
                },
            ]);
            return result[0];
        }
        catch (err) {
            this.logger.error(`Error in getting platform data count: ${err.message}`);
            throw new common_1.HttpException(err.message, err.status || 500);
        }
    }
    async DayWisePlatform(params) {
        const { id: botId, startDate } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = new bson_1.ObjectId(botId);
        }
        try {
            const data = await this.conversationModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $isoDayOfWeek: "$createdAt",
                        },
                        total: { $sum: 1 },
                        facebook: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.FACEBOOK] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        whatsapp: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.WHATSAPP] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        telegram: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.TELEGRAM] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        widget: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.WIDGET] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        day: {
                            $switch: {
                                branches: [
                                    { case: { $eq: ["$_id", 1] }, then: "MON" },
                                    { case: { $eq: ["$_id", 2] }, then: "TUE" },
                                    { case: { $eq: ["$_id", 3] }, then: "WED" },
                                    { case: { $eq: ["$_id", 4] }, then: "THU" },
                                    { case: { $eq: ["$_id", 5] }, then: "FRI" },
                                    { case: { $eq: ["$_id", 6] }, then: "SAT" },
                                    { case: { $eq: ["$_id", 7] }, then: "SUN" },
                                ],
                            },
                        },
                        total: 1,
                        facebook: 1,
                        whatsapp: 1,
                        telegram: 1,
                        widget: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting bot conversation performance ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async DateWisePlatform(params) {
        const { id: botId, startDate } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = new bson_1.ObjectId(botId);
        }
        try {
            const data = await this.conversationModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$createdAt",
                            },
                        },
                        total: { $sum: 1 },
                        facebook: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.FACEBOOK] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        whatsapp: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.WHATSAPP] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        telegram: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.TELEGRAM] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        widget: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$platform", platform_enum_1.PlatformEnum.WIDGET] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        date: "$_id",
                        total: 1,
                        facebook: 1,
                        whatsapp: 1,
                        telegram: 1,
                        widget: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting date wise conversations ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getActiveCount(query, title) {
        const { agentId, anonymous } = query;
        const match = {
            status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
        };
        if (agentId) {
            match["agent"] = agentId;
            match["type"] = conversation_type_enum_1.ConversationTypeEnum.REALTIME;
        }
        if (anonymous) {
            match["anonymous"] = true;
        }
        const total = await this.conversationModel.countDocuments(match);
        return {
            stats: total,
            trendNumber: 0,
            trend: "positive",
            title: title || "Total Active",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(1),
            type: "conversation",
        };
    }
    async getActiveStats(user) {
        return Promise.all([
            this.getActiveCount({}, "Total Active"),
            this.getActiveCount({ agentId: user._id }, "My Active"),
            this.getActiveCount({ agentId: user._id, anonymous: true }, "My Anonymous"),
            this.getActiveCount({ agentId: user._id, anonymous: false }, "My Named"),
        ]);
    }
    async getHistoryStats() {
        return Promise.all([
            this.getTotalCount(30, false, "Total Conversations", conversation_status_enum_1.ConversationStatusEnum.COMPLETED, true, true),
            this.getTotalCount(30, false, "Handled By Bot", conversation_status_enum_1.ConversationStatusEnum.COMPLETED, false, true),
            this.getTotalCount(30, true, "Handled By Agent", conversation_status_enum_1.ConversationStatusEnum.COMPLETED, false, true),
        ]);
    }
    async getBlockStats() {
        return Promise.all([
            this.getTotalCount(30, false, "Blocked By Bot", conversation_status_enum_1.ConversationStatusEnum.BLOCKED),
            this.getTotalCount(30, true, "Blocked By Agent", conversation_status_enum_1.ConversationStatusEnum.BLOCKED),
            this.getTotalCount(30, false, "Total Blocked Conversations", conversation_status_enum_1.ConversationStatusEnum.COMPLETED, true),
        ]);
    }
    async endConversationByAgent(data) {
        const { conversationId } = data;
        const conversation = await this.conversationModel.findById(conversationId);
        if (conversation) {
            conversation.type = conversation_type_enum_1.ConversationTypeEnum.BOT;
            conversation.agentCallEndedAt = new Date();
            await conversation.save();
        }
    }
    async reportConversation(data) {
        const { conversationId } = data;
        const conversation = await this.conversationModel.findById(conversationId);
        if (conversation) {
            conversation.status = conversation_status_enum_1.ConversationStatusEnum.BLOCKED;
            await conversation.save();
        }
    }
    async getChats(conversationId, visitorId) {
        try {
            const conversation = await this.conversationModel
                .findById(conversationId)
                .populate("bot", "name")
                .populate("agent", "name")
                .populate("chats");
            if (!conversation) {
                throw new common_1.HttpException("No conversation found by this Id", 404);
            }
            const botId = conversation.bot._id.toHexString();
            const data = conversation.chats.map((chat) => {
                return {
                    message: chat.message,
                    label: chat.sender === visitorId
                        ? "You"
                        : chat.sender === botId
                            ? conversation.bot.name
                            : conversation.agent.name,
                };
            });
            return data;
        }
        catch (err) {
            this.logger.error("error in getting chat", err);
        }
    }
    async homeConversationCount(filter, status) {
        if (!filter)
            filter = "day";
        try {
            const total = await this.conversationModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().startOf(filter).toISOString()),
                },
                status: status || { $ne: "" },
            });
            let percentageChange = 0;
            const previousTotal = await this.conversationModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().subtract(1, filter).startOf(filter).toISOString()),
                },
                status: status || { $ne: "" },
            });
            if (previousTotal) {
                percentageChange = Math.round(((total - previousTotal) / previousTotal) * 100);
            }
            return {
                stats: total,
                trendNumber: Math.abs(percentageChange),
                trend: percentageChange > 0 ? "positive" : "negative",
                title: status === conversation_status_enum_1.ConversationStatusEnum.BLOCKED
                    ? "Blocked Conversations"
                    : "Total Conversations",
                type: "conversation",
            };
        }
        catch (error) {
            this.logger.error(`Error while getting home conversation count ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)("create.new.chat", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_chat_dto_1.CreateChatDto]),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "createChat", null);
__decorate([
    (0, event_emitter_1.OnEvent)("mask.chat", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "maskChat", null);
__decorate([
    (0, event_emitter_1.OnEvent)("end.conversation", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "closeConversation", null);
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_2_HOURS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "markConversationExpiredAfter2Hours", null);
__decorate([
    (0, event_emitter_1.OnEvent)("end-conversation-by-agent", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "endConversationByAgent", null);
__decorate([
    (0, event_emitter_1.OnEvent)("report-conversation", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConversationService.prototype, "reportConversation", null);
ConversationService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.CONVERSATION_PROVIDER)),
    __param(1, (0, common_1.Inject)(constant_1.CHAT_PROVIDER)),
    __param(2, (0, common_1.Inject)(constant_1.CONVERSATION_ACTIVITIES_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        mongoose_1.Model,
        mongoose_1.Model,
        event_emitter_1.EventEmitter2])
], ConversationService);
exports.ConversationService = ConversationService;
//# sourceMappingURL=conversation.service.js.map