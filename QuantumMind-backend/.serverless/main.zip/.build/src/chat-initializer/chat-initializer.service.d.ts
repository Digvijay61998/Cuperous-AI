import { VisitorService } from 'src/visitor/visitor.service';
import { BotsService } from 'src/bots/bots.service';
import { ConversationService } from 'src/conversation/conversation.service';
import { SocketStateService } from 'src/socket/socket-state.service';
import { CreateVisitorDto } from 'src/visitor/dto/create-visitor.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class ChatInitializerService {
    private readonly visitorService;
    private readonly botsService;
    private readonly conversationService;
    private readonly socketStateService;
    private readonly eventEmitter;
    private readonly logger;
    constructor(visitorService: VisitorService, botsService: BotsService, conversationService: ConversationService, socketStateService: SocketStateService, eventEmitter: EventEmitter2);
    initializeChat(visitorData: CreateVisitorDto, botId: string): Promise<{
        visitorId: string;
    }>;
    createChat(botId: string): Promise<{
        visitorId: string;
    }>;
}
