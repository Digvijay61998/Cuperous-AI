import { ChatInitializerService } from './chat-initializer.service';
export declare class ChatInitializerController {
    private readonly chatInitializerService;
    constructor(chatInitializerService: ChatInitializerService);
    test(botId: string): Promise<{
        visitorId: string;
    }>;
}
