"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ChatInitializerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatInitializerService = void 0;
const common_1 = require("@nestjs/common");
const visitor_service_1 = require("src/visitor/visitor.service");
const bots_service_1 = require("src/bots/bots.service");
const conversation_service_1 = require("src/conversation/conversation.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const conversation_type_enum_1 = require("src/conversation/enums/conversation-type.enum");
const mode_enum_1 = require("src/widget/enums/mode.enum");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
const bson_1 = require("bson");
const event_emitter_1 = require("@nestjs/event-emitter");
let ChatInitializerService = ChatInitializerService_1 = class ChatInitializerService {
    constructor(visitorService, botsService, conversationService, socketStateService, eventEmitter) {
        this.visitorService = visitorService;
        this.botsService = botsService;
        this.conversationService = conversationService;
        this.socketStateService = socketStateService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(ChatInitializerService_1.name);
    }
    async initializeChat(visitorData, botId) {
        try {
            const visitorId = await this.visitorService.CreateVisitorfromSocialMedia(visitorData);
            const userdata = this.socketStateService.getUserData(visitorId);
            if (userdata) {
                return {
                    visitorId,
                };
            }
            const bot = await this.botsService.getBotDataForWidget(botId);
            const botSettings = bot.botSetting;
            const nodeData = await this.botsService.getBotNode(bot.botFlow.startNode);
            const data = {
                botId: bot.id,
                currentNode: nodeData,
                startNode: nodeData,
                botSettings,
                mode: mode_enum_1.ModeEnum.live,
                platform: visitorData.platform,
                botName: bot.name,
            };
            const conversation = await this.conversationService.createConversation({
                bot: bot.id,
                type: conversation_type_enum_1.ConversationTypeEnum.BOT,
                visitor: visitorId,
                platform: visitorData.platform,
            });
            data.conversationId = conversation.id;
            this.socketStateService.updateUserData(visitorId, data);
            return {
                visitorId,
            };
        }
        catch (error) {
            console.log(error);
        }
    }
    async createChat(botId) {
        try {
            const visitorId = new bson_1.ObjectID().toHexString();
            const conversation = await this.conversationService.createConversation({
                bot: botId,
                type: conversation_type_enum_1.ConversationTypeEnum.BOT,
                visitor: visitorId,
                platform: platform_enum_1.PlatformEnum.WIDGET,
            });
            this.eventEmitter.emit('create.new.chat', {
                sender: visitorId,
                message: "Hi, I'm a new visitor, Create a new chat for stress testing",
                type: 'text',
                conversationId: conversation.id,
            });
            return {
                visitorId,
            };
        }
        catch (error) {
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
ChatInitializerService = ChatInitializerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [visitor_service_1.VisitorService,
        bots_service_1.BotsService,
        conversation_service_1.ConversationService,
        socket_state_service_1.SocketStateService,
        event_emitter_1.EventEmitter2])
], ChatInitializerService);
exports.ChatInitializerService = ChatInitializerService;
//# sourceMappingURL=chat-initializer.service.js.map