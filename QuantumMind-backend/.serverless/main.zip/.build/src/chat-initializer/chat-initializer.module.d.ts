export declare class ChatInitializerModule {
}
