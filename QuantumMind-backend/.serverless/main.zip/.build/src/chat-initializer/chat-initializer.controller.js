"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatInitializerController = void 0;
const common_1 = require("@nestjs/common");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const chat_initializer_service_1 = require("./chat-initializer.service");
let ChatInitializerController = class ChatInitializerController {
    constructor(chatInitializerService) {
        this.chatInitializerService = chatInitializerService;
    }
    async test(botId) {
        return this.chatInitializerService.createChat(botId);
    }
};
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('test/:botId'),
    __param(0, (0, common_1.Param)('botId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatInitializerController.prototype, "test", null);
ChatInitializerController = __decorate([
    (0, common_1.Controller)('chat-initializer'),
    __metadata("design:paramtypes", [chat_initializer_service_1.ChatInitializerService])
], ChatInitializerController);
exports.ChatInitializerController = ChatInitializerController;
//# sourceMappingURL=chat-initializer.controller.js.map