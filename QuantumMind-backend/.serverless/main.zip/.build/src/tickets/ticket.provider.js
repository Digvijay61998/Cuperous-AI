"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketProviders = void 0;
const constant_1 = require("./constant");
const ticket_entity_1 = require("./entities/ticket.entity");
const constants_1 = require("src/constants");
const ticket_activities_entity_1 = require("./entities/ticket-activities.entity");
exports.TicketProviders = [
    {
        provide: constant_1.TICKET_PROVIDER,
        useFactory: (connection) => connection.model(ticket_entity_1.Ticket.name, ticket_entity_1.TicketSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
    {
        provide: constant_1.TICKET_DETAILS_PROVIDER,
        useFactory: (connection) => connection.model(ticket_activities_entity_1.TicketActivities.name, ticket_activities_entity_1.TicketActivitiesSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=ticket.provider.js.map