export declare class CreateActivityDto {
    message: string;
    ticket: string;
    agent: string;
    status: string;
}
