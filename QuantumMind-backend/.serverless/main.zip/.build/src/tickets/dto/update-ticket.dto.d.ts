import { TicketStatusEnum } from '../enums/ticket-status.enum';
import { CreateTicketDto } from './create-ticket.dto';
declare const UpdateTicketDto_base: import("@nestjs/common").Type<Partial<CreateTicketDto>>;
export declare class UpdateTicketDto extends UpdateTicketDto_base {
    status: TicketStatusEnum;
}
export {};
