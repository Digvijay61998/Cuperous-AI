export declare class SearchParamDto {
    skip?: number;
    limit?: number;
    status?: string;
    priority?: string;
    tags?: string[];
    startDate?: Date;
    endDate?: Date;
    bot?: string;
}
