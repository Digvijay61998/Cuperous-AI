import { TicketPriorityEnum } from '../enums/ticket-priority';
export declare class CreateTicketDto {
    subject: string;
    description?: string;
    priority?: TicketPriorityEnum;
    bot: string;
    visitor: string;
    agents?: string[];
    conversationId: string;
    tags?: string[];
}
