"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketActivitiesEnum = void 0;
var TicketActivitiesEnum;
(function (TicketActivitiesEnum) {
    TicketActivitiesEnum["ASSIGNED"] = "ASSIGNED";
    TicketActivitiesEnum["REOPENED"] = "REOPENED";
    TicketActivitiesEnum["CLOSED"] = "CLOSED";
    TicketActivitiesEnum["COMMENTED"] = "COMMENTED";
    TicketActivitiesEnum["CREATED"] = "CREATED";
    TicketActivitiesEnum["RESOLVED"] = "RESOLVED";
})(TicketActivitiesEnum = exports.TicketActivitiesEnum || (exports.TicketActivitiesEnum = {}));
//# sourceMappingURL=ticket-activities.enum.js.map