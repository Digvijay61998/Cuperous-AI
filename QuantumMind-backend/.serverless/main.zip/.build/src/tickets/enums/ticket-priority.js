"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketPriorityEnumList = exports.TicketPriorityEnum = void 0;
exports.TicketPriorityEnum = {
    LOW: "LOW",
    MEDIUM: "MEDIUM",
    HIGH: "HIGH",
    CRITICAL: "CRITICAL",
};
exports.TicketPriorityEnumList = Object.values(exports.TicketPriorityEnum);
//# sourceMappingURL=ticket-priority.js.map