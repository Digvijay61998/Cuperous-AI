export declare enum TicketActivitiesEnum {
    ASSIGNED = "ASSIGNED",
    REOPENED = "REOPENED",
    CLOSED = "CLOSED",
    COMMENTED = "COMMENTED",
    CREATED = "CREATED",
    RESOLVED = "RESOLVED"
}
