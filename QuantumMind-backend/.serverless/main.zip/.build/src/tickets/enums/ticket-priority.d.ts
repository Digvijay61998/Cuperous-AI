export declare const TicketPriorityEnum: {
    readonly LOW: "LOW";
    readonly MEDIUM: "MEDIUM";
    readonly HIGH: "HIGH";
    readonly CRITICAL: "CRITICAL";
};
export type TicketPriorityEnum = (typeof TicketPriorityEnum)[keyof typeof TicketPriorityEnum];
export declare const TicketPriorityEnumList: ("LOW" | "MEDIUM" | "HIGH" | "CRITICAL")[];
