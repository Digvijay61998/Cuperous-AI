"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketStatusEnum = void 0;
var TicketStatusEnum;
(function (TicketStatusEnum) {
    TicketStatusEnum["OPEN"] = "OPEN";
    TicketStatusEnum["CLOSED"] = "CLOSED";
    TicketStatusEnum["PENDING"] = "PENDING";
    TicketStatusEnum["DEFERRED"] = "DEFERRED";
})(TicketStatusEnum = exports.TicketStatusEnum || (exports.TicketStatusEnum = {}));
//# sourceMappingURL=ticket-status.enum.js.map