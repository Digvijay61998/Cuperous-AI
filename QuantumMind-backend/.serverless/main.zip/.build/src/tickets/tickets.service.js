"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var TicketsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const constant_1 = require("./constant");
const ticket_activities_enum_1 = require("./enums/ticket-activities.enum");
const visitor_service_1 = require("src/visitor/visitor.service");
const ticket_status_enum_1 = require("./enums/ticket-status.enum");
const get_subtitle_1 = require("src/util/get-subtitle");
const ticket_priority_1 = require("./enums/ticket-priority");
const event_emitter_1 = require("@nestjs/event-emitter");
const moment_1 = __importDefault(require("moment"));
let TicketsService = TicketsService_1 = class TicketsService {
    constructor(ticketModel, ticketDetailsModel, eventEmitter, visitorService) {
        this.ticketModel = ticketModel;
        this.ticketDetailsModel = ticketDetailsModel;
        this.eventEmitter = eventEmitter;
        this.visitorService = visitorService;
        this.logger = new common_1.Logger(TicketsService_1.name);
    }
    async create(createTicketDto) {
        try {
            const ticket = await this.ticketModel.create(createTicketDto);
            const activities = await this.ticketDetailsModel.create({
                ticket: ticket._id,
                message: `Service Request Created`,
                date: new Date().toISOString(),
                status: ticket_activities_enum_1.TicketActivitiesEnum.CREATED,
            });
            ticket.activities.push(activities);
            await ticket.save();
            await this.visitorService.addServiceRequests(createTicketDto.visitor, ticket._id);
            return ticket;
        }
        catch (error) {
            this.logger.error(`Error while creating ticket : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async assignTicketToMe(ticketId, user) {
        try {
            const ticket = await this.ticketModel.findOne({
                _id: ticketId,
            });
            if (!ticket) {
                throw new common_1.NotFoundException(`Ticket not found`);
            }
            ticket.agents.push(user._id);
            this.eventEmitter.emit("ticket.assigned.agent", {
                ticketId: ticket._id,
                agentId: user._id,
            });
            const activities = await this.ticketDetailsModel.create({
                ticket: ticket._id,
                message: `Ticket assigned to ${user.email}`,
                date: new Date().toISOString(),
                status: ticket_activities_enum_1.TicketActivitiesEnum.ASSIGNED,
            });
            ticket.activities.push(activities);
            await ticket.save();
            return ticket;
        }
        catch (error) {
            this.logger.error(`Error while assigning ticket : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async markAsResolved(ticketId, user) {
        try {
            const ticket = await this.ticketModel.findOne({
                _id: ticketId,
            });
            if (!ticket) {
                throw new common_1.NotFoundException(`Ticket not found`);
            }
            ticket.status = ticket_status_enum_1.TicketStatusEnum.CLOSED;
            ticket.closedAt = new Date();
            const activities = await this.ticketDetailsModel.create({
                ticket: ticket._id,
                message: `Ticket marked as resolved by ${user.email}`,
                date: new Date().toISOString(),
                status: ticket_activities_enum_1.TicketActivitiesEnum.RESOLVED,
            });
            ticket.activities.push(activities);
            await ticket.save();
            return ticket;
        }
        catch (error) {
            this.logger.error(`Error while assigning ticket : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, tags, status, startDate, bot, } = query;
            const endDate = query.endDate || new Date().toISOString();
            const queryObject = {};
            if (status)
                queryObject["status"] = status;
            if (tags)
                queryObject["tags"] = { $in: tags };
            if (bot)
                queryObject["bot"] = bot;
            if (startDate && endDate) {
                queryObject["createdAt"] = {
                    $gte: new Date(startDate),
                    $lte: new Date(endDate),
                };
            }
            const tickets = this.ticketModel
                .find(queryObject)
                .sort({ createdAt: -1 })
                .populate("agents", "name")
                .populate("bot", "name")
                .populate("visitor", "name email phone")
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                tickets.limit(limitOfDocuments);
            }
            const data = await tickets.exec();
            const count = await this.ticketModel.countDocuments(queryObject);
            return { data, count };
        }
        catch (error) {
            this.logger.error(`Error while getting all tickets : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findOne(id) {
        try {
            const ticket = await this.ticketModel
                .findOne({ _id: id })
                .populate("activities")
                .populate("agents", "name")
                .populate("bot", "name")
                .populate("visitor", "name email phone");
            if (!ticket)
                throw new common_1.NotFoundException("No Ticket found by this id");
            return ticket;
        }
        catch (error) {
            this.logger.error(`Error while getting ticket with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async update(id, updateTicketDto) {
        try {
            const ticket = await this.ticketModel.findByIdAndUpdate(id, updateTicketDto, {
                new: true,
            });
            return ticket;
        }
        catch (error) {
            this.logger.error(`Error while updating ticket with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async addActivity(id, ticketActivity) {
        try {
            const activity = await this.ticketDetailsModel.create(Object.assign(Object.assign({}, ticketActivity), { date: new Date().toISOString() }));
            const ticket = await this.ticketModel.findById(id);
            ticket.activities.push(activity._id);
            await ticket.save();
            return activity;
        }
        catch (error) {
            this.logger.error(`Error while adding activity to ticket with id ${id} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalCount(days = 7) {
        const total = await this.ticketModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.ticketModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - 60)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "ticket",
        };
    }
    async closedTickets(days = 7) {
        const total = await this.ticketModel.countDocuments({
            status: ticket_status_enum_1.TicketStatusEnum.CLOSED,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.ticketModel.countDocuments({
                status: ticket_status_enum_1.TicketStatusEnum.CLOSED,
                closedAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Closed",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "ticket",
        };
    }
    async openTickets(days = 7) {
        const total = await this.ticketModel.countDocuments({
            status: ticket_status_enum_1.TicketStatusEnum.OPEN,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.ticketModel.countDocuments({
                status: ticket_status_enum_1.TicketStatusEnum.OPEN,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Open",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "ticket",
        };
    }
    async ticketStats(days = 7) {
        return await Promise.all([
            this.getTotalCount(days),
            this.closedTickets(days),
            this.openTickets(days),
            this.CriticalTickets(days),
        ]);
    }
    async CriticalTickets(days = 7) {
        try {
            const total = await this.ticketModel.countDocuments({
                priority: ticket_priority_1.TicketPriorityEnum.CRITICAL,
            });
            let percentageChange = 0;
            if (total) {
                const agoCount = await this.ticketModel.countDocuments({
                    priority: ticket_priority_1.TicketPriorityEnum.CRITICAL,
                    createdAt: {
                        $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                    },
                });
                percentageChange = Math.round((agoCount / total) * 100);
            }
            return {
                stats: total,
                trendNumber: percentageChange,
                trend: percentageChange >= 0 ? "positive" : "negative",
                title: "Critical",
                subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
                type: "ticket",
            };
        }
        catch (error) {
            this.logger.error(`Error while getting critical tickets : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalTicketsReport() {
        try {
            const response = await this.ticketModel.aggregate([
                {
                    $group: {
                        _id: "$status",
                        total: { $sum: 1 },
                        closed: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.CLOSED] }, 1, 0],
                            },
                        },
                        open: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.OPEN] }, 1, 0],
                            },
                        },
                    },
                },
                {
                    $project: {
                        _id: 0,
                    },
                },
            ]);
            return response[0];
        }
        catch (error) {
            this.logger.error(`Error while getting total tickets : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async dayWisePerformance(query) {
        const { id: botId, startDate } = query;
        let endDate = query.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = botId;
        }
        try {
            const response = await this.ticketModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $isoDayOfWeek: "$createdAt",
                        },
                        total: { $sum: 1 },
                        closed: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.CLOSED] }, 1, 0],
                            },
                        },
                        open: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.OPEN] }, 1, 0],
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        day: {
                            $switch: {
                                branches: [
                                    { case: { $eq: ["$_id", 1] }, then: "MON" },
                                    { case: { $eq: ["$_id", 2] }, then: "TUE" },
                                    { case: { $eq: ["$_id", 3] }, then: "WED" },
                                    { case: { $eq: ["$_id", 4] }, then: "THU" },
                                    { case: { $eq: ["$_id", 5] }, then: "FRI" },
                                    { case: { $eq: ["$_id", 6] }, then: "SAT" },
                                    { case: { $eq: ["$_id", 7] }, then: "SUN" },
                                ],
                            },
                        },
                        total: 1,
                        open: 1,
                        closed: 1,
                        _id: 0,
                    },
                },
            ]);
            return response;
        }
        catch (error) {
            this.logger.error("Error while getting day wise performance : ${error.message}");
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async dateWisePerformance(query) {
        const { id: botId, startDate } = query;
        let endDate = query.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (botId) {
            match["bot"] = botId;
        }
        try {
            const response = await this.ticketModel.aggregate([
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$createdAt",
                            },
                        },
                        total: { $sum: 1 },
                        closed: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.CLOSED] }, 1, 0],
                            },
                        },
                        open: {
                            $sum: {
                                $cond: [{ $eq: ["$status", ticket_status_enum_1.TicketStatusEnum.OPEN] }, 1, 0],
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        date: "$_id",
                        total: 1,
                        open: 1,
                        closed: 1,
                        _id: 0,
                    },
                },
            ]);
            return response;
        }
        catch (error) {
            this.logger.error("Error while getting date wise performance : ${error.message}");
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async homeTicketCount(filter, status) {
        if (!filter)
            filter = "day";
        try {
            const total = await this.ticketModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().startOf(filter).toISOString()),
                },
                status: status || { $ne: "" },
            });
            let percentageChange = 0;
            const previousTotal = await this.ticketModel.countDocuments({
                createdAt: {
                    $gte: new Date((0, moment_1.default)().subtract(1, filter).startOf(filter).toISOString()),
                },
                status: status || { $ne: "" },
            });
            if (previousTotal) {
                percentageChange = Math.round(((total - previousTotal) / previousTotal) * 100);
            }
            return {
                stats: total,
                trendNumber: Math.abs(percentageChange),
                trend: percentageChange > 0 ? "positive" : "negative",
                title: status === ticket_status_enum_1.TicketStatusEnum.OPEN ? "Pendig Tickets" : "Total Tickets",
                type: "service_request",
            };
        }
        catch (error) {
            this.logger.error(`Error while getting home  count ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
TicketsService = TicketsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.TICKET_PROVIDER)),
    __param(1, (0, common_1.Inject)(constant_1.TICKET_DETAILS_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        mongoose_1.Model,
        event_emitter_1.EventEmitter2,
        visitor_service_1.VisitorService])
], TicketsService);
exports.TicketsService = TicketsService;
//# sourceMappingURL=tickets.service.js.map