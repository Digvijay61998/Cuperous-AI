/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose/types/inferschematype" />
import { Model } from "mongoose";
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { CreateActivityDto } from "./dto/create-activity.dto";
import { CreateTicketDto } from "./dto/create-ticket.dto";
import { UpdateTicketDto } from "./dto/update-ticket.dto";
import { TicketActivitiesDocument } from "./entities/ticket-activities.entity";
import { TicketDocument } from "./entities/ticket.entity";
import { VisitorService } from "src/visitor/visitor.service";
import { ReportParamsDto } from "src/util/report-params.dto";
import { SearchParamDto } from "./dto/search-param.dto";
import { EventEmitter2 } from "@nestjs/event-emitter";
export declare class TicketsService {
    private ticketModel;
    private ticketDetailsModel;
    private readonly eventEmitter;
    private visitorService;
    private readonly logger;
    constructor(ticketModel: Model<TicketDocument>, ticketDetailsModel: Model<TicketActivitiesDocument>, eventEmitter: EventEmitter2, visitorService: VisitorService);
    create(createTicketDto: CreateTicketDto): Promise<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    assignTicketToMe(ticketId: string, user: JwtPayload): Promise<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    markAsResolved(ticketId: string, user: JwtPayload): Promise<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query: SearchParamDto): Promise<{
        data: Omit<Omit<Omit<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>, never>, never>[];
        count: number;
    }>;
    findOne(id: string): Promise<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, updateTicketDto: UpdateTicketDto): Promise<import("./entities/ticket.entity").Ticket & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    addActivity(id: string, ticketActivity: CreateActivityDto): Promise<import("./entities/ticket-activities.entity").TicketActivities & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    closedTickets(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    openTickets(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    ticketStats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    CriticalTickets(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getTotalTicketsReport(): Promise<any>;
    dayWisePerformance(query: ReportParamsDto): Promise<any[]>;
    dateWisePerformance(query: ReportParamsDto): Promise<any[]>;
    homeTicketCount(filter: any, status?: string): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        type: string;
    }>;
}
