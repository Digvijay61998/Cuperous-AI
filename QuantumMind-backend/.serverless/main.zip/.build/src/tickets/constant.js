"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TICKET_DETAILS_PROVIDER = exports.TICKET_PROVIDER = void 0;
exports.TICKET_PROVIDER = 'TICKET_MODEL';
exports.TICKET_DETAILS_PROVIDER = 'TICKET_DETAILS_MODEL';
//# sourceMappingURL=constant.js.map