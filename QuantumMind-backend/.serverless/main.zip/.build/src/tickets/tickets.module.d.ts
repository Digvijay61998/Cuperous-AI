export declare class TicketsModule {
}
