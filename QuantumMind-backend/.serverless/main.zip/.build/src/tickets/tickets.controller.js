"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const util_1 = require("src/util");
const create_ticket_dto_1 = require("./dto/create-ticket.dto");
const update_ticket_dto_1 = require("./dto/update-ticket.dto");
const tickets_service_1 = require("./tickets.service");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const report_params_dto_1 = require("src/util/report-params.dto");
const search_param_dto_1 = require("./dto/search-param.dto");
const ticket_status_enum_1 = require("./enums/ticket-status.enum");
let TicketsController = class TicketsController {
    constructor(ticketsService) {
        this.ticketsService = ticketsService;
    }
    create(createTicketDto) {
        return this.ticketsService.create(createTicketDto);
    }
    async findAll(query) {
        return await this.ticketsService.findAll(query);
    }
    async assignToMe(user, id) {
        return await this.ticketsService.assignTicketToMe(id, user);
    }
    async markAsResolved(id, user) {
        return await this.ticketsService.markAsResolved(id, user);
    }
    async getStats() {
        return await this.ticketsService.ticketStats();
    }
    async getHomeStats(time) {
        return await this.ticketsService.homeTicketCount(time);
    }
    async getHomePendiNgStats(time) {
        return await this.ticketsService.homeTicketCount(time, ticket_status_enum_1.TicketStatusEnum.OPEN);
    }
    async findOne(id) {
        return await this.ticketsService.findOne(id);
    }
    async getTotalReport() {
        return await this.ticketsService.getTotalTicketsReport();
    }
    async dayWisePerformanceReport(query) {
        return await this.ticketsService.dayWisePerformance(query);
    }
    async dateWisePerformanceReport(query) {
        return await this.ticketsService.dateWisePerformance(query);
    }
    async update(id, updateTicketDto) {
        return await this.ticketsService.update(id, updateTicketDto);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_ticket_dto_1.CreateTicketDto]),
    __metadata("design:returntype", void 0)
], TicketsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_param_dto_1.SearchParamDto]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('assign-to-me'),
    __param(0, (0, util_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "assignToMe", null);
__decorate([
    (0, common_1.Get)('mark-as-resolved'),
    __param(0, (0, common_1.Query)('id')),
    __param(1, (0, util_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "markAsResolved", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('stats/home'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)('time')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "getHomeStats", null);
__decorate([
    (0, common_1.Get)('stats/home/pending'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)('time')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "getHomePendiNgStats", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('report/total'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "getTotalReport", null);
__decorate([
    (0, common_1.Get)('report/day-wise-performance'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "dayWisePerformanceReport", null);
__decorate([
    (0, common_1.Get)('report/date-wise-performance'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [report_params_dto_1.ReportParamsDto]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "dateWisePerformanceReport", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_ticket_dto_1.UpdateTicketDto]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "update", null);
TicketsController = __decorate([
    (0, common_1.Controller)('tickets'),
    (0, swagger_1.ApiTags)('Tickets'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [tickets_service_1.TicketsService])
], TicketsController);
exports.TicketsController = TicketsController;
//# sourceMappingURL=tickets.controller.js.map