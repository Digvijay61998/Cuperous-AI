import * as mongoose from "mongoose";
import { Bot } from "src/bots/entities";
import { VisitorDocument } from "src/visitor/entities/visitor.entity";
import { TicketActivities } from "./ticket-activities.entity";
export type TicketDocument = Ticket & mongoose.Document;
export declare class Ticket {
    ticketId: string;
    subject: string;
    description: string;
    status: string;
    priority: string;
    visitor: VisitorDocument;
    bot: Bot;
    agents: string[];
    activities: TicketActivities[];
    closedAt: Date;
    conversationId: string;
    tags: string[];
}
export declare const TicketSchema: mongoose.Schema<Ticket, mongoose.Model<Ticket, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Ticket>;
