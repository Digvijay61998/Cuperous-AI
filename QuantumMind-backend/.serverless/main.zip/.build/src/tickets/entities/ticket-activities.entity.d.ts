/// <reference types="node" />
import { Agent } from 'http';
import * as mongoose from 'mongoose';
import { TicketActivitiesEnum } from '../enums/ticket-activities.enum';
import { Ticket } from './ticket.entity';
export type TicketActivitiesDocument = TicketActivities & mongoose.Document;
export declare class TicketActivities {
    ticket: Ticket;
    message: string;
    status: TicketActivitiesEnum;
    date: Date;
    agent: Agent;
}
export declare const TicketActivitiesSchema: mongoose.Schema<TicketActivities, mongoose.Model<TicketActivities, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, TicketActivities>;
