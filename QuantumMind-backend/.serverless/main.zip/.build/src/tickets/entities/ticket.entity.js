"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketSchema = exports.Ticket = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const http_1 = require("http");
const mongoose = __importStar(require("mongoose"));
const entities_1 = require("src/bots/entities");
const util_1 = require("src/util");
const visitor_entity_1 = require("src/visitor/entities/visitor.entity");
const ticket_status_enum_1 = require("../enums/ticket-status.enum");
const ticket_priority_1 = require("../enums/ticket-priority");
const ticket_activities_entity_1 = require("./ticket-activities.entity");
let Ticket = class Ticket {
};
__decorate([
    (0, mongoose_1.Prop)({
        default: () => (0, util_1.generateId)("SR", 6),
    }),
    __metadata("design:type", String)
], Ticket.prototype, "ticketId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        required: true,
    }),
    __metadata("design:type", String)
], Ticket.prototype, "subject", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Ticket.prototype, "description", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: ticket_status_enum_1.TicketStatusEnum.OPEN,
        enum: ticket_status_enum_1.TicketStatusEnum,
    }),
    __metadata("design:type", String)
], Ticket.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: ticket_priority_1.TicketPriorityEnum.LOW,
        enum: ticket_priority_1.TicketPriorityEnum,
    }),
    __metadata("design:type", String)
], Ticket.prototype, "priority", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: visitor_entity_1.Visitor.name,
    }),
    __metadata("design:type", Object)
], Ticket.prototype, "visitor", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: entities_1.Bot.name,
        required: true,
    }),
    __metadata("design:type", entities_1.Bot)
], Ticket.prototype, "bot", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: http_1.Agent.name,
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Ticket.prototype, "agents", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: ticket_activities_entity_1.TicketActivities.name,
            },
        ],
    }),
    __metadata("design:type", Array)
], Ticket.prototype, "activities", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], Ticket.prototype, "closedAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: "Conversation",
    }),
    __metadata("design:type", String)
], Ticket.prototype, "conversationId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: [],
    }),
    __metadata("design:type", Array)
], Ticket.prototype, "tags", void 0);
Ticket = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
    })
], Ticket);
exports.Ticket = Ticket;
exports.TicketSchema = mongoose_1.SchemaFactory.createForClass(Ticket);
//# sourceMappingURL=ticket.entity.js.map