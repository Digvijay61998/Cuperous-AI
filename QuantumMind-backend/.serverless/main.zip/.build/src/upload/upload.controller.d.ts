/// <reference types="multer" />
export declare class UploadController {
    uploadFile(file: Express.Multer.File): Promise<{
        url: string;
        error?: undefined;
    } | {
        error: string;
        url?: undefined;
    }>;
}
