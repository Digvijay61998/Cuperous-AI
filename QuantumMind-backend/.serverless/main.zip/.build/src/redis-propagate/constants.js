"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEND_TO_OTHER = exports.SEND_TO_SELF = void 0;
exports.SEND_TO_SELF = 'send-to-self';
exports.SEND_TO_OTHER = 'send-to-other';
//# sourceMappingURL=constants.js.map