"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisPropagatorService = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const socket_state_service_1 = require("src/socket/socket-state.service");
const redis_service_1 = require("../redis/redis.service");
const constants_1 = require("./constants");
const event_emitter_1 = require("@nestjs/event-emitter");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
let RedisPropagatorService = class RedisPropagatorService {
    constructor(socketStateService, redisService, eventEmitter) {
        this.socketStateService = socketStateService;
        this.redisService = redisService;
        this.eventEmitter = eventEmitter;
        this.consumeSendEvent = (eventInfo) => {
            const { userId, event, data, platform } = eventInfo;
            const userData = this.socketStateService.getUserData(userId);
            if (!userData)
                return;
            const { ctx } = userData;
            if (platform === platform_enum_1.PlatformEnum.WHATSAPP) {
                this.eventEmitter.emit("send-whatsapp-message", {
                    ctx,
                    message: data.message,
                });
            }
            else if (platform === platform_enum_1.PlatformEnum.FACEBOOK) {
                this.eventEmitter.emit("send-facebook-message", {
                    ctx,
                    message: data.message,
                });
            }
            else if (platform === platform_enum_1.PlatformEnum.TELEGRAM) {
                this.eventEmitter.emit("send-telegram-message", {
                    ctx,
                    message: data.message,
                });
            }
            else {
                const sockets = this.socketStateService.getSocket(userId);
                sockets &&
                    sockets.length &&
                    sockets.forEach((socket) => {
                        socket.emit(event, data);
                    });
            }
        };
        this.consumeSendToSelf = (eventInfo) => {
            const { userId, event, data, socketId } = eventInfo;
            this.socketStateService.getSocket(userId).forEach((socket) => {
                if (socket.id !== socketId) {
                    socket.emit(event, data);
                }
            });
        };
        this.redisService
            .fromEvent(constants_1.SEND_TO_OTHER)
            .pipe((0, rxjs_1.tap)(this.consumeSendEvent))
            .subscribe();
        this.redisService
            .fromEvent(constants_1.SEND_TO_SELF)
            .pipe((0, rxjs_1.tap)(this.consumeSendToSelf))
            .subscribe();
    }
    injectSocketServer(server) {
        this.socketServer = server;
        return this;
    }
    propogateToSelf(eventInfo) {
        if (!eventInfo.userId) {
            return false;
        }
        this.redisService.publish(constants_1.SEND_TO_SELF, eventInfo);
        return true;
    }
    propagateEvent(eventInfo) {
        if (!eventInfo.userId) {
            return false;
        }
        this.redisService.publish(constants_1.SEND_TO_OTHER, eventInfo);
        return true;
    }
};
RedisPropagatorService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [socket_state_service_1.SocketStateService,
        redis_service_1.RedisService,
        event_emitter_1.EventEmitter2])
], RedisPropagatorService);
exports.RedisPropagatorService = RedisPropagatorService;
//# sourceMappingURL=redis-propagate.service.js.map