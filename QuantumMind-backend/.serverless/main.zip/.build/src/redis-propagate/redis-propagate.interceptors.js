"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisPropagatorInterceptor = void 0;
const common_1 = require("@nestjs/common");
const redis_propagate_service_1 = require("./redis-propagate.service");
const rxjs_1 = require("rxjs");
let RedisPropagatorInterceptor = class RedisPropagatorInterceptor {
    constructor(redisPropagatorService) {
        this.redisPropagatorService = redisPropagatorService;
    }
    intercept(context, next) {
        const socket = context.switchToWs().getClient();
        return next.handle().pipe((0, rxjs_1.tap)((data) => {
            var _a;
            this.redisPropagatorService.propogateToSelf(Object.assign(Object.assign({}, data), { socketId: socket.id, userId: (_a = socket.auth) === null || _a === void 0 ? void 0 : _a.userId }));
        }));
    }
};
RedisPropagatorInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [redis_propagate_service_1.RedisPropagatorService])
], RedisPropagatorInterceptor);
exports.RedisPropagatorInterceptor = RedisPropagatorInterceptor;
//# sourceMappingURL=redis-propagate.interceptors.js.map