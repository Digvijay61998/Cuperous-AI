export declare const SEND_TO_SELF = "send-to-self";
export declare const SEND_TO_OTHER = "send-to-other";
