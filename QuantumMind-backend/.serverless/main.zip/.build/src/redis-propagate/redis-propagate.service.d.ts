import { SocketStateService } from "src/socket/socket-state.service";
import { RedisService } from "../redis/redis.service";
import { RedisSocketEventSendDTO } from "./dto/RedisSocketEventSend.dto";
import { EventEmitter2 } from "@nestjs/event-emitter";
import { Server } from "socket.io";
export declare class RedisPropagatorService {
    private readonly socketStateService;
    private readonly redisService;
    private readonly eventEmitter;
    private socketServer;
    constructor(socketStateService: SocketStateService, redisService: RedisService, eventEmitter: EventEmitter2);
    injectSocketServer(server: Server): RedisPropagatorService;
    propogateToSelf(eventInfo: RedisSocketEventSendDTO): boolean;
    propagateEvent(eventInfo: RedisSocketEventSendDTO): boolean;
    private consumeSendEvent;
    private consumeSendToSelf;
}
