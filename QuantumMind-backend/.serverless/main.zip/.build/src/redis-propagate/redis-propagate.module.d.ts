export declare class RedisPropagateModule {
}
