export declare class RedisSocketEventSendDTO {
    readonly userId: string;
    readonly socketId?: string;
    readonly event: string;
    readonly data: any;
    readonly platform?: string;
}
