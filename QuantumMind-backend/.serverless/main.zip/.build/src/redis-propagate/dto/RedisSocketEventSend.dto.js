"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisSocketEventSendDTO = void 0;
class RedisSocketEventSendDTO {
}
exports.RedisSocketEventSendDTO = RedisSocketEventSendDTO;
//# sourceMappingURL=RedisSocketEventSend.dto.js.map