import { NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { WsResponse } from '@nestjs/websockets';
import { RedisPropagatorService } from './redis-propagate.service';
import { Observable } from 'rxjs';
export declare class RedisPropagatorInterceptor<T> implements NestInterceptor<T, WsResponse<T>> {
    private readonly redisPropagatorService;
    constructor(redisPropagatorService: RedisPropagatorService);
    intercept(context: ExecutionContext, next: CallHandler): Observable<WsResponse<T>>;
}
