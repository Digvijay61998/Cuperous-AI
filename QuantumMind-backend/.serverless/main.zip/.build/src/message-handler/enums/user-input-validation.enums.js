"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationInputList = exports.UserInputValidationEnum = void 0;
var UserInputValidationEnum;
(function (UserInputValidationEnum) {
    UserInputValidationEnum["EMAIL"] = "engage.email";
    UserInputValidationEnum["PHONE"] = "engage.phone_number";
    UserInputValidationEnum["NUMBER"] = "engage.number";
    UserInputValidationEnum["DATE"] = "engage.date";
    UserInputValidationEnum["ALPHANUMERIC"] = "engage.alphanumeric";
    UserInputValidationEnum["ANY"] = "engage.any";
    UserInputValidationEnum["COUNTRY"] = "engage.country";
    UserInputValidationEnum["TEXT"] = "engage.text";
    UserInputValidationEnum["YES_NO"] = "engage.yes_no";
    UserInputValidationEnum["YES"] = "engage.yes";
    UserInputValidationEnum["NO"] = "engage.no";
})(UserInputValidationEnum = exports.UserInputValidationEnum || (exports.UserInputValidationEnum = {}));
exports.ValidationInputList = [
    {
        value: UserInputValidationEnum.EMAIL,
        label: 'Email',
    },
    {
        value: UserInputValidationEnum.PHONE,
        label: 'Phone',
    },
    {
        value: UserInputValidationEnum.NUMBER,
        label: 'Number',
    },
    {
        value: UserInputValidationEnum.DATE,
        label: 'Date',
    },
    {
        value: UserInputValidationEnum.ALPHANUMERIC,
        label: 'Alphanumeric',
    },
    {
        value: UserInputValidationEnum.ANY,
        label: 'Any',
    },
    {
        value: UserInputValidationEnum.COUNTRY,
        label: 'Country',
    },
    {
        value: UserInputValidationEnum.TEXT,
        label: 'Text',
    },
    {
        value: UserInputValidationEnum.YES_NO,
        label: 'Yes/No',
    },
    {
        value: UserInputValidationEnum.YES,
        label: 'Yes',
    },
];
//# sourceMappingURL=user-input-validation.enums.js.map