"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotNodeStateEnum = void 0;
var BotNodeStateEnum;
(function (BotNodeStateEnum) {
    BotNodeStateEnum["NEW"] = "NEW";
    BotNodeStateEnum["AWAITING_USER_INPUT"] = "AWAITING_USER_INPUT";
    BotNodeStateEnum["VISITED"] = "VISITED";
})(BotNodeStateEnum = exports.BotNodeStateEnum || (exports.BotNodeStateEnum = {}));
//# sourceMappingURL=bot-node-state.enum.js.map