export declare enum UserInputValidationEnum {
    EMAIL = "engage.email",
    PHONE = "engage.phone_number",
    NUMBER = "engage.number",
    DATE = "engage.date",
    ALPHANUMERIC = "engage.alphanumeric",
    ANY = "engage.any",
    COUNTRY = "engage.country",
    TEXT = "engage.text",
    YES_NO = "engage.yes_no",
    YES = "engage.yes",
    NO = "engage.no"
}
export declare const ValidationInputList: {
    value: UserInputValidationEnum;
    label: string;
}[];
