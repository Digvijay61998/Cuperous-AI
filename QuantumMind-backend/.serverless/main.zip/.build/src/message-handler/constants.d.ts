export declare const MESSAGE_HANDLER_QUEUE = "message-handler";
