import { Job } from "bull";
import { RedisPropagatorService } from "src/redis-propagate/redis-propagate.service";
import { SocketStateService } from "src/socket/socket-state.service";
import { EventEmitter2 } from "@nestjs/event-emitter";
import { MessageHandlerService } from "./message-handler.service";
export declare class MessageQueueConsumer {
    private readonly redisPropagatorService;
    private readonly socketStateService;
    private readonly eventEmitter;
    private readonly messageHandlerService;
    private readonly logger;
    private delay;
    constructor(redisPropagatorService: RedisPropagatorService, socketStateService: SocketStateService, eventEmitter: EventEmitter2, messageHandlerService: MessageHandlerService);
    handleJob(job: Job): Promise<{}>;
    wait(ms: number): Promise<unknown>;
}
