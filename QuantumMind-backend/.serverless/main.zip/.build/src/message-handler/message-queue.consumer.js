"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MessageQueueConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageQueueConsumer = void 0;
const bull_1 = require("@nestjs/bull");
const common_1 = require("@nestjs/common");
const constants_1 = require("./constants");
const redis_propagate_service_1 = require("src/redis-propagate/redis-propagate.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const chat_type_enum_1 = require("src/conversation/enums/chat-type.enum");
const util_1 = require("src/util");
const event_emitter_1 = require("@nestjs/event-emitter");
const mode_enum_1 = require("src/widget/enums/mode.enum");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
const message_handler_service_1 = require("./message-handler.service");
let MessageQueueConsumer = MessageQueueConsumer_1 = class MessageQueueConsumer {
    constructor(redisPropagatorService, socketStateService, eventEmitter, messageHandlerService) {
        this.redisPropagatorService = redisPropagatorService;
        this.socketStateService = socketStateService;
        this.eventEmitter = eventEmitter;
        this.messageHandlerService = messageHandlerService;
        this.logger = new common_1.Logger(MessageQueueConsumer_1.name);
        this.delay = 0;
    }
    async handleJob(job) {
        try {
            const { message, userId, event } = job.data;
            const userData = this.socketStateService.getUserData(userId);
            if (!userData)
                return;
            const { botId, conversationId, mode, platform, handledByAgent } = userData;
            let progress = 0;
            await Promise.all(message.map(async (ele, index) => {
                if (ele.type === chat_type_enum_1.ChatTypeEnum.RANDOM_TEXT) {
                    ele.value =
                        ele.values.length > 0
                            ? ele.values[Math.floor(Math.random() * ele.values.length)]
                            : "";
                    ele.type = chat_type_enum_1.ChatTypeEnum.TEXT;
                }
                const messageResponse = {
                    id: (0, util_1.generateId)("message", 10),
                    senderId: botId,
                    type: ele.type,
                    value: ele.value,
                    buttons: ele.buttons,
                    time: new Date(),
                    delay: 2000,
                    switchToAgent: ele.switchToAgent || false,
                    agentId: ele.agentId || "",
                    location: ele.location,
                    info: ele.info,
                    handledByAgent: handledByAgent || false,
                };
                await this.wait(index * 500);
                if (mode !== mode_enum_1.ModeEnum.preview) {
                    this.eventEmitter.emit("create.new.chat", {
                        message: ele.value,
                        type: ele.type,
                        sender: botId,
                        conversationId: conversationId,
                    });
                }
                if (platform === platform_enum_1.PlatformEnum.TELEGRAM) {
                    await this.messageHandlerService.sendMessageToTelegram(messageResponse);
                }
                else if (platform === platform_enum_1.PlatformEnum.FACEBOOK)
                    await this.messageHandlerService.sendFacebookMessage(messageResponse);
                else if (platform === platform_enum_1.PlatformEnum.WHATSAPP)
                    await this.messageHandlerService.sendWhatsappMessage(messageResponse);
                else {
                    this.redisPropagatorService.propagateEvent({
                        userId,
                        event,
                        data: {
                            message: messageResponse,
                        },
                    });
                }
                progress = Math.floor((index / message.length) * 100);
                return await job.progress(progress);
            }));
            job.moveToCompleted("done", true);
            return {};
        }
        catch (error) {
            job.moveToFailed({ message: error.message });
            this.logger.error(`Error in job ${job.id}: ${error.message}`);
        }
    }
    async wait(ms) {
        return await new Promise((resolve) => setTimeout(resolve, ms));
    }
};
__decorate([
    (0, bull_1.Process)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageQueueConsumer.prototype, "handleJob", null);
MessageQueueConsumer = MessageQueueConsumer_1 = __decorate([
    (0, bull_1.Processor)(constants_1.MESSAGE_HANDLER_QUEUE),
    __metadata("design:paramtypes", [redis_propagate_service_1.RedisPropagatorService,
        socket_state_service_1.SocketStateService,
        event_emitter_1.EventEmitter2,
        message_handler_service_1.MessageHandlerService])
], MessageQueueConsumer);
exports.MessageQueueConsumer = MessageQueueConsumer;
//# sourceMappingURL=message-queue.consumer.js.map