export declare class MessageHandlerModule {
}
