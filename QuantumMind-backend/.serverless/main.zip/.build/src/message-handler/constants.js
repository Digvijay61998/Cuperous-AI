"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MESSAGE_HANDLER_QUEUE = void 0;
exports.MESSAGE_HANDLER_QUEUE = "message-handler";
//# sourceMappingURL=constants.js.map