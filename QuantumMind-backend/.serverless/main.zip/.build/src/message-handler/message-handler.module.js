"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageHandlerModule = void 0;
const axios_1 = require("@nestjs/axios");
const bull_1 = require("@nestjs/bull");
const common_1 = require("@nestjs/common");
const questions_module_1 = require("src/questions/questions.module");
const constants_1 = require("./constants");
const message_handler_service_1 = require("./message-handler.service");
const message_queue_consumer_1 = require("./message-queue.consumer");
let MessageHandlerModule = class MessageHandlerModule {
};
MessageHandlerModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [message_handler_service_1.MessageHandlerService, message_queue_consumer_1.MessageQueueConsumer],
        exports: [message_handler_service_1.MessageHandlerService],
        imports: [
            questions_module_1.QuestionsModule,
            axios_1.HttpModule.register({}),
            bull_1.BullModule.registerQueue({ name: constants_1.MESSAGE_HANDLER_QUEUE }),
        ],
    })
], MessageHandlerModule);
exports.MessageHandlerModule = MessageHandlerModule;
//# sourceMappingURL=message-handler.module.js.map