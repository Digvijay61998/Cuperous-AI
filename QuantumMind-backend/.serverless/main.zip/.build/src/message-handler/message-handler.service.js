"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MessageHandlerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageHandlerService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const class_validator_1 = require("class-validator");
const agent_service_1 = require("src/agent/agent.service");
const bots_service_1 = require("src/bots/bots.service");
const node_type_enum_1 = require("src/bots/enums/node-type.enum");
const conversation_service_1 = require("src/conversation/conversation.service");
const chat_type_enum_1 = require("src/conversation/enums/chat-type.enum");
const questions_service_1 = require("src/questions/questions.service");
const redis_propagate_service_1 = require("src/redis-propagate/redis-propagate.service");
const segments_service_1 = require("src/segments/segments.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const tickets_service_1 = require("src/tickets/tickets.service");
const unanswered_service_1 = require("src/unanswered/unanswered.service");
const util_1 = require("src/util");
const webhook_status_enum_1 = require("src/webhook/enums/webhook-status.enum");
const webhook_service_1 = require("src/webhook/webhook.service");
const mode_enum_1 = require("src/widget/enums/mode.enum");
const telegraf_1 = require("telegraf");
const bot_node_state_enum_1 = require("./enums/bot-node-state.enum");
const user_input_validation_enums_1 = require("./enums/user-input-validation.enums");
const axios_1 = require("@nestjs/axios");
const rxjs_1 = require("rxjs");
const bull_1 = require("@nestjs/bull");
const constants_1 = require("./constants");
const config_1 = require("@nestjs/config");
let MessageHandlerService = MessageHandlerService_1 = class MessageHandlerService {
    constructor(botsService, socketStateService, segmentsService, webhookService, ticketsService, conversationService, redisPropagatorService, agentService, unansweredService, questionsService, eventEmitter, httpService, configService, messageHandlerQueue) {
        this.botsService = botsService;
        this.socketStateService = socketStateService;
        this.segmentsService = segmentsService;
        this.webhookService = webhookService;
        this.ticketsService = ticketsService;
        this.conversationService = conversationService;
        this.redisPropagatorService = redisPropagatorService;
        this.agentService = agentService;
        this.unansweredService = unansweredService;
        this.questionsService = questionsService;
        this.eventEmitter = eventEmitter;
        this.httpService = httpService;
        this.configService = configService;
        this.messageHandlerQueue = messageHandlerQueue;
        this.logger = new common_1.Logger(MessageHandlerService_1.name);
        this.delay = {};
    }
    async setNextNode(nodeId, userId) {
        const node = await this.botsService.getBotNode(nodeId);
        this.socketStateService.updateUserData(userId, {
            currentNode: node,
        });
    }
    maskCreditCard(creditcard) {
        const len = creditcard.length;
        const mastercreditcard = creditcard.slice(0, 2) + "*".repeat(len - 6) + creditcard.slice(-4);
        return mastercreditcard;
    }
    async handleBlockedContent() {
        const userId = this.user.auth.userId;
        return await this.sendBotMessage(userId, [
            {
                type: "text",
                value: "Sorry, you are not allowed to send this message",
            },
        ]);
    }
    async handleMessage(message, user, type = "text", language = "english", ctx) {
        var _a, _b;
        this.user = user;
        this.language = language;
        const userId = this.user.auth.userId;
        this.ctx = ctx;
        const userData = this.socketStateService.getUserData(userId);
        if (!userData)
            return;
        const { mode, conversationId, currentNode } = userData;
        if (!currentNode)
            return;
        if (mode !== mode_enum_1.ModeEnum.preview && conversationId && message) {
            const chatId = (0, util_1.generateId)("chat", 10);
            this.chatId = chatId;
            this.eventEmitter.emit("create.new.chat", {
                sender: userId,
                message: message,
                type: type,
                conversationId,
                chatId,
            });
        }
        const blockedContent = ((_b = (_a = this.socketStateService.getUserData(userId)) === null || _a === void 0 ? void 0 : _a.botSettings) === null || _b === void 0 ? void 0 : _b.blockedContent) || [];
        const isBlocked = blockedContent.some((content) => {
            if (message && message.toLowerCase().includes(content.toLowerCase())) {
                return this.handleBlockedContent();
            }
        });
        if (isBlocked) {
            return;
        }
        if (type === "goto") {
            const step = await this.botsService.getBotNode(message);
            this.socketStateService.updateUserData(userId, {
                currentNode: step,
            });
            return this.handleNode(step, message, userId);
        }
        message = message.trim().toLowerCase();
        if (message === "start" || message === "reset" || message === "restart") {
            const { startNode, botSettings, role } = this.socketStateService.getUserData(userId);
            await this.sendBotMessage(userId, [
                {
                    type: "text",
                    value: (botSettings === null || botSettings === void 0 ? void 0 : botSettings.welcomeMessages) ||
                        "Welcome to the bot, how can I help you?",
                },
            ]);
            if (startNode) {
                this.socketStateService.updateUserData(userId, {
                    currentNode: startNode,
                    BotNodeState: {},
                    questionNodeState: {},
                    attributes: {},
                });
                return this.handleNode(startNode, message, userId);
            }
        }
        const list = [node_type_enum_1.NodeTypeEnum.QUESTIONS, node_type_enum_1.NodeTypeEnum.USER_INPUT];
        if (list.includes(currentNode.nodeType)) {
            this.delay[conversationId] = parseInt(this.configService.get("delay.node"));
        }
        await this.handleNode(currentNode, message, userId, language);
    }
    async handleNode(currentNode, message, userId, language = "english") {
        var _a, _b;
        try {
            const userdata = this.socketStateService.getUserData(userId);
            if (!userdata)
                return;
            const { conversationId, defaultFallback } = userdata;
            if (!currentNode) {
                return this.defaultFallback(message, defaultFallback, userId);
            }
            if (currentNode.id !==
                this.socketStateService.getUserData(userId).currentNode.id) {
                this.socketStateService.updateUserData(userId, {
                    currentNode,
                });
            }
            this.logger.verbose(`current Node: ${currentNode.nodeType} ${currentNode.id}`);
            switch (currentNode.nodeType) {
                case node_type_enum_1.NodeTypeEnum.START_NODE:
                    return await this.handleStartNode(currentNode, message, userId, language);
                case node_type_enum_1.NodeTypeEnum.BOT_RESPONSE:
                    return await this.handleBotResponse(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.USER_INPUT:
                    return await this.handleUserInput(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.FALL_BACK:
                    return await this.defaultFallback(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.ADD_TO_SEGMENT:
                    return await this.handleAddToSegment(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.REMOVE_FROM_SEGMENT:
                    return await this.handleRemoveFromSegment(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.WEBHOOK:
                    return await this.handleWebHookCall(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.TICKET:
                    return await this.handleCreateTicket(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.GO_TO_STEP:
                    return await this.handleGoToStep(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.SUCCESS:
                    return await this.handleSuccessNode(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.FAILURE:
                    return await this.handleFailureNode(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.TRANSFER_TO_AGENT:
                    return await this.TransferToAgent(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.QUESTIONS:
                    return await this.handleQuestion(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.FILE_ATTACHMENT:
                    return await this.handleAttachmentInput(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.SET_ATTRIBUTES:
                    return await this.handleSetAttributes(message, currentNode, userId);
                case node_type_enum_1.NodeTypeEnum.CLOSE_CHAT:
                    return await this.handleCloseChat(message, currentNode, userId);
                default:
                    return await this.defaultFallback(message, currentNode, userId);
            }
        }
        catch (error) {
            this.logger.error(`Error in Handling Node : ${error.message}`);
            return await this.sendBotMessage(userId, [
                {
                    type: "text",
                    value: ((_b = (_a = this.socketStateService.getUserData(userId)) === null || _a === void 0 ? void 0 : _a.botSettings) === null || _b === void 0 ? void 0 : _b.fallbackMessage) ||
                        "I am sorry, I am not able to understand you",
                },
            ]);
        }
    }
    async handleStartNode(currentNode, message, userId, language) {
        const NextNodes = await Promise.all(currentNode.next.map(async (nodeId) => {
            return await this.botsService.getBotNode(nodeId);
        }));
        const defaultFallback = NextNodes.find((node) => node.nodeType === node_type_enum_1.NodeTypeEnum.FALL_BACK);
        this.socketStateService.updateUserData(userId, { defaultFallback });
        const otherNode = NextNodes.find((node) => node.nodeType !== node_type_enum_1.NodeTypeEnum.FALL_BACK);
        const startMessagesList = [
            "start",
            "reset",
            "restart",
            "hi",
            "hello",
            "hey",
            "help",
        ];
        if (!startMessagesList.includes(message) &&
            (message === null || message === void 0 ? void 0 : message.split(" ").length) > 1) {
            const response = await this.findAnswerFromQuestionBank(message, language);
            if (response) {
                return await this.sendBotMessage(userId, [
                    {
                        type: "text",
                        value: response,
                    },
                ]);
            }
        }
        return this.handleNode(otherNode, message, userId);
    }
    async handleBotResponse(message, node, userId) {
        var _a;
        if (node.next.length === 1) {
            await this.sendBotMessage(userId, node.responses);
            const nextNode = await this.botsService.getBotNode(node.next[0]);
            this.socketStateService.updateUserData(userId, {
                currentNode: nextNode,
            });
            if (nextNode.nodeType === node_type_enum_1.NodeTypeEnum.USER_INPUT ||
                nextNode.nodeType === node_type_enum_1.NodeTypeEnum.FILE_ATTACHMENT) {
                return;
            }
            return this.handleNode(nextNode, message, userId);
        }
        if (node.next.length > 1) {
            const nodeState = this.socketStateService.getNodeState(userId, node.id);
            if (nodeState === bot_node_state_enum_1.BotNodeStateEnum.NEW) {
                this.socketStateService.setNodeState(userId, node.id, bot_node_state_enum_1.BotNodeStateEnum.AWAITING_USER_INPUT);
                return await this.sendBotMessage(userId, node.responses);
            }
            if (nodeState === bot_node_state_enum_1.BotNodeStateEnum.AWAITING_USER_INPUT) {
                const nextNodes = await Promise.all(node.next.map(async (nodeId) => {
                    return await this.botsService.getBotNode(nodeId);
                }));
                this.socketStateService.setNodeState(userId, node.id, bot_node_state_enum_1.BotNodeStateEnum.NEW);
                const matchedNode = nextNodes
                    .map((ele) => {
                    if (ele.nodeType === node_type_enum_1.NodeTypeEnum.USER_INPUT) {
                        return this.checkIfUserInputMatching(message, ele, userId)
                            ? ele
                            : null;
                    }
                    return null;
                })
                    .find((ele) => ele);
                if (matchedNode) {
                    this.socketStateService.setNodeState(userId, matchedNode.id, bot_node_state_enum_1.BotNodeStateEnum.VISITED);
                    return this.handleNode(matchedNode, message, userId);
                }
                this.socketStateService.setNodeState(userId, node.id, bot_node_state_enum_1.BotNodeStateEnum.AWAITING_USER_INPUT);
                const response = await this.findAnswerFromQuestionBank(message);
                if (response) {
                    return await this.sendBotMessage(userId, [
                        {
                            type: "text",
                            value: response,
                        },
                    ]);
                }
                const { fallbackMessage } = (_a = this.socketStateService.getUserData(userId)) === null || _a === void 0 ? void 0 : _a.botSettings;
                return await this.sendBotMessage(userId, [
                    {
                        type: "text",
                        value: fallbackMessage || "I am sorry, I am not able to understand you",
                    },
                ]);
            }
        }
        await this.sendBotMessage(userId, node.responses);
        return this.socketStateService.updateUserData(userId, {
            currentNode: null,
        });
    }
    async handleUserInput(message, node, userId) {
        const nextNodes = await this.botsService.getBotNode(node.next[0]);
        const nodeState = this.socketStateService.getNodeState(userId, node.id);
        if (nodeState === bot_node_state_enum_1.BotNodeStateEnum.VISITED) {
            return this.handleNode(nextNodes, message, userId);
        }
        else if (this.checkIfUserInputMatching(message, node, userId)) {
            return this.handleNode(nextNodes, message, userId);
        }
        else {
            return this.handleNode(this.socketStateService.getUserData(userId).defaultFallback, message, userId);
        }
    }
    checkIfUserInputMatching(message, node, userId) {
        const { alias, entity, secure } = node.payload;
        if (secure) {
            this.eventEmitter.emit("mask.chat", this.chatId);
        }
        if (entity && entity !== user_input_validation_enums_1.UserInputValidationEnum.ANY) {
            if (!this.validationCheck(entity, message)) {
                return false;
            }
            if (alias) {
                this.socketStateService.updateUserData(userId, {
                    attributes: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).attributes), { [alias]: message }),
                });
            }
            return true;
        }
        if (node.keywords.length > 0) {
            const keywordMatched = node.keywords.some((keyword) => {
                return message.includes(keyword.toLowerCase());
            });
            if (keywordMatched) {
                if (alias) {
                    this.socketStateService.updateUserData(userId, {
                        attributes: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).attributes), { [alias]: message }),
                    });
                }
                return true;
            }
        }
        if (node.utterance.length > 0) {
            const utteranceMatched = node.utterance.some((utterance) => {
                return utterance.toLowerCase().includes(message.toLowerCase());
            });
            if (utteranceMatched) {
                if (alias) {
                    this.socketStateService.updateUserData(userId, {
                        attributes: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).attributes), { [alias]: message }),
                    });
                }
                return true;
            }
        }
        if (alias) {
            this.socketStateService.updateUserData(userId, {
                attributes: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).attributes), { [alias]: message }),
            });
            return true;
        }
        return false;
    }
    async defaultFallback(message, node, userId) {
        var _a;
        const response = await this.findAnswerFromQuestionBank(message);
        if (response) {
            return await this.sendBotMessage(userId, [
                {
                    type: "text",
                    value: response,
                },
            ]);
        }
        this.saveUnansweredMessage(message, userId);
        if ((node === null || node === void 0 ? void 0 : node.next.length) > 0) {
            const nextNode = await this.botsService.getBotNode(node.next[0]);
            this.socketStateService.updateUserData(userId, {
                currentNode: nextNode,
            });
            return this.handleNode(nextNode, message, userId);
        }
        return await this.sendBotMessage(userId, [
            {
                type: "text",
                value: ((_a = this.socketStateService.getUserData(userId).botSettings) === null || _a === void 0 ? void 0 : _a.fallbackMessage) || "I am sorry, I am not able to understand you",
            },
        ]);
    }
    async handleAddToSegment(message, node, userId) {
        const segmentId = node.payload.segmentId;
        await this.segmentsService.addVisitor(segmentId, userId);
        const nextNode = await this.botsService.getBotNode(node.next[0]);
        return this.handleNode(nextNode, message, userId);
    }
    async handleRemoveFromSegment(message, node, userId) {
        const segmentId = node.payload.segmentId;
        await this.segmentsService.removeVisitor(segmentId, userId);
        const nextNode = await this.botsService.getBotNode(node.next[0]);
        return this.handleNode(nextNode, message, userId);
    }
    async handleWebHookCall(message, node, userId) {
        const nextNodes = await Promise.all(node.next.map(async (nodeId) => {
            return await this.botsService.getBotNode(nodeId);
        }));
        const successNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.SUCCESS;
        });
        const failureNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.FAILURE;
        });
        const webhookId = node.payload.webhookId;
        if (!webhookId) {
            return this.handleNode(failureNode, message, userId);
        }
        const { attributes, metadata } = this.socketStateService.getUserData(userId);
        const data = {
            attributes: attributes,
            event: node.payload.eventField,
            metadata: metadata,
            visitor: this.user,
        };
        const response = await this.webhookService.callWebhook(webhookId, data, this.socketStateService.getUserData(userId).botId);
        if (response.status === webhook_status_enum_1.WebhookStatusEnum.SUCCESS) {
            if (Array.isArray(response.data)) {
                await this.sendBotMessage(userId, response.data);
            }
            if (response.metadata) {
                this.socketStateService.updateUserData(userId, {
                    metadata: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).metadata), response.metadata),
                });
            }
            return this.handleNode(successNode, message, userId);
        }
        else
            return this.handleNode(failureNode, message, userId);
    }
    async handleGoToStep(message, node, userId) {
        const stepId = node.payload.blockId;
        const step = await this.botsService.getBotNode(stepId);
        this.socketStateService.updateUserData(userId, {
            BotNodeState: {},
            questionNodeState: {},
        });
        return this.handleNode(step, message, userId);
    }
    async handleCreateTicket(message, node, userId) {
        try {
            const subject = node.payload.ticketSubject;
            const userData = this.socketStateService.getUserData(userId);
            const ticket = await this.ticketsService.create({
                subject,
                visitor: userId,
                bot: userData.botId,
                conversationId: userData.conversationId,
            });
            const nextNode = await this.botsService.getBotNode(node.next[0]);
            await this.sendBotMessage(userId, [
                {
                    type: "text",
                    value: `Service Request Raised Successfully. Please note down the ticket  : #${ticket.id} for future reference.`,
                },
            ]);
            return this.handleNode(nextNode, message, userId);
        }
        catch (e) {
            this.logger.error(e);
        }
    }
    validationCheck(validation, message) {
        switch (validation) {
            case user_input_validation_enums_1.UserInputValidationEnum.EMAIL:
                return (0, class_validator_1.isEmail)(message);
            case user_input_validation_enums_1.UserInputValidationEnum.NUMBER:
                return !isNaN(message);
            case user_input_validation_enums_1.UserInputValidationEnum.TEXT:
                return (0, class_validator_1.isString)(message);
            case user_input_validation_enums_1.UserInputValidationEnum.ANY:
                return true;
            case user_input_validation_enums_1.UserInputValidationEnum.DATE:
                return !isNaN(Date.parse(message));
            case user_input_validation_enums_1.UserInputValidationEnum.ALPHANUMERIC:
                return /^[a-zA-Z0-9]*$/.test(message);
            case user_input_validation_enums_1.UserInputValidationEnum.YES_NO:
                return ["yes", "no"].includes(message);
            case user_input_validation_enums_1.UserInputValidationEnum.YES:
                return ["yes"].includes(message);
            case user_input_validation_enums_1.UserInputValidationEnum.NO:
                return ["no"].includes(message);
            case user_input_validation_enums_1.UserInputValidationEnum.PHONE:
                return !isNaN(message);
            default:
                return true;
        }
    }
    async handleFailureNode(message, node, userId) {
        if (node.next.length > 0) {
            const nextNode = await this.botsService.getBotNode(node.next[0]);
            return this.handleNode(nextNode, message, userId);
        }
    }
    async handleSuccessNode(message, node, userId) {
        const nextNode = await this.botsService.getBotNode(node.next[0]);
        return this.handleNode(nextNode, message, userId);
    }
    async TransferToAgent(message, node, userId) {
        const { botId, mode, conversationId, botName } = this.socketStateService.getUserData(userId);
        if (!node.next.length) {
            return;
        }
        const nextNodes = await Promise.all(node.next.map(async (nodeId) => {
            return await this.botsService.getBotNode(nodeId);
        }));
        const successNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.SUCCESS;
        });
        const failureNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.FAILURE;
        });
        const agent = await this.agentService.assignAgent(botId);
        if (!agent) {
            await this.sendBotMessage(userId, [
                {
                    value: 'No agent is available at the moment. Please try again later. Enter "Start" to restart the conversation.',
                    type: "text",
                    info: "error",
                },
            ]);
            return this.handleNode(failureNode, message, userId);
        }
        this.logger.debug("Chat transfered is being forwarded to agent" + agent.name);
        this.eventEmitter.emit("conversation.created.agent", {
            agentId: agent.id,
            conversationId: conversationId,
        });
        this.eventEmitter.emit("agent.added.visitor", {
            agentId: agent.id,
            visitorId: userId,
        });
        const assignedAgentId = agent.id;
        if (mode !== mode_enum_1.ModeEnum.preview) {
            await this.conversationService.transferConversationToAgent(conversationId, assignedAgentId);
        }
        const conversation = {
            _id: conversationId,
            visitor: {
                _id: userId,
                name: this.user.auth.name,
            },
            bot: {
                _id: botId,
                name: botName,
            },
            chats: [],
        };
        await this.sendBotMessage(userId, [
            {
                type: "text",
                value: `Welcome to ${botName}. I am ${agent.name}, How may I assist you?`,
                switchToAgent: true,
                agentName: agent.name,
                info: "success",
            },
        ]);
        this.socketStateService.updateUserData(userId, {
            handledByAgent: true,
            assignedAgentId,
        });
        this.emitEventToUser(assignedAgentId, "new-visitor", conversation);
        this.socketStateService.updateUserData(userId, {
            currentNode: successNode,
        });
    }
    async handleAttachmentInput(message, node, userId) {
        const nextNode = await this.botsService.getBotNode(node.next[0]);
        if (node.payload.alias) {
            this.socketStateService.updateUserData(userId, {
                attributes: Object.assign(Object.assign({}, this.socketStateService.getUserData(userId).attributes), { [node.payload.alias]: message }),
            });
        }
        return this.handleNode(nextNode, message, userId);
    }
    async handleQuestion(message, node, userId) {
        const questionNodeState = this.socketStateService.getQuestionNodeState(userId, node.id);
        if (!questionNodeState) {
            this.socketStateService.setQuestionNodeState(userId, node.id, {
                currentQuestion: -1,
                lifespan: 0,
            });
        }
        const { currentQuestion, lifespan } = this.socketStateService.getQuestionNodeState(userId, node.id);
        const nextNodes = await Promise.all(node.next.map(async (nodeId) => {
            return await this.botsService.getBotNode(nodeId);
        }));
        const successNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.SUCCESS;
        });
        const failureNode = nextNodes.find((ele) => {
            return ele.nodeType === node_type_enum_1.NodeTypeEnum.FAILURE;
        });
        const elements = node.payload.elements;
        if (!elements) {
            return this.handleNode(failureNode, message, userId);
        }
        if (currentQuestion === -1) {
            const element = elements[0];
            const { prompt } = element;
            await this.sendBotMessage(userId, [
                {
                    type: "text",
                    value: prompt,
                },
            ]);
            this.socketStateService.setQuestionNodeState(userId, node.id, {
                currentQuestion: 0,
            });
        }
        if (currentQuestion !== -1) {
            const element = elements[currentQuestion];
            const { entity, alias, lifespan: attempt, actionOnFailure, secure, } = element;
            if (this.validationCheck(entity, message)) {
                this.socketStateService.setQuestionNodeState(userId, node.id, {
                    currentQuestion: currentQuestion + 1,
                    lifespan: 0,
                });
                if (alias) {
                    this.socketStateService.updateUserData(userId, {
                        attributes: {
                            [alias]: message,
                        },
                    });
                }
                if (secure) {
                    this.eventEmitter.emit("mask.chat", this.chatId);
                }
                if (currentQuestion + 1 >= elements.length) {
                    return this.handleNode(successNode, message, userId);
                }
                const nextElement = elements[currentQuestion + 1];
                await this.sendBotMessage(userId, [
                    {
                        type: "text",
                        value: nextElement.prompt,
                    },
                ]);
            }
            else {
                if (!attempt || attempt === -1) {
                    await this.sendBotMessage(userId, [
                        {
                            type: "text",
                            value: element.prompt,
                        },
                    ]);
                }
                const haveLifespan = lifespan + 1 < attempt;
                if (haveLifespan && attempt && attempt > 0) {
                    this.socketStateService.setQuestionNodeState(userId, node.id, {
                        lifespan: lifespan + 1,
                        currentQuestion: currentQuestion,
                    });
                    return await this.sendBotMessage(userId, [
                        {
                            type: "text",
                            value: element.prompt,
                        },
                    ]);
                }
                else {
                    if (actionOnFailure === "continue") {
                        this.socketStateService.setQuestionNodeState(userId, node.id, {
                            lifespan: 0,
                            currentQuestion: currentQuestion + 1,
                        });
                        if (currentQuestion + 1 >= elements.length) {
                            this.socketStateService.setQuestionNodeState(userId, node.id, {});
                            return this.handleNode(successNode, message, userId);
                        }
                        const nextElement = elements[currentQuestion + 1];
                        await this.sendBotMessage(userId, [
                            {
                                type: "text",
                                value: nextElement.prompt,
                            },
                        ]);
                    }
                    if (actionOnFailure === "fallback") {
                        this.socketStateService.setQuestionNodeState(userId, node.id, {});
                        return this.handleNode(failureNode, message, userId);
                    }
                }
            }
        }
    }
    async handleSetAttributes(message, node, userId) {
        const nextNode = await this.botsService.getBotNode(node.next[0]);
        const attributes = node.payload.attributes;
        if (attributes.length > 0) {
            const existedAttributes = this.socketStateService.getUserData(userId).attributes;
            if (existedAttributes) {
                const mewAttributes = attributes.reduce((acc, ele) => {
                    return Object.assign(Object.assign({}, acc), { [ele.to]: existedAttributes[ele.set] || "" });
                }, {});
                this.socketStateService.updateUserData(userId, {
                    attributes: Object.assign(Object.assign({}, existedAttributes), mewAttributes),
                });
            }
        }
        return this.handleNode(nextNode, message, userId);
    }
    async handleCloseChat(message, node, userId) {
        const { startNode, botSettings, conversationId } = this.socketStateService.getUserData(userId);
        this.socketStateService.updateUserData(userId, {
            attributes: {},
            currentNode: startNode,
            BotNodeState: {},
            questionNodeState: {},
        });
        if (botSettings === null || botSettings === void 0 ? void 0 : botSettings.askForFeedback) {
            this.emitEventToUser(userId, "ask-for-feedback", {});
        }
        await this.sendBotMessage(userId, [
            {
                type: "text",
                value: (botSettings === null || botSettings === void 0 ? void 0 : botSettings.thankyoumsg) || "Thank you for contacting us.",
            },
            {
                type: "text",
                value: 'To start again type "start"',
            },
        ]);
        this.eventEmitter.emit("end.conversation", { conversationId, userId });
    }
    async findAnswerFromQuestionBank(message, language = this.language) {
        const response = await this.questionsService.findAnswer(message, language);
        if (response) {
            return response;
        }
        return null;
    }
    async sendBotMessage(userId, message, event) {
        const data = {
            event: event || "chat-message-bot",
            userId,
        };
        if (typeof message === "string") {
            message = [message];
        }
        const userData = this.socketStateService.getUserData(userId);
        if (!userData)
            return;
        const { botId, conversationId, mode, platform, handledByAgent } = userData;
        const messageDelay = this.delay[conversationId] || 0;
        const nodeDelay = parseInt(this.configService.get("delay.node")) || 1000;
        const message_delay = parseInt(this.configService.get("delay.message")) || 750;
        message.map((ele, index) => {
            if (ele.type === chat_type_enum_1.ChatTypeEnum.RANDOM_TEXT) {
                ele.value =
                    ele.values.length > 0
                        ? ele.values[Math.floor(Math.random() * ele.values.length)]
                        : "";
                ele.type = chat_type_enum_1.ChatTypeEnum.TEXT;
            }
            const messageResponse = {
                id: (0, util_1.generateId)("message", 10),
                senderId: botId,
                type: ele.type,
                value: ele.value,
                buttons: ele.buttons,
                time: new Date(),
                delay: 2000,
                switchToAgent: ele.switchToAgent || false,
                agentId: ele.agentId || "",
                location: ele.location,
                info: ele.info,
                handledByAgent: handledByAgent || false,
            };
            if (mode !== mode_enum_1.ModeEnum.preview) {
                this.eventEmitter.emit("create.new.chat", {
                    message: ele.value,
                    type: ele.type,
                    sender: botId,
                    conversationId: conversationId,
                });
            }
            setTimeout(() => {
                this.redisPropagatorService.propagateEvent(Object.assign(Object.assign({}, data), { data: {
                        message: messageResponse,
                    }, platform }));
            }, messageDelay + index * message_delay);
        });
        this.delay[conversationId] =
            messageDelay + (message.length - 1) * message_delay + nodeDelay;
    }
    async sendMessageToAgent(userId, message, visitor) {
        const data = {
            event: "message",
            userId,
        };
        const { mode, conversationId } = visitor;
        if (mode !== mode_enum_1.ModeEnum.preview && conversationId && message.value) {
            this.eventEmitter.emit("create.new.chat", {
                sender: message.from,
                message: message.value,
                type: message.type,
                conversationId,
            });
        }
        const messageResponse = {
            id: (0, util_1.generateId)("message", 10),
            sender: message.from,
            type: message.type,
            value: message.value,
            time: new Date(),
            delay: 2000,
        };
        return this.redisPropagatorService.propagateEvent(Object.assign(Object.assign({}, data), { data: {
                message: messageResponse,
                conversationId,
            } }));
    }
    async onSendTelegramMessage(data) {
        await this.sendMessageToTelegram(data.message, data.ctx);
    }
    async onSendFacebookMessage(data) {
        await this.sendFacebookMessage(data.message, data.ctx);
    }
    async onSendWhatsappMessage(data) {
        await this.sendWhatsappMessage(data.message, data.ctx);
    }
    async sendMessageToTelegram(messageResponse, ctx = this.ctx) {
        if (!ctx || !messageResponse)
            return;
        try {
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.TEXT) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.reply(messageResponse.value));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.IMAGE) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.replyWithPhoto(messageResponse.value));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.MAPS) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.replyWithLocation(messageResponse.location.latitude, messageResponse.location.longitude));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.AUDIO) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.replyWithAudio(messageResponse.value));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.VIDEO) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.replyWithVideo(messageResponse.value));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.FILE) {
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.replyWithDocument(messageResponse.value));
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.BUTTONS) {
                let buttons = messageResponse.buttons.map((ele) => {
                    return telegraf_1.Markup.button.callback(ele.title, ele.value);
                });
                buttons = telegraf_1.Markup.inlineKeyboard(buttons);
                return await (ctx === null || ctx === void 0 ? void 0 : ctx.reply(messageResponse.value, Object.assign({}, buttons)));
            }
        }
        catch (error) {
            this.logger.error(`Error sending message to telegram: ${error}`);
        }
    }
    emitEventToUser(userId, event, data, platform) {
        var _a;
        const eventData = {
            event,
            userId,
        };
        const userData = this.socketStateService.getUserData(userId);
        if (!userData)
            return;
        const { mode, conversationId, ctx } = userData;
        platform = platform || userData.platform;
        if (mode !== mode_enum_1.ModeEnum.preview && conversationId && ((_a = data.message) === null || _a === void 0 ? void 0 : _a.value)) {
            this.eventEmitter.emit("create.new.chat", {
                sender: data.message.senderId || data.message.sender,
                message: data.message.value,
                type: data.message.type,
                conversationId,
            });
        }
        return this.redisPropagatorService.propagateEvent(Object.assign(Object.assign({}, eventData), { data,
            platform }));
    }
    async saveUnansweredMessage(message, userId) {
        const { botId } = this.socketStateService.getUserData(userId);
        if (this.checkIfQuestionIsProper(message)) {
            this.logger.debug(`Adding question to Unanswered Questions: ${message}`);
            await this.unansweredService.create({
                botId,
                questions: {
                    question: message,
                    askedBy: userId,
                    time: new Date(),
                },
            });
        }
    }
    checkIfQuestionIsProper(message) {
        this.logger.debug(`Checking if question is proper: ${message}`);
        if (!message) {
            this.logger.debug(`Question is empty`);
            return false;
        }
        message = message.toLowerCase();
        if (typeof message === "string")
            message = message.trim();
        if ((0, class_validator_1.isCreditCard)(message)) {
            this.logger.debug(`Question is a credit card`);
            return false;
        }
        if ((0, class_validator_1.isDate)(message)) {
            this.logger.debug(`Question is a date`);
            return false;
        }
        if ((0, class_validator_1.isCurrency)(message)) {
            this.logger.debug(`Question is a currency`);
            return false;
        }
        if ((0, class_validator_1.IsUrl)(message)) {
            this.logger.debug(`Question is a url`);
            return false;
        }
        if ((0, class_validator_1.isMACAddress)(message)) {
            this.logger.debug(`Question is a MAC Address`);
            return false;
        }
        if ((0, class_validator_1.isMobilePhone)(message)) {
            this.logger.debug(`Question is a mobile phone`);
            return false;
        }
        if ((0, class_validator_1.isIP)(message)) {
            this.logger.debug(`Question is an IP`);
            return false;
        }
        if (!isNaN(message)) {
            this.logger.debug(`Question is a number`);
            return false;
        }
        if ((0, class_validator_1.isEmail)(message)) {
            this.logger.debug(`Question is an email`);
            return false;
        }
        let words = message.split(" ");
        words = [...new Set(words)];
        const filteredWords = words.filter((ele) => {
            return ele.length > 2;
        });
        if (filteredWords.length > 2) {
            return true;
        }
        this.logger.debug(`Question is not proper ${message}.Not adding to DB`);
        return false;
    }
    async sendFacebookMessage(messageResponse, ctx = this.ctx) {
        var _a, _b, _c;
        if (!ctx || !ctx.sender_psid)
            return;
        if (!messageResponse)
            return;
        const request_body = {
            recipient: {
                id: this.ctx.sender_psid,
            },
            message: {},
        };
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.TEXT) {
            request_body.message = {
                text: messageResponse.value,
            };
        }
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.IMAGE) {
            request_body.message = {
                attachment: {
                    type: "image",
                    payload: {
                        url: messageResponse.value,
                    },
                },
            };
        }
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.BUTTONS) {
            request_body.message = {
                attachment: {
                    type: "template",
                    payload: {
                        template_type: "generic",
                        elements: [
                            {
                                title: messageResponse.value,
                                buttons: messageResponse.buttons.map((ele) => {
                                    return {
                                        type: "postback",
                                        title: ele.title,
                                        payload: ele.value,
                                    };
                                }),
                            },
                        ],
                    },
                },
            };
        }
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.QUICK_REPLY) {
            request_body.message = {
                text: messageResponse.value,
                quick_replies: messageResponse.buttons.map((ele) => {
                    return {
                        content_type: "text",
                        title: ele.title,
                        payload: ele.value,
                    };
                }),
            };
        }
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.AUDIO) {
            request_body.message = {
                attachment: {
                    type: "audio",
                    payload: {
                        url: messageResponse.value,
                    },
                },
            };
        }
        if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.VIDEO) {
            request_body.message = {
                attachment: {
                    type: "video",
                    payload: {
                        url: messageResponse.value,
                    },
                },
            };
        }
        try {
            await (0, rxjs_1.firstValueFrom)(this.httpService.post("https://graph.facebook.com/v15.0/me/messages", request_body, {
                params: {
                    access_token: ctx.accessToken,
                },
            }));
        }
        catch (error) {
            const errorMessages = (_c = (_b = (_a = error.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error) === null || _c === void 0 ? void 0 : _c.message;
            this.logger.error(`Unable to send message. ${errorMessages}`);
        }
    }
    async sendWhatsappMessage(messageResponse, ctx = this.ctx) {
        try {
            if (!ctx || !ctx.recipient)
                return;
            if (!messageResponse)
                return;
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.TEXT) {
                await ctx.Whatsapp.sendText({
                    recipientPhone: this.ctx.recipient,
                    message: messageResponse.value,
                });
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.IMAGE) {
                await ctx.Whatsapp.sendImage({
                    recipientPhone: this.ctx.recipient,
                    url: messageResponse.value,
                });
            }
            if (messageResponse.type === chat_type_enum_1.ChatTypeEnum.BUTTONS) {
                await ctx.Whatsapp.sendSimpleButtons({
                    recipientPhone: this.ctx.recipient,
                    text: messageResponse.value,
                    buttons: messageResponse.buttons.map((ele) => {
                        return {
                            type: "postback",
                            title: ele.title,
                            payload: ele.value,
                        };
                    }),
                });
            }
        }
        catch (error) {
            this.logger.error(`Unable to send message. ${error.message}`);
        }
    }
    async endConversationByAgent(data) {
        this.logger.debug(`End conversation by agent: ${data.userId}`);
        const userData = this.socketStateService.getUserData(data.userId);
        if (userData) {
            const { currentNode } = userData;
            if (currentNode && currentNode.next.length > 0) {
                const nextNodes = await Promise.all(currentNode.next.map(async (nodeId) => {
                    return await this.botsService.getBotNode(nodeId);
                }));
                this.socketStateService.updateUserData(data.userId, {
                    currentNode: nextNodes[0],
                    handledByAgent: false,
                    assignedAgentId: null,
                });
                this.sendBotMessage(data.userId, [
                    {
                        type: "text",
                        value: "Your conversation has been ended by the agent. Bot will take over now.",
                        info: "warning",
                    },
                ]);
                return this.handleNode(nextNodes[0], "", data.userId);
            }
        }
    }
    async reportConversation(data) {
        this.logger.debug(`Report conversation: ${data.userId}`);
        await this.sendBotMessage(data.userId, [
            {
                type: "text",
                value: "Agent marked this conversation as inappropriate. You will not be able to chat with this agent again.",
                info: "error",
            },
        ]);
        return this.emitEventToUser(data.userId, "conversation-reported", {});
    }
    async publishEvent(data) {
        this.logger.debug(`Publish event: ${data.userId}`);
        return this.emitEventToUser(data.userId, data.event, data.data);
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)("send-telegram-message", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "onSendTelegramMessage", null);
__decorate([
    (0, event_emitter_1.OnEvent)("send-facebook-message", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "onSendFacebookMessage", null);
__decorate([
    (0, event_emitter_1.OnEvent)("send-whatsapp-message", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "onSendWhatsappMessage", null);
__decorate([
    (0, event_emitter_1.OnEvent)("end-conversation-by-agent", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "endConversationByAgent", null);
__decorate([
    (0, event_emitter_1.OnEvent)("report-conversation", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "reportConversation", null);
__decorate([
    (0, event_emitter_1.OnEvent)("publish-events", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MessageHandlerService.prototype, "publishEvent", null);
MessageHandlerService = MessageHandlerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(13, (0, bull_1.InjectQueue)(constants_1.MESSAGE_HANDLER_QUEUE)),
    __metadata("design:paramtypes", [bots_service_1.BotsService,
        socket_state_service_1.SocketStateService,
        segments_service_1.SegmentsService,
        webhook_service_1.WebhookService,
        tickets_service_1.TicketsService,
        conversation_service_1.ConversationService,
        redis_propagate_service_1.RedisPropagatorService,
        agent_service_1.AgentService,
        unanswered_service_1.UnansweredService,
        questions_service_1.QuestionsService,
        event_emitter_1.EventEmitter2,
        axios_1.HttpService,
        config_1.ConfigService, Object])
], MessageHandlerService);
exports.MessageHandlerService = MessageHandlerService;
//# sourceMappingURL=message-handler.service.js.map