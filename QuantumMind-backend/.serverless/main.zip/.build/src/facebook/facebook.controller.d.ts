import { FacebookService } from './facebook.service';
export declare class FacebookController {
    private readonly facebookService;
    constructor(facebookService: FacebookService);
    getWebhook(query: any): Promise<any>;
    postWebhook(body: any): Promise<string>;
}
