"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FacebookService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const config_1 = require("@nestjs/config");
const social_service_1 = require("src/social/social.service");
const chat_initializer_service_1 = require("src/chat-initializer/chat-initializer.service");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
const message_handler_service_1 = require("src/message-handler/message-handler.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const chat_type_enum_1 = require("src/conversation/enums/chat-type.enum");
let FacebookService = FacebookService_1 = class FacebookService {
    constructor(httpService, configService, socialService, chatInitializerService, messageHandlerService, socketStateService) {
        this.httpService = httpService;
        this.configService = configService;
        this.socialService = socialService;
        this.chatInitializerService = chatInitializerService;
        this.messageHandlerService = messageHandlerService;
        this.socketStateService = socketStateService;
        this.logger = new common_1.Logger(FacebookService_1.name);
        this.botList = {};
    }
    async getWebhook(query) {
        const mode = query["hub.mode"];
        const token = query["hub.verify_token"];
        const challenge = query["hub.challenge"];
        if (mode && token) {
            if (mode === "subscribe" &&
                token === this.configService.get("social.verifyToken")) {
                this.logger.debug(`Facebook Webhook verified!`);
                return challenge;
            }
        }
        this.logger.debug(`Facebook Webhook verification failed.`);
        throw new common_1.HttpException("Webhook verification failed.", 403);
    }
    async postWebhook(body) {
        try {
            if (body.object !== "page")
                throw new common_1.BadRequestException();
            body.entry.forEach(async (entry) => {
                const pageId = entry.id;
                const { accessToken, engageBotId } = this.botList[pageId] || {};
                if (!accessToken || !engageBotId) {
                    const { accessToken, engageBotId } = await this.socialService.getBotToken(pageId);
                    this.botList[pageId] = { accessToken, engageBotId };
                }
                if (entry.changes) {
                    const webhook_event = entry.changes[0];
                    const sender_psid = webhook_event.value.from.id;
                    if (sender_psid === pageId)
                        return;
                    if (webhook_event.value.message) {
                        const commentId = webhook_event.value.comment_id;
                        if (webhook_event.value.type === "comment") {
                            await this.replyToFbComment(pageId, commentId, webhook_event.value.message);
                        }
                    }
                    else if (webhook_event.value.postback) {
                        this.handlePostback(sender_psid, webhook_event.value.postback, pageId);
                    }
                }
                if (entry.messaging) {
                    const webhook_event = entry.messaging[0];
                    const sender_psid = webhook_event.sender.id;
                    if (sender_psid === pageId)
                        return;
                    if (webhook_event.message) {
                        await this.handleMessage(sender_psid, webhook_event.message, pageId);
                    }
                    else if (webhook_event.postback) {
                        this.handlePostback(sender_psid, webhook_event.postback, pageId);
                    }
                }
            });
            return "EVENT_RECEIVED";
        }
        catch (error) {
            this.logger.error(error.message);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async handleMessage(sender_psid, received_message, pageId) {
        this.logger.log(`Received message from ${sender_psid}`);
        const { accessToken, engageBotId } = this.botList[pageId] || {};
        const userData = await this.getUserDetails(sender_psid, accessToken);
        const { first_name, last_name, id } = userData;
        const visitor = await this.chatInitializerService.initializeChat({
            name: `${first_name} ${last_name}`,
            username: id,
            bot: engageBotId,
            platform: platform_enum_1.PlatformEnum.FACEBOOK,
        }, engageBotId);
        const user = {
            auth: {
                userId: visitor.visitorId,
                email: "",
                name: `${first_name} ${last_name}`,
                role: "visitor",
            },
        };
        const socketData = this.socketStateService.getUserData(visitor.visitorId);
        if (!socketData)
            return;
        const { mode, handledByAgent, assignedAgentId, conversationId } = socketData;
        this.socketStateService.updateUserData(visitor.visitorId, {
            ctx: { pageId, sender_psid, accessToken },
        });
        const messageData = {
            message: "",
            user,
            type: "text",
            language: "en",
            ctx: { pageId, sender_psid, accessToken },
        };
        if (received_message.text) {
            messageData.message = received_message.text;
            messageData.type = "text";
        }
        else if (received_message.attachments) {
            const attachment_url = received_message.attachments[0].payload.url;
            const type = received_message.attachments[0].type;
            messageData.message = attachment_url;
            if (type === chat_type_enum_1.ChatTypeEnum.IMAGE)
                messageData.type = chat_type_enum_1.ChatTypeEnum.IMAGE;
            else if (type === chat_type_enum_1.ChatTypeEnum.VIDEO)
                messageData.type = chat_type_enum_1.ChatTypeEnum.VIDEO;
            else if (type === chat_type_enum_1.ChatTypeEnum.FILE)
                messageData.type = chat_type_enum_1.ChatTypeEnum.FILE;
            else if (type === chat_type_enum_1.ChatTypeEnum.AUDIO)
                messageData.type = chat_type_enum_1.ChatTypeEnum.AUDIO;
            else
                return;
        }
        if (handledByAgent && assignedAgentId) {
            return this.messageHandlerService.sendMessageToAgent(assignedAgentId, {
                type: messageData.type,
                value: messageData.message,
                from: visitor.visitorId,
            }, socketData);
        }
        return this.messageHandlerService.handleMessage(messageData.message, user, messageData.type, "en", messageData.ctx);
    }
    async handlePostback(sender_psid, received_postback, pageId) {
        const { accessToken, engageBotId } = this.botList[pageId] || {};
        const userData = await this.getUserDetails(sender_psid, accessToken);
        const { first_name, last_name, id } = userData;
        const visitor = await this.chatInitializerService.initializeChat({
            name: `${first_name} ${last_name}`,
            username: id,
            bot: engageBotId,
            platform: platform_enum_1.PlatformEnum.FACEBOOK,
        }, engageBotId);
        const user = {
            auth: {
                userId: visitor.visitorId,
                email: "",
                name: `${first_name} ${last_name}`,
                role: "visitor",
            },
        };
        const payload = received_postback.payload;
        if (typeof payload === "string") {
            return this.messageHandlerService.handleMessage(payload, user, "text", "en", { pageId, sender_psid, accessToken });
        }
    }
    async callSendAPI(sender_psid, response, access_token) {
        var _a, _b, _c;
        this.logger.log(`Sending message to ${sender_psid}`);
        const request_body = {
            recipient: {
                id: sender_psid,
            },
            message: response,
        };
        try {
            const response = await (0, rxjs_1.firstValueFrom)(this.httpService.post("https://graph.facebook.com/v15.0/me/messages", request_body, {
                params: {
                    access_token: access_token,
                },
            }));
            this.logger.log(`Message sent! ${JSON.stringify(response.data)}`);
        }
        catch (error) {
            const errorMessages = (_c = (_b = (_a = error.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error) === null || _c === void 0 ? void 0 : _c.message;
            this.logger.error(`Unable to send message. ${errorMessages}`);
        }
    }
    async getUserDetails(userId, access_token) {
        var _a, _b, _c;
        try {
            if (!userId)
                throw new common_1.BadRequestException("User Id is required");
            const response = await (0, rxjs_1.firstValueFrom)(this.httpService.get(`https://graph.facebook.com/${userId}`, {
                params: {
                    access_token: access_token,
                    fields: "first_name,last_name",
                },
            }));
            return response.data;
        }
        catch (error) {
            console.log((_a = error.response) === null || _a === void 0 ? void 0 : _a.data);
            const errorMessages = ((_c = (_b = error.response.data) === null || _b === void 0 ? void 0 : _b.error) === null || _c === void 0 ? void 0 : _c.message) || error.message;
            this.logger.error(errorMessages);
        }
    }
    async replyToFbComment(pageId, commentId, message) {
        var _a, _b, _c;
        console.log("replyToFbComment", pageId, commentId, message);
        const { accessToken } = this.botList[pageId] || {};
        const request_body = {
            message: `We have received your comment. Our team will get back to you shortly. \n\n${message}`,
        };
        try {
            const response = await (0, rxjs_1.firstValueFrom)(this.httpService.post(`https://graph.facebook.com/v15.0/${commentId}/comments`, request_body, {
                params: {
                    access_token: "EAAOch7o5ZBU4BAM0jiK0ln5DM1fw82Dwsma5genR6kNM7VGBK37do6FxjxLr9Cruy2ww5w0Pp7RburO1hCFcjzcMT7o5EwZCsTOZCKAWE5dKP3ZBJEZAW1BtwwkKHQmVZCV4rXUnwZBQF8ZC6lu39mdGHAnwTBY2NBmtOPSgQnL29bPebZC8Fq879RutgrSyU10H4EIhPOuba1pzpcKZBKL5m62I6eYpKO79IZD",
                },
            }));
            this.logger.log(`Message sent! ${JSON.stringify(response.data)}`);
        }
        catch (error) {
            const errorMessages = (_c = (_b = (_a = error.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error) === null || _c === void 0 ? void 0 : _c.message;
            this.logger.error(`Unable to send message. ${errorMessages}`);
        }
    }
};
FacebookService = FacebookService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [axios_1.HttpService,
        config_1.ConfigService,
        social_service_1.SocialService,
        chat_initializer_service_1.ChatInitializerService,
        message_handler_service_1.MessageHandlerService,
        socket_state_service_1.SocketStateService])
], FacebookService);
exports.FacebookService = FacebookService;
//# sourceMappingURL=facebook.service.js.map