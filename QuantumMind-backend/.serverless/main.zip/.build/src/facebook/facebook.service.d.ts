import { HttpService } from "@nestjs/axios";
import { ConfigService } from "@nestjs/config";
import { SocialService } from "src/social/social.service";
import { ChatInitializerService } from "src/chat-initializer/chat-initializer.service";
import { MessageHandlerService } from "src/message-handler/message-handler.service";
import { SocketStateService } from "src/socket/socket-state.service";
export declare class FacebookService {
    private readonly httpService;
    private readonly configService;
    private readonly socialService;
    private readonly chatInitializerService;
    private readonly messageHandlerService;
    private readonly socketStateService;
    private readonly logger;
    private botList;
    constructor(httpService: HttpService, configService: ConfigService, socialService: SocialService, chatInitializerService: ChatInitializerService, messageHandlerService: MessageHandlerService, socketStateService: SocketStateService);
    getWebhook(query: any): Promise<any>;
    postWebhook(body: any): Promise<string>;
    handleMessage(sender_psid: any, received_message: any, pageId: string): Promise<any>;
    handlePostback(sender_psid: string, received_postback: any, pageId: string): Promise<any>;
    callSendAPI(sender_psid: any, response: any, access_token?: string): Promise<void>;
    getUserDetails(userId: string, access_token: any): Promise<any>;
    replyToFbComment(pageId: string, commentId: string, message: string): Promise<void>;
}
