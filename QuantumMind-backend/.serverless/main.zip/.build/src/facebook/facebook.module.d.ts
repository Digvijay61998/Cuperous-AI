export declare class FacebookModule {
}
