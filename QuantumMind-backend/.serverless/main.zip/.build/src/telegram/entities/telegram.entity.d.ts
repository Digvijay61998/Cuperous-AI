import { TelegramStatus } from '../enums/telegram-status.enum';
import mongoose, { Document } from 'mongoose';
export declare class Telegram {
    name: string;
    telegramBotId: string;
    engageBot: string;
    status: TelegramStatus;
    token: string;
}
export type TelegramDocument = Telegram & Document;
export declare const TelegramSchema: mongoose.Schema<Telegram, mongoose.Model<Telegram, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Telegram>;
