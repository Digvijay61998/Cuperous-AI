"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramSchema = exports.Telegram = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const telegram_status_enum_1 = require("../enums/telegram-status.enum");
const mongoose_2 = __importDefault(require("mongoose"));
let Telegram = class Telegram {
};
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Telegram.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true }),
    __metadata("design:type", String)
], Telegram.prototype, "telegramBotId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose_2.default.Schema.Types.ObjectId,
        ref: 'Bot',
        required: true,
    }),
    __metadata("design:type", String)
], Telegram.prototype, "engageBot", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        enum: telegram_status_enum_1.TelegramStatus,
        default: telegram_status_enum_1.TelegramStatus.INACTIVE,
    }),
    __metadata("design:type", String)
], Telegram.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Telegram.prototype, "token", void 0);
Telegram = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret._id;
                delete ret.__v;
                delete ret.token;
            },
        },
    })
], Telegram);
exports.Telegram = Telegram;
exports.TelegramSchema = mongoose_1.SchemaFactory.createForClass(Telegram);
//# sourceMappingURL=telegram.entity.js.map