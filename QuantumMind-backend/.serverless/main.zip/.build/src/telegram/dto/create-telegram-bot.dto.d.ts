export declare class CreateTelegramBotDto {
    name: string;
    telegramBotId: string;
    engageBot: string;
    token: string;
}
