import { Context } from 'telegraf';
import { ChatInitializerService } from 'src/chat-initializer/chat-initializer.service';
export type TelegramContext = Context & {
    visitorId: string;
};
export declare const TelegramUserMiddleware: (chatInitializerService: ChatInitializerService, engageBotId: string) => (ctx: TelegramContext, next: () => Promise<any>) => Promise<void>;
