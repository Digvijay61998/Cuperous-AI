"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramUserMiddleware = void 0;
const telegraf_1 = require("telegraf");
const platform_enum_1 = require("src/conversation/enums/platform.enum");
const TelegramUserMiddleware = (chatInitializerService, engageBotId) => async (ctx, next) => {
    try {
        if (!ctx.from || !ctx.chat)
            new telegraf_1.TelegramError({
                error_code: 400,
                description: 'Bad Request: chat not found',
            });
        const user = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
        const visitor = await chatInitializerService.initializeChat({
            name: `${user.user.first_name} ${user.user.last_name}`,
            username: user.user.username,
            platform: platform_enum_1.PlatformEnum.TELEGRAM,
            bot: engageBotId,
        }, engageBotId);
        ctx.visitorId = visitor.visitorId;
        await next();
    }
    catch (error) {
        throw new telegraf_1.TelegramError({
            error_code: error.error_code || 500,
            description: error.description || 'Internal Server Error',
        });
    }
};
exports.TelegramUserMiddleware = TelegramUserMiddleware;
//# sourceMappingURL=telegram.user.js.map