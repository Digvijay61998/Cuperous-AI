"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.telegramProvider = void 0;
const constants_1 = require("./constants");
const constants_2 = require("src/constants");
const telegram_entity_1 = require("./entities/telegram.entity");
exports.telegramProvider = [
    {
        provide: constants_1.TELEGRAM_PROVIDER,
        inject: [constants_2.DATABASE_PROVIDER],
        useFactory: (connection) => connection.model(telegram_entity_1.Telegram.name, telegram_entity_1.TelegramSchema),
    },
];
//# sourceMappingURL=telegram.provider.js.map