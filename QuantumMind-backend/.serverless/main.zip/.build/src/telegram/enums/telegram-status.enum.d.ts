export declare enum TelegramStatus {
    ACTIVE = "active",
    INACTIVE = "inactive"
}
