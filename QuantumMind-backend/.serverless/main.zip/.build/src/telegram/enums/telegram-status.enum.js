"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramStatus = void 0;
var TelegramStatus;
(function (TelegramStatus) {
    TelegramStatus["ACTIVE"] = "active";
    TelegramStatus["INACTIVE"] = "inactive";
})(TelegramStatus = exports.TelegramStatus || (exports.TelegramStatus = {}));
//# sourceMappingURL=telegram-status.enum.js.map