"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TELEGRAM_PROVIDER = void 0;
exports.TELEGRAM_PROVIDER = 'TELEGRAM_PROVIDER';
//# sourceMappingURL=constants.js.map