"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TelegramService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const constants_1 = require("./constants");
let TelegramService = TelegramService_1 = class TelegramService {
    constructor(telegramModel) {
        this.telegramModel = telegramModel;
        this.logger = new common_1.Logger(TelegramService_1.name);
    }
    async create(createTelegramBotDto) {
        try {
            let bot = await this.telegramModel.findOne({
                telegramBotId: createTelegramBotDto.telegramBotId,
            });
            if (bot) {
                throw new common_1.HttpException('Bot already exists', 400);
            }
            bot = new this.telegramModel(createTelegramBotDto);
            return await bot.save();
        }
        catch (error) {
            this.logger.error(`Error while creating telegram bot: ${error.message}`);
            throw new common_1.HttpException(error.message || 'Some thing went wrong', error.status || 500);
        }
    }
};
TelegramService = TelegramService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.TELEGRAM_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model])
], TelegramService);
exports.TelegramService = TelegramService;
//# sourceMappingURL=telegram.service.js.map