import { MessageHandlerService } from "src/message-handler/message-handler.service";
import { SocketStateService } from "src/socket/socket-state.service";
import { TelegramContext } from "./middlewares/telegram.user";
import { SocialService } from "src/social/social.service";
import { ChatInitializerService } from "src/chat-initializer/chat-initializer.service";
import { ConfigService } from "@nestjs/config";
export declare class TelegramMessageService {
    private messageHandlerService;
    private socketStateService;
    private socialService;
    private configService;
    private chatInitializerService;
    private readonly logger;
    private botList;
    constructor(messageHandlerService: MessageHandlerService, socketStateService: SocketStateService, socialService: SocialService, configService: ConfigService, chatInitializerService: ChatInitializerService);
    handlePostWebhook(body: any, botId: string): Promise<void>;
    handleSendMessage(ctx: TelegramContext, next: () => Promise<any>): Promise<void>;
}
