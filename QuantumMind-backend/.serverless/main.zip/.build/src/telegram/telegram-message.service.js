"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelegramMessageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramMessageService = void 0;
const common_1 = require("@nestjs/common");
const message_handler_service_1 = require("src/message-handler/message-handler.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const social_service_1 = require("src/social/social.service");
const telegraf_1 = require("telegraf");
const telegram_user_1 = require("./middlewares/telegram.user");
const chat_initializer_service_1 = require("src/chat-initializer/chat-initializer.service");
const config_1 = require("@nestjs/config");
let TelegramMessageService = TelegramMessageService_1 = class TelegramMessageService {
    constructor(messageHandlerService, socketStateService, socialService, configService, chatInitializerService) {
        this.messageHandlerService = messageHandlerService;
        this.socketStateService = socketStateService;
        this.socialService = socialService;
        this.configService = configService;
        this.chatInitializerService = chatInitializerService;
        this.logger = new common_1.Logger(TelegramMessageService_1.name);
        this.botList = {};
    }
    async handlePostWebhook(body, botId) {
        try {
            let { accessToken, enageBotId } = this.botList[botId] || {};
            if (!accessToken) {
                const data = await this.socialService.getBotToken(botId);
                accessToken = data === null || data === void 0 ? void 0 : data.accessToken;
                enageBotId = data === null || data === void 0 ? void 0 : data.engageBotId;
                if (!accessToken)
                    return;
                this.botList[botId] = { accessToken, enageBotId };
            }
            const bot = new telegraf_1.Telegraf(accessToken);
            bot.use((0, telegram_user_1.TelegramUserMiddleware)(this.chatInitializerService, enageBotId));
            bot.use(this.handleSendMessage.bind(this));
            await bot.handleUpdate(body);
        }
        catch (error) {
            console.log(error);
        }
    }
    async handleSendMessage(ctx, next) {
        var _a;
        try {
            this.socketStateService.updateUserData(ctx.visitorId, {
                ctx,
            });
            const user = {
                auth: {
                    userId: ctx.visitorId,
                    email: ctx.from.username,
                    name: ctx.from.first_name,
                    role: "visitor",
                },
            };
            if (ctx.message) {
                const data = {
                    message: "",
                    type: "text",
                    language: ((_a = ctx.message.from) === null || _a === void 0 ? void 0 : _a.language_code) || "en",
                };
                if ("text" in ctx.message) {
                    data.message = ctx.message.text;
                }
                if ("photo" in ctx.message) {
                    const fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
                    const file = await ctx.telegram.getFile(fileId);
                }
                const { handledByAgent, assignedAgentId } = this.socketStateService.getUserData(ctx.visitorId);
                if (handledByAgent && assignedAgentId) {
                    this.messageHandlerService.sendMessageToAgent(assignedAgentId, {
                        type: data.type,
                        value: data.message,
                        from: ctx.visitorId,
                    }, this.socketStateService.getUserData(ctx.visitorId));
                }
                else
                    await this.messageHandlerService.handleMessage(data.message, user, data.type, data.language, ctx);
                await next();
            }
            if (ctx.callbackQuery) {
                if ("data" in ctx.callbackQuery) {
                    await this.messageHandlerService.handleMessage(ctx.callbackQuery.data, user, "text", "en", ctx);
                }
            }
        }
        catch (error) {
            console.log(error);
        }
    }
};
TelegramMessageService = TelegramMessageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [message_handler_service_1.MessageHandlerService,
        socket_state_service_1.SocketStateService,
        social_service_1.SocialService,
        config_1.ConfigService,
        chat_initializer_service_1.ChatInitializerService])
], TelegramMessageService);
exports.TelegramMessageService = TelegramMessageService;
//# sourceMappingURL=telegram-message.service.js.map