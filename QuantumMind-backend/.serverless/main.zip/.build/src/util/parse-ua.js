"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseUserAgent = void 0;
const ua_parser_js_1 = __importDefault(require("ua-parser-js"));
const parseUserAgent = (userAgent) => {
    const parsed = new ua_parser_js_1.default(userAgent);
    const { browser, os, device } = parsed.getResult();
    return {
        browser: (browser === null || browser === void 0 ? void 0 : browser.name) || 'unknown',
        os: (os === null || os === void 0 ? void 0 : os.name) || 'unknown',
        device: (device === null || device === void 0 ? void 0 : device.type) || 'unknown',
    };
};
exports.parseUserAgent = parseUserAgent;
//# sourceMappingURL=parse-ua.js.map