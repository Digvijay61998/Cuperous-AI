export declare const generateId: (pretext: string, length?: number) => string;
