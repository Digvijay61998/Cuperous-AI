export declare class ReportParamsDto {
    readonly startDate: string;
    readonly endDate: string;
    id: string;
    agentId?: string;
}
