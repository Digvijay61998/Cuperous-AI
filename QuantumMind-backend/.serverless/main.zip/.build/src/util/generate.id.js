"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateId = void 0;
const nanoid_1 = require("nanoid");
const generateId = (pretext, length = 10) => {
    const id = pretext ? `${pretext}_${(0, nanoid_1.nanoid)(length)}` : (0, nanoid_1.nanoid)(length);
    return id;
};
exports.generateId = generateId;
//# sourceMappingURL=generate.id.js.map