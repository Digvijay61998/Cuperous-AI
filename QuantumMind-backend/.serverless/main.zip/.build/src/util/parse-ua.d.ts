export declare const parseUserAgent: (userAgent: string) => {
    browser: string;
    os: string;
    device: string;
};
