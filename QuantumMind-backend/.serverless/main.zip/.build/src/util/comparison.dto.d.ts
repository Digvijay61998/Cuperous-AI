export declare class ComparisonDto {
    param1: string;
    param2: string;
    startDate: string;
    endDate: string;
}
