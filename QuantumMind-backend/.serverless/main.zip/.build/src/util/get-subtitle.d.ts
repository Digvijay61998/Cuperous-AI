export declare const getDaySubtitle: (day: number) => string;
