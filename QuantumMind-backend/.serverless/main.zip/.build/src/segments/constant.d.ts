export declare const SEGMENT_PROVIDER = "SEGMENT_MODEL";
