"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SegmentProvider = void 0;
const segments_entity_1 = require("./entities/segments.entity");
const constant_1 = require("./constant");
const constants_1 = require("src/constants");
exports.SegmentProvider = [
    {
        provide: constant_1.SEGMENT_PROVIDER,
        useFactory: (connection) => connection.model(segments_entity_1.Segment.name, segments_entity_1.SegmentSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=segments.provider.js.map