"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SegmentsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SegmentsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const get_subtitle_1 = require("src/util/get-subtitle");
const constant_1 = require("./constant");
const bson_1 = require("bson");
const conversation_status_enum_1 = require("src/conversation/enums/conversation-status.enum");
let SegmentsService = SegmentsService_1 = class SegmentsService {
    constructor(segmentModel) {
        this.segmentModel = segmentModel;
        this.logger = new common_1.Logger(SegmentsService_1.name);
    }
    async create(createSegmentDto) {
        try {
            const segment = new this.segmentModel(Object.assign({}, createSegmentDto));
            return segment.save();
        }
        catch (error) {
            this.logger.error(`Error while creating segment: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll() {
        try {
            return this.segmentModel.find().populate("visitors", "name email");
        }
        catch (error) {
            this.logger.error(`Error while fetching segments: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getVisitors(segmentId) {
        try {
            const segment = await this.segmentModel
                .findOne({ _id: segmentId })
                .populate({
                path: "visitors.visitorId",
                populate: {
                    path: "bot",
                    select: "name",
                },
                options: {
                    limit: 1,
                },
            });
            return segment.visitors;
        }
        catch (error) {
            this.logger.error(`Error while fetching visitors: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async addVisitor(segmentId, visitorId) {
        try {
            const segment = await this.segmentModel.findOne({
                _id: segmentId,
            });
            if (segment) {
                const existingVisitors = segment.visitors.map((visitor) => visitor.visitorId.toString());
                console.log({ existingVisitors: existingVisitors.includes(visitorId) });
                if (!existingVisitors.includes(visitorId)) {
                    segment.visitors.push({
                        visitorId: new bson_1.ObjectId(visitorId),
                    });
                    return segment.save();
                }
                else {
                    throw new common_1.HttpException("Visitor already exists", 400);
                }
            }
        }
        catch (error) {
            this.logger.error(`Error while adding visitor: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async removeVisitor(segmentId, visitorId) {
        try {
            const segment = await this.segmentModel.findOne({
                _id: segmentId,
            });
            if (!segment) {
                throw new Error("Segment not found");
            }
            const existingVisitors = segment.visitors.map((visitor) => visitor.visitorId.toString());
            if (existingVisitors.includes(visitorId)) {
                segment.visitors = segment.visitors.filter((visitor) => visitor.visitorId.toString() !== visitorId);
            }
            return segment.save();
        }
        catch (error) {
            this.logger.error(`Error while removing visitor: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async removeSegment(segmentId) {
        try {
            return this.segmentModel.deleteOne({ _id: segmentId });
        }
        catch (error) {
            this.logger.error(`Error while removing segment: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getSegmentsForNode() {
        const segments = await this.segmentModel.find();
        return segments.map((segment) => ({
            id: segment._id,
            name: segment.name,
        }));
    }
    async getTotalCount(days = 30) {
        const total = await this.segmentModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.segmentModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Segments",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "segment",
        };
    }
    async VisitorCount(days = 30) {
        const response = await this.segmentModel.aggregate([
            { $unwind: "$visitors" },
            {
                $group: {
                    _id: null,
                    total: { $sum: 1 },
                    agoCount: {
                        $sum: {
                            $cond: [
                                {
                                    $gte: [
                                        "$visitors.addedAt",
                                        new Date(new Date().setDate(new Date().getDate() - days)),
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    total: "$total" || 0,
                    agoCount: "$agoCount" || 0,
                },
            },
        ]);
        if (response.length === 0) {
            return {
                stats: 0,
                trendNumber: 0,
                trend: "positive",
                title: "Total Visitors",
                subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
                type: "visitor",
            };
        }
        const { total, agoCount } = response[0];
        const percentageChange = Math.round((agoCount / total) * 100);
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Visitors",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
        };
    }
    async newVisitorCount(days = 7) {
        const response = await this.segmentModel.aggregate([
            { $unwind: "$visitors" },
            {
                $group: {
                    _id: null,
                    total: { $sum: 1 },
                    agoCount: {
                        $sum: {
                            $cond: [
                                {
                                    $gte: [
                                        "$visitors.addedAt",
                                        new Date(new Date().setDate(new Date().getDate() - days)),
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    total: "$total" || 0,
                    agoCount: "$agoCount" || 0,
                },
            },
        ]);
        if (response.length === 0) {
            return {
                stats: 0,
                trendNumber: 0,
                trend: "positive",
                title: "New Visitors",
                subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
                type: "visitor",
            };
        }
        const { total, agoCount } = response[0];
        const percentageChange = Math.round((agoCount / total) * 100);
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "New Visitors",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
        };
    }
    async getSegmentStats(days = 2) {
        const result = await Promise.all([
            this.getTotalCount(days),
            this.VisitorCount(days),
            this.newVisitorCount(days),
        ]);
        return result;
    }
    async getAllSegmentsOfVisitor(visitorId) {
        const segments = await this.segmentModel
            .find({
            "visitors.visitorId": visitorId,
        })
            .select("name");
        return segments;
    }
    async activeStats(user) {
        const totalActive = await this.segmentModel.countDocuments({
            status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
        });
        const myActive = await this.segmentModel.countDocuments({
            status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
            agents: { $in: [user._id] },
        });
        const activeAnonymously = await this.segmentModel.countDocuments({
            status: conversation_status_enum_1.ConversationStatusEnum.IN_PROGRESS,
        });
    }
    async findSegmentsVisitorsCount() {
        const segments = await this.segmentModel.aggregate([
            {
                $project: {
                    name: 1,
                    numberOfVisitors: {
                        $cond: {
                            if: { $isArray: "$visitors" },
                            then: { $size: "$visitors" },
                            else: 0,
                        },
                    },
                },
            },
        ]);
        return segments;
    }
    async findSegmentsVisitorsStats(query) {
        try {
            const { startDate, endDate, segmentId } = query;
            const queryObject = {};
            if (segmentId)
                queryObject["id"] = segmentId;
            if (startDate)
                queryObject["createdAt"] = { $gte: startDate };
            if (endDate)
                queryObject["createdAt"] = { $lte: endDate };
            if (startDate && endDate)
                queryObject["createdAt"] = { $gte: startDate, $lte: endDate };
            const segments = this.segmentModel.find(queryObject);
            return segments;
        }
        catch (error) {
            this.logger.error(`Error while getting all visitors : ${error.message}`);
        }
    }
    async getDayWisePerformance(params) {
        const { segmentId, startDate } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (segmentId) {
            match["_id"] = new bson_1.ObjectId(segmentId);
        }
        try {
            const data = await this.segmentModel.aggregate([
                {
                    $match: match,
                },
                {
                    $unwind: {
                        path: "$visitors",
                    },
                },
                {
                    $group: {
                        _id: {
                            $isoDayOfWeek: "$visitors.addedAt",
                        },
                        total: { $sum: 1 },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        day: {
                            $switch: {
                                branches: [
                                    { case: { $eq: ["$_id", 1] }, then: "MON" },
                                    { case: { $eq: ["$_id", 2] }, then: "TUE" },
                                    { case: { $eq: ["$_id", 3] }, then: "WED" },
                                    { case: { $eq: ["$_id", 4] }, then: "THU" },
                                    { case: { $eq: ["$_id", 5] }, then: "FRI" },
                                    { case: { $eq: ["$_id", 6] }, then: "SAT" },
                                    { case: { $eq: ["$_id", 7] }, then: "SUN" },
                                ],
                            },
                        },
                        total: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting bot conversation performance ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getDateWiseSegmentVisitors(params) {
        const { segmentId, startDate } = params;
        let endDate = params.endDate;
        if (!endDate) {
            endDate = new Date().toISOString();
        }
        const match = {};
        if (startDate) {
            match["createdAt"] = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }
        if (segmentId) {
            match["_id"] = new bson_1.ObjectId(segmentId);
        }
        try {
            const data = await this.segmentModel.aggregate([
                {
                    $match: match,
                },
                {
                    $unwind: {
                        path: "$visitors",
                    },
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$visitors.addedAt",
                            },
                        },
                        total: { $sum: 1 },
                    },
                },
                {
                    $sort: {
                        _id: 1,
                    },
                },
                {
                    $project: {
                        date: "$_id",
                        total: 1,
                        _id: 0,
                    },
                },
            ]);
            return data;
        }
        catch (error) {
            this.logger.error(`Error while getting date wise conversations ${error}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getDateWiseSegmentCompare(query) {
        try {
            const { param1, param2, startDate } = query;
            let endDate = query.endDate;
            if (!endDate) {
                endDate = new Date().toISOString();
            }
            const match = {};
            if (!startDate) {
                match["visitors.addedAt"] = {
                    $lte: new Date(endDate),
                };
            }
            if (startDate && endDate) {
                match["visitors.addedAt"] = {
                    $gte: new Date(startDate),
                    $lte: new Date(endDate),
                };
            }
            const result = await this.segmentModel.aggregate([
                {
                    $unwind: "$visitors",
                },
                {
                    $match: match,
                },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$visitors.addedAt",
                            },
                        },
                        segment1: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$_id", new bson_1.ObjectId(param1)] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                        segment2: {
                            $sum: {
                                $cond: {
                                    if: { $eq: ["$_id", new bson_1.ObjectId(param2)] },
                                    then: 1,
                                    else: 0,
                                },
                            },
                        },
                    },
                },
                {
                    $sort: {
                        _id: -1,
                    },
                },
                {
                    $project: {
                        _id: 0,
                        date: "$_id",
                        segment1: 1,
                        segment2: 1,
                    },
                },
            ]);
            return result;
        }
        catch (err) {
            this.logger.error(`Error in getting offer dae wise compare ${err.message}`);
            throw new common_1.HttpException(err.message, err.status || 500);
        }
    }
};
SegmentsService = SegmentsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constant_1.SEGMENT_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model])
], SegmentsService);
exports.SegmentsService = SegmentsService;
//# sourceMappingURL=segments.service.js.map