import mongoose, { Model } from "mongoose";
import { CreateSegmentDto } from "./dto/create-segment.dto";
import { SegmentDocument } from "./entities/segments.entity";
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { SegmentQueryParams } from "./dto/get-segment.params.dto";
import { ComparisonDto } from "src/util/comparison.dto";
export declare class SegmentsService {
    private segmentModel;
    private readonly logger;
    constructor(segmentModel: Model<SegmentDocument>);
    create(createSegmentDto: CreateSegmentDto): Promise<import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    findAll(): Promise<Omit<import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }, never>[]>;
    getVisitors(segmentId: string): Promise<import("./entities/segments.entity").VisitorInfo[]>;
    addVisitor(segmentId: string, visitorId: string): Promise<import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    removeVisitor(segmentId: string, visitorId: string): Promise<import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    removeSegment(segmentId: string): Promise<import("mongodb").DeleteResult>;
    getSegmentsForNode(): Promise<{
        id: any;
        name: string;
    }[]>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    VisitorCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }>;
    newVisitorCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }>;
    getSegmentStats(days?: number): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }]>;
    getAllSegmentsOfVisitor(visitorId: string): Promise<(import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    })[]>;
    activeStats(user: JwtPayload): Promise<void>;
    findSegmentsVisitorsCount(): Promise<any[]>;
    findSegmentsVisitorsStats(query: SegmentQueryParams): Promise<(import("./entities/segments.entity").Segment & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    })[]>;
    getDayWisePerformance(params: SegmentQueryParams): Promise<any[]>;
    getDateWiseSegmentVisitors(params: SegmentQueryParams): Promise<any[]>;
    getDateWiseSegmentCompare(query: ComparisonDto): Promise<any[]>;
}
