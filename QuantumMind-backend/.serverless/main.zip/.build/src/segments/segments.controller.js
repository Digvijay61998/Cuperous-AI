"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SegmentsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("src/auth/Public/public.decorator");
const add_visitor_to_segement_dto_1 = require("./dto/add-visitor-to-segement.dto");
const create_segment_dto_1 = require("./dto/create-segment.dto");
const segments_service_1 = require("./segments.service");
const get_segment_params_dto_1 = require("./dto/get-segment.params.dto");
const comparison_dto_1 = require("src/util/comparison.dto");
let SegmentsController = class SegmentsController {
    constructor(segmentsService) {
        this.segmentsService = segmentsService;
    }
    async createSegment(createSegmentDto) {
        return this.segmentsService.create(createSegmentDto);
    }
    async findAll() {
        return this.segmentsService.findAll();
    }
    async segmentSummary() {
        return this.segmentsService.findSegmentsVisitorsCount();
    }
    async segmentSummaryStats(query) {
        return this.segmentsService.getDayWisePerformance(query);
    }
    async segmentDateWiseStats(query) {
        return this.segmentsService.getDateWiseSegmentVisitors(query);
    }
    async segmentDateWiseCompare(query) {
        return this.segmentsService.getDateWiseSegmentCompare(query);
    }
    async getStats() {
        return this.segmentsService.getSegmentStats();
    }
    async getSegmentsByVisitorId(visitorId) {
        return await this.segmentsService.getAllSegmentsOfVisitor(visitorId);
    }
    async getVisitors(segmentId) {
        return this.segmentsService.getVisitors(segmentId);
    }
    async delete(segmentId) {
        return this.segmentsService.removeSegment(segmentId);
    }
    async addUser(segmentId, body) {
        return this.segmentsService.addVisitor(segmentId, body.visitorId);
    }
    async removeUser(segmentId, body) {
        return this.segmentsService.removeVisitor(segmentId, body.visitorId);
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_segment_dto_1.CreateSegmentDto]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "createSegment", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "findAll", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/count'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "segmentSummary", null);
__decorate([
    (0, common_1.Get)('report/day-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_segment_params_dto_1.SegmentQueryParams]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "segmentSummaryStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-performance'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_segment_params_dto_1.SegmentQueryParams]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "segmentDateWiseStats", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('report/date-wise-compare'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [comparison_dto_1.ComparisonDto]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "segmentDateWiseCompare", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':visitorId'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('visitorId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "getSegmentsByVisitorId", null);
__decorate([
    (0, common_1.Get)(':id/visitors'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "getVisitors", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "delete", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)(':id/add-visitor'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, add_visitor_to_segement_dto_1.AddVisitorToSegmentDto]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "addUser", null);
__decorate([
    (0, common_1.Post)(':id/remove-visitor'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, add_visitor_to_segement_dto_1.AddVisitorToSegmentDto]),
    __metadata("design:returntype", Promise)
], SegmentsController.prototype, "removeUser", null);
SegmentsController = __decorate([
    (0, common_1.Controller)('segments'),
    (0, swagger_1.ApiTags)('Segments'),
    (0, swagger_1.ApiSecurity)('bearer'),
    __metadata("design:paramtypes", [segments_service_1.SegmentsService])
], SegmentsController);
exports.SegmentsController = SegmentsController;
//# sourceMappingURL=segments.controller.js.map