export declare class SegmentsModule {
}
