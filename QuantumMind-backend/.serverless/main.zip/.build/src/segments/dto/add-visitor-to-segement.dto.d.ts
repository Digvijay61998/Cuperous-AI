export declare class AddVisitorToSegmentDto {
    visitorId: string;
}
