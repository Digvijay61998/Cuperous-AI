export declare class SegmentQueryParams {
    segmentId?: string;
    comapreSegmentId?: string;
    startDate?: string;
    endDate?: string;
}
