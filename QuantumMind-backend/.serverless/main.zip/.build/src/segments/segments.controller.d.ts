/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { AddVisitorToSegmentDto } from './dto/add-visitor-to-segement.dto';
import { CreateSegmentDto } from './dto/create-segment.dto';
import { SegmentsService } from './segments.service';
import { SegmentQueryParams } from './dto/get-segment.params.dto';
import { ComparisonDto } from 'src/util/comparison.dto';
export declare class SegmentsController {
    private readonly segmentsService;
    constructor(segmentsService: SegmentsService);
    createSegment(createSegmentDto: CreateSegmentDto): Promise<import("./entities/segments.entity").Segment & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(): Promise<Omit<import("./entities/segments.entity").Segment & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }, never>[]>;
    segmentSummary(): Promise<any[]>;
    segmentSummaryStats(query: SegmentQueryParams): Promise<any[]>;
    segmentDateWiseStats(query: SegmentQueryParams): Promise<any[]>;
    segmentDateWiseCompare(query: ComparisonDto): Promise<any[]>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    } | {
        stats: any;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type?: undefined;
    }]>;
    getSegmentsByVisitorId(visitorId: string): Promise<(import("./entities/segments.entity").Segment & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    })[]>;
    getVisitors(segmentId: string): Promise<import("./entities/segments.entity").VisitorInfo[]>;
    delete(segmentId: string): Promise<import("mongodb").DeleteResult>;
    addUser(segmentId: string, body: AddVisitorToSegmentDto): Promise<import("./entities/segments.entity").Segment & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    removeUser(segmentId: string, body: AddVisitorToSegmentDto): Promise<import("./entities/segments.entity").Segment & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
