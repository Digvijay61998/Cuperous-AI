import * as mongoose from 'mongoose';
export interface VisitorInfo {
    visitorId: any;
    addedAt?: Date;
}
export type SegmentDocument = Segment & mongoose.Document;
export declare class Segment {
    name: string;
    visitors: VisitorInfo[];
}
export declare const SegmentSchema: mongoose.Schema<Segment, mongoose.Model<Segment, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Segment>;
