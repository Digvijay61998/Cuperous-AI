"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEGMENT_PROVIDER = void 0;
exports.SEGMENT_PROVIDER = 'SEGMENT_MODEL';
//# sourceMappingURL=constant.js.map