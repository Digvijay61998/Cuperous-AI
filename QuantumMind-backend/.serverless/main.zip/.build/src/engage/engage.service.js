"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EngageService = void 0;
const common_1 = require("@nestjs/common");
const advertisement_service_1 = require("src/advertisement/advertisement.service");
const offer_service_1 = require("src/offer/offer.service");
const socket_state_service_1 = require("src/socket/socket-state.service");
const event_emitter_1 = require("@nestjs/event-emitter");
const conversation_service_1 = require("src/conversation/conversation.service");
const message_handler_service_1 = require("src/message-handler/message-handler.service");
let EngageService = class EngageService {
    constructor(offerService, advertisementService, socketStateService, eventEmmitter, conversationService, messageHandlerService) {
        this.offerService = offerService;
        this.advertisementService = advertisementService;
        this.socketStateService = socketStateService;
        this.eventEmmitter = eventEmmitter;
        this.conversationService = conversationService;
        this.messageHandlerService = messageHandlerService;
    }
    async handleEndConversationByAgent(conversationId, visitorId) {
        this.eventEmmitter.emit('end-conversation-by-agent', {
            conversationId,
            userId: visitorId,
        });
    }
    async ReportConversation(conversationId, visitorId) {
        this.eventEmmitter.emit('report-conversation', {
            conversationId,
            userId: visitorId,
        });
    }
    async PublishOfferOrAdvertisement(visitorId, data) {
        if (data) {
            console.log(data);
            this.eventEmmitter.emit('publish-events', {
                userId: visitorId,
                data,
                event: `publish-${data.type}`,
            });
        }
    }
    async sendTranscriptToVisitor(data) {
        const { visitorId, email, name } = data;
        console.log({ visitorId, email, name });
        const userData = this.socketStateService.getUserData(visitorId);
        if (userData) {
            const { conversationId } = userData;
            console.log({ conversationId });
            if (conversationId) {
                this.eventEmmitter.emit('send-transcript-to-visitor', {
                    conversationId,
                    email,
                    visitorId,
                    name,
                });
            }
        }
    }
};
EngageService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [offer_service_1.OfferService,
        advertisement_service_1.AdvertisementService,
        socket_state_service_1.SocketStateService,
        event_emitter_1.EventEmitter2,
        conversation_service_1.ConversationService,
        message_handler_service_1.MessageHandlerService])
], EngageService);
exports.EngageService = EngageService;
//# sourceMappingURL=engage.service.js.map