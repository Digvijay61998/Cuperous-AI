import { OnGatewayConnection } from "@nestjs/websockets";
import { Observable } from "rxjs";
import { MessageHandlerService } from "src/message-handler/message-handler.service";
import { SocketStateService } from "src/socket/socket-state.service";
import { AuthenticatedSocket } from "src/socket/socket.adaptor";
import { Server } from "socket.io";
import { ConversationService } from "src/conversation/conversation.service";
import { FeedbackService } from "src/feedback/feedback.service";
import { EngageService } from "./engage.service";
import { EventEmitter2 } from "@nestjs/event-emitter";
export declare class EngageGateway implements OnGatewayConnection {
    private readonly messageHandlerService;
    private readonly socketStateService;
    private readonly conversationService;
    private readonly feedbackService;
    private readonly engageService;
    private readonly eventEmmitter;
    constructor(messageHandlerService: MessageHandlerService, socketStateService: SocketStateService, conversationService: ConversationService, feedbackService: FeedbackService, engageService: EngageService, eventEmmitter: EventEmitter2);
    server: Server;
    handleEvents(client: AuthenticatedSocket, data: any): Promise<Observable<any>>;
    submitFeedback(client: AuthenticatedSocket, data: any): Promise<void>;
    handleEndConversation(client: AuthenticatedSocket, data: any): Promise<void>;
    handleReportConversation(client: AuthenticatedSocket, data: any): Promise<void>;
    handlePublish(client: AuthenticatedSocket, data: any): Promise<void>;
    handleSendTranscript(client: AuthenticatedSocket, data: any): Promise<void>;
    handleConnection(client: AuthenticatedSocket, ...args: any[]): Promise<any>;
}
