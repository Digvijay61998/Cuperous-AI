import { AdvertisementService } from 'src/advertisement/advertisement.service';
import { OfferService } from 'src/offer/offer.service';
import { SocketStateService } from 'src/socket/socket-state.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConversationService } from 'src/conversation/conversation.service';
import { MessageHandlerService } from 'src/message-handler/message-handler.service';
export declare class EngageService {
    private readonly offerService;
    private readonly advertisementService;
    private readonly socketStateService;
    private readonly eventEmmitter;
    private readonly conversationService;
    private readonly messageHandlerService;
    constructor(offerService: OfferService, advertisementService: AdvertisementService, socketStateService: SocketStateService, eventEmmitter: EventEmitter2, conversationService: ConversationService, messageHandlerService: MessageHandlerService);
    handleEndConversationByAgent(conversationId: string, visitorId: string): Promise<void>;
    ReportConversation(conversationId: string, visitorId: string): Promise<void>;
    PublishOfferOrAdvertisement(visitorId: string, data: any): Promise<void>;
    sendTranscriptToVisitor(data: any): Promise<void>;
}
