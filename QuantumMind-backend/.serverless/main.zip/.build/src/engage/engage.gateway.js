"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EngageGateway = void 0;
const common_1 = require("@nestjs/common");
const websockets_1 = require("@nestjs/websockets");
const rxjs_1 = require("rxjs");
const message_handler_service_1 = require("src/message-handler/message-handler.service");
const redis_propagate_interceptors_1 = require("src/redis-propagate/redis-propagate.interceptors");
const socket_state_service_1 = require("src/socket/socket-state.service");
const socket_io_1 = require("socket.io");
const conversation_service_1 = require("src/conversation/conversation.service");
const util_1 = require("src/util");
const feedback_for_enum_1 = require("src/feedback/enums/feedback-for.enum");
const feedback_service_1 = require("src/feedback/feedback.service");
const engage_service_1 = require("./engage.service");
const event_emitter_1 = require("@nestjs/event-emitter");
let EngageGateway = class EngageGateway {
    constructor(messageHandlerService, socketStateService, conversationService, feedbackService, engageService, eventEmmitter) {
        this.messageHandlerService = messageHandlerService;
        this.socketStateService = socketStateService;
        this.conversationService = conversationService;
        this.feedbackService = feedbackService;
        this.engageService = engageService;
        this.eventEmmitter = eventEmmitter;
    }
    async handleEvents(client, data) {
        var _a, _b, _c;
        const { userId, role } = client.auth;
        const userData = this.socketStateService.getUserData(userId);
        const { handledByAgent, assignedAgentId, platform } = userData;
        if (data.event === "chat-message-bot") {
            if (handledByAgent && assignedAgentId && role === "visitor") {
                this.messageHandlerService.sendMessageToAgent(assignedAgentId, {
                    type: ((_a = data.data) === null || _a === void 0 ? void 0 : _a.type) || "text",
                    value: data.data.message,
                    from: userId,
                }, this.socketStateService.getUserData(userId));
            }
            else {
                this.messageHandlerService.handleMessage(data.data.message, client, data.data.type, data.data.language);
            }
        }
        else if (data.event === "chat-message-from-agent") {
            this.messageHandlerService.emitEventToUser(data.data.to, "chat-message-bot", {
                message: {
                    type: ((_b = data.data) === null || _b === void 0 ? void 0 : _b.type) || "text",
                    value: data.data.message,
                    senderId: userId,
                    time: new Date().toISOString(),
                    id: (0, util_1.generateId)("message", 10),
                },
            }, platform);
        }
        const sendResponse = {
            type: ((_c = data.data) === null || _c === void 0 ? void 0 : _c.type) || "text",
            value: data.data.message,
            senderId: userId,
            time: new Date().toISOString(),
            id: (0, util_1.generateId)("message", 10),
        };
        return (0, rxjs_1.of)({
            event: "chat-message-me",
            data: {
                message: sendResponse,
            },
        });
    }
    async submitFeedback(client, data) {
        const { userId, role } = client.auth;
        const { rating, comment } = data === null || data === void 0 ? void 0 : data.data;
        const dataForFeedback = {
            rating,
            comment,
            visitor: null,
            conversation: null,
            bot: null,
            feedbackFor: feedback_for_enum_1.FeedbackForEnum.BOT,
        };
        if (role === "visitor") {
            const { assignedAgentId, botId, conversationId } = this.socketStateService.getUserData(userId);
            dataForFeedback.visitor = userId;
            dataForFeedback.conversation = conversationId;
            dataForFeedback.bot = botId;
            if (assignedAgentId) {
                dataForFeedback.feedbackFor = feedback_for_enum_1.FeedbackForEnum.AGENT;
                dataForFeedback["agent"] = assignedAgentId;
            }
        }
        await this.feedbackService.create(dataForFeedback);
    }
    async handleEndConversation(client, data) {
        if (data.data.conversationId)
            return await this.engageService.handleEndConversationByAgent(data.data.conversationId, data.data.visitorId);
    }
    async handleReportConversation(client, data) {
        if (data.data.conversationId) {
            return await this.engageService.ReportConversation(data.data.conversationId, data.data.visitorId);
        }
    }
    async handlePublish(client, data) {
        return await this.engageService.PublishOfferOrAdvertisement(data.data.visitorId, data.data);
    }
    async handleSendTranscript(client, data) {
        return await this.engageService.sendTranscriptToVisitor(data.data);
    }
    async handleConnection(client, ...args) {
        const { role } = client.auth;
        if (role === "visitor") {
            return await this.messageHandlerService.handleMessage("start", client, "text", "en");
        }
    }
};
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], EngageGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)("events"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "handleEvents", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("submit-feedback"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "submitFeedback", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("end-conversation"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "handleEndConversation", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("report-conversation"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "handleReportConversation", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("publish"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "handlePublish", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("send-transcript"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EngageGateway.prototype, "handleSendTranscript", null);
EngageGateway = __decorate([
    (0, common_1.UseInterceptors)(redis_propagate_interceptors_1.RedisPropagatorInterceptor),
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: "*",
        },
        path: "/socket.io/engage",
    }),
    __metadata("design:paramtypes", [message_handler_service_1.MessageHandlerService,
        socket_state_service_1.SocketStateService,
        conversation_service_1.ConversationService,
        feedback_service_1.FeedbackService,
        engage_service_1.EngageService,
        event_emitter_1.EventEmitter2])
], EngageGateway);
exports.EngageGateway = EngageGateway;
//# sourceMappingURL=engage.gateway.js.map