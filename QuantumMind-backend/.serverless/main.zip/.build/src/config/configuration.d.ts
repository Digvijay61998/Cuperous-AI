declare const _default: () => {
    server: {
        domain: string;
    };
    admin: {
        name: string;
        email: string;
        password: string;
    };
    session: {
        secret: string;
    };
    port: number;
    database: {
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
    };
    telegram: {
        token: string;
        botId: string;
    };
    jwt: {
        secret: string;
        signOptions: {
            expiresIn: string;
            issuer: string;
        };
        refreshExpiresInDays: string | number;
    };
    mail: {
        host: string;
        port: number;
        username: string;
        password: string;
        from: string;
        expiresIn: string | number;
    };
    bcrypt: {
        saltOrRounds: number;
    };
    tags: {
        defaultTags: string | string[];
    };
    redis: {
        host: string;
        port: number;
        password: string;
    };
    google: {
        translate: string;
    };
    attributesList: {
        value: string;
        label: string;
    }[];
    languages: {
        value: string;
        label: string;
        code: string;
    }[];
    encryption: {
        key: string;
    };
    social: {
        verifyToken: string;
        webhookBaseUrl: string;
        facebook: {
            baseUrl: string;
        };
        telegram: {
            baseUrl: string;
            webhookUrl: string;
        };
        whatsapp: {
            baseUrl: string;
        };
    };
    nlp: {
        url: string;
    };
    scraper: {
        url: string;
    };
    delay: {
        node: string | number;
        message: string | number;
    };
};
export default _default;
