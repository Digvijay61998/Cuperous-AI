"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentStatusEnum = void 0;
var AgentStatusEnum;
(function (AgentStatusEnum) {
    AgentStatusEnum["ONLINE"] = "online";
    AgentStatusEnum["OFFLINE"] = "offline";
    AgentStatusEnum["BUSY"] = "busy";
    AgentStatusEnum["AWAY"] = "away";
})(AgentStatusEnum = exports.AgentStatusEnum || (exports.AgentStatusEnum = {}));
//# sourceMappingURL=agent-status.enum.js.map