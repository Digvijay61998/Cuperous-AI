"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleEnum = void 0;
var RoleEnum;
(function (RoleEnum) {
    RoleEnum["ADMIN"] = "admin";
    RoleEnum["AGENT"] = "agent";
})(RoleEnum = exports.RoleEnum || (exports.RoleEnum = {}));
//# sourceMappingURL=agent-role.enum.js.map