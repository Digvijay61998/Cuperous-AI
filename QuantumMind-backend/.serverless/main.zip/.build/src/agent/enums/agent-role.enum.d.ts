export declare enum RoleEnum {
    ADMIN = "admin",
    AGENT = "agent"
}
