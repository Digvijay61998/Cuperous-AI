import { OnModuleInit } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { CreateAgentDto } from "./dto/create-agent.dto";
import { UpdateAgentDto } from "./dto/update-agent.dto";
import { AgentDocument } from "./entities/agent.entity";
import mongoose, { Model } from "mongoose";
import { AgentQueryParams } from "./agent-query.params";
import { RoleEnum } from "./enums/agent-role.enum";
import { AgentStatusEnum } from "./enums/agent-status.enum";
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { ConversationService } from "src/conversation/conversation.service";
import { ReportParamsDto } from "src/util/report-params.dto";
export declare class AgentService implements OnModuleInit {
    private readonly agentModel;
    private readonly configService;
    private readonly conversationService;
    private readonly logger;
    onModuleInit(): Promise<void>;
    constructor(agentModel: Model<AgentDocument>, configService: ConfigService, conversationService: ConversationService);
    encryptPassword(password: string): Promise<string>;
    comparePassword(password: string, receivedPassword: string): Promise<boolean>;
    authenticateAgent(email: string, password: string): Promise<AgentDocument>;
    create(createAgentDto: CreateAgentDto): Promise<import("./entities/agent.entity").Agent & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    agentList(): Promise<any[]>;
    remove(agentId: string): Promise<void>;
    update(agentId: string, updateAgentDto: UpdateAgentDto): Promise<{
        message: string;
    }>;
    findAll(query: AgentQueryParams): Promise<{
        data: Omit<Omit<import("./entities/agent.entity").Agent & mongoose.Document<any, any, any> & {
            _id: mongoose.Types.ObjectId;
        }, never>, never>[];
        count: number;
    }>;
    findOne(agentId: string): Promise<import("./entities/agent.entity").Agent & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    assignAgent(botId: string): Promise<AgentDocument>;
    addBotToAgent(botId: any, agents: string[]): Promise<void>;
    updateAgentStatus(agentId: string, status: AgentStatusEnum): Promise<void>;
    getMe(user: JwtPayload): Promise<{
        email: string;
        username: string;
        _id: any;
        fullName: string;
        role: RoleEnum;
    }>;
    addConversations({ agentId, conversationId, }: {
        agentId: string;
        conversationId: string;
    }): Promise<import("./entities/agent.entity").Agent & mongoose.Document<any, any, any> & {
        _id: mongoose.Types.ObjectId;
    }>;
    updateRatingAndFeedback(agentId: string, rating: number, feedbackId: string): Promise<void>;
    getTotalCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getOnlineAgentsCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getActiveAgentsCount(days?: number): Promise<{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }>;
    getStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getTotalAgent(): Promise<any>;
    dayWisePerformance(query: ReportParamsDto): Promise<any[]>;
    dateWiseConversations(query: ReportParamsDto): Promise<any[]>;
    addServiceRequest(data: {
        agentId: string;
        ticketId: string;
    }): Promise<void>;
    welcomeToAgent(agentId: any): Promise<{
        requestHandled: number;
        days: number;
        visitorCount: number;
    }>;
}
