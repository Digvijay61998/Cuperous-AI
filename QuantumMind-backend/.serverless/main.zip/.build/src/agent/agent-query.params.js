"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentQueryParams = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const agent_status_enum_1 = require("./enums/agent-status.enum");
class AgentQueryParams {
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, swagger_1.ApiPropertyOptional)({
        default: 0,
    }),
    __metadata("design:type", Number)
], AgentQueryParams.prototype, "skip", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    (0, swagger_1.ApiPropertyOptional)({
        default: 10,
    }),
    __metadata("design:type", Number)
], AgentQueryParams.prototype, "limit", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, class_validator_1.IsEnum)(agent_status_enum_1.AgentStatusEnum),
    (0, swagger_1.ApiPropertyOptional)({
        enum: agent_status_enum_1.AgentStatusEnum,
    }),
    __metadata("design:type", String)
], AgentQueryParams.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, swagger_1.ApiPropertyOptional)({
        isArray: true,
    }),
    (0, swagger_1.ApiProperty)({
        isArray: true,
    }),
    __metadata("design:type", Array)
], AgentQueryParams.prototype, "tags", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => String),
    (0, swagger_1.ApiPropertyOptional)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], AgentQueryParams.prototype, "bot", void 0);
exports.AgentQueryParams = AgentQueryParams;
//# sourceMappingURL=agent-query.params.js.map