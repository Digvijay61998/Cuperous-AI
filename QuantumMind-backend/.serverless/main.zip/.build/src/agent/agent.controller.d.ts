/// <reference types="mongoose/types/aggregate" />
/// <reference types="mongoose/types/callback" />
/// <reference types="mongoose/types/collection" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/expressions" />
/// <reference types="mongoose/types/helpers" />
/// <reference types="mongoose/types/middlewares" />
/// <reference types="mongoose/types/indexes" />
/// <reference types="mongoose/types/models" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/populate" />
/// <reference types="mongoose/types/query" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose/types/schematypes" />
/// <reference types="mongoose/types/session" />
/// <reference types="mongoose/types/types" />
/// <reference types="mongoose/types/utility" />
/// <reference types="mongoose/types/validation" />
/// <reference types="mongoose/types/virtuals" />
/// <reference types="mongoose" />
/// <reference types="mongoose/types/inferschematype" />
import { JwtPayload } from "src/auth/strategy/jwt.strategy";
import { ReportParamsDto } from "src/util/report-params.dto";
import { AgentQueryParams } from "./agent-query.params";
import { AgentService } from "./agent.service";
import { CreateAgentDto } from "./dto/create-agent.dto";
import { UpdateAgentDto } from "./dto/update-agent.dto";
export declare class AgentController {
    private readonly agentService;
    constructor(agentService: AgentService);
    create(createAgentDto: CreateAgentDto): Promise<import("./entities/agent.entity").Agent & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    findAll(query: AgentQueryParams): Promise<{
        data: Omit<Omit<import("./entities/agent.entity").Agent & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        }, never>, never>[];
        count: number;
    }>;
    welcome(agent: JwtPayload): Promise<{
        requestHandled: number;
        days: number;
        visitorCount: number;
    }>;
    getAgentList(): Promise<any[]>;
    getAgentStats(): Promise<[{
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }, {
        stats: number;
        trendNumber: number;
        trend: string;
        title: string;
        subtitle: string;
        type: string;
    }]>;
    getAgentReport(): Promise<any>;
    dayWisePerformanceReport(query: ReportParamsDto): Promise<any[]>;
    dateWisePerformanceReport(query: ReportParamsDto): Promise<any[]>;
    getMe(agent: JwtPayload): Promise<{
        email: string;
        username: string;
        _id: any;
        fullName: string;
        role: import("./enums/agent-role.enum").RoleEnum;
    }>;
    findOne(id: string): Promise<import("./entities/agent.entity").Agent & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, updateAgentDto: UpdateAgentDto): Promise<{
        message: string;
    }>;
    remove(id: string): Promise<void>;
}
