"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentProviders = void 0;
const agent_entity_1 = require("./entities/agent.entity");
const constants_1 = require("src/constants");
exports.AgentProviders = [
    {
        provide: constants_1.AGENT_PROVIDER,
        useFactory: (connection) => connection.model(agent_entity_1.Agent.name, agent_entity_1.AgentSchema),
        inject: [constants_1.DATABASE_PROVIDER],
    },
];
//# sourceMappingURL=agent.provider.js.map