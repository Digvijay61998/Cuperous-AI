import { ObjectId } from 'mongoose';
export declare class AgentQueryParams {
    skip?: number;
    limit?: number;
    status?: string;
    tags?: ObjectId[];
    bot?: string;
}
