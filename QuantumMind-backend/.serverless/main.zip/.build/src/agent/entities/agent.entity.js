"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentSchema = exports.Agent = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = __importStar(require("mongoose"));
const agent_status_enum_1 = require("../enums/agent-status.enum");
const tag_entity_1 = require("src/tag/entities/tag.entity");
const agent_role_enum_1 = require("../enums/agent-role.enum");
const common_1 = require("@nestjs/common");
let Agent = class Agent {
};
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Agent.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true }),
    __metadata("design:type", String)
], Agent.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Agent.prototype, "password", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: true,
    }),
    __metadata("design:type", Boolean)
], Agent.prototype, "active", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: agent_status_enum_1.AgentStatusEnum.OFFLINE,
    }),
    __metadata("design:type", String)
], Agent.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], Agent.prototype, "lastLogin", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Agent.prototype, "activeHours", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Conversation",
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "conversations", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Reports" }],
        default: [],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "reports", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Agent.prototype, "activeConversations", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Bot" }],
        default: [],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "assignedBots", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: tag_entity_1.Tag.name }],
        default: [],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "tags", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], Agent.prototype, "profilePic", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Ticket" }],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "serviceRequests", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], Agent.prototype, "lastSeen", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 10,
    }),
    __metadata("design:type", Number)
], Agent.prototype, "maxConcurrentChats", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: agent_role_enum_1.RoleEnum.AGENT,
    }),
    __metadata("design:type", String)
], Agent.prototype, "role", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Feedback" }],
        default: [],
    }),
    __metadata("design:type", Array)
], Agent.prototype, "feedbacks", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Agent.prototype, "totalRating", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Agent.prototype, "totalRatingCount", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 0,
    }),
    __metadata("design:type", Number)
], Agent.prototype, "rating", void 0);
Agent = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        virtuals: true,
        toJSON: {
            virtuals: true,
            transform: (doc, ret) => {
                delete ret.__v;
                delete ret.password;
                delete ret.totalRating;
                delete ret.totalRatingCount;
                return ret;
            },
        },
    })
], Agent);
exports.Agent = Agent;
exports.AgentSchema = mongoose_1.SchemaFactory.createForClass(Agent);
exports.AgentSchema.pre("remove", async function (next) {
    const agent = this;
    if (agent.role === agent_role_enum_1.RoleEnum.ADMIN) {
        next(new common_1.HttpException("Admin cannot be deleted", 400));
    }
    const Feedback = mongoose.model("Feedback");
    const Bot = mongoose.model("Bot");
    await Bot.updateMany({
        agents: { $in: [agent._id] },
    }, { $pull: { agents: agent._id } });
    await Feedback.deleteMany({ agent: agent._id });
    next();
});
//# sourceMappingURL=agent.entity.js.map