"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AgentService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const bcrypt = __importStar(require("bcryptjs"));
const constants_1 = require("src/constants");
const mongoose_1 = __importStar(require("mongoose"));
const agent_role_enum_1 = require("./enums/agent-role.enum");
const agent_status_enum_1 = require("./enums/agent-status.enum");
const get_subtitle_1 = require("src/util/get-subtitle");
const conversation_service_1 = require("src/conversation/conversation.service");
const event_emitter_1 = require("@nestjs/event-emitter");
let AgentService = AgentService_1 = class AgentService {
    async onModuleInit() {
        const email = this.configService.get("admin.email");
        const name = this.configService.get("admin.name");
        const admin = await this.agentModel.findOne({ email });
        if (!admin) {
            const originalPassword = this.configService.get("admin.password");
            const admin = new this.agentModel({
                name,
                email,
                password: await this.encryptPassword(originalPassword),
                role: agent_role_enum_1.RoleEnum.ADMIN,
            });
            await admin.save();
            this.logger.debug(`Admin created with Email ${admin.email} and password: ${originalPassword}`);
        }
        this.logger.debug("Admin Credentials are already present");
    }
    constructor(agentModel, configService, conversationService) {
        this.agentModel = agentModel;
        this.configService = configService;
        this.conversationService = conversationService;
        this.logger = new common_1.Logger(AgentService_1.name);
    }
    async encryptPassword(password) {
        const salt = await bcrypt.genSalt(this.configService.get("bcrypt.saltOrRounds"));
        return await bcrypt.hash(password, salt);
    }
    async comparePassword(password, receivedPassword) {
        return await bcrypt.compare(password, receivedPassword);
    }
    async authenticateAgent(email, password) {
        const agent = await this.agentModel.findOne({ email });
        if (agent) {
            const isMatch = await this.comparePassword(password, agent.password);
            if (isMatch) {
                agent.lastLogin = new Date();
                await agent.save();
                return agent;
            }
        }
        return null;
    }
    async create(createAgentDto) {
        this.logger.log(`Creating Agent with name ${createAgentDto.name} and email ${createAgentDto.email}`);
        try {
            const password = await this.encryptPassword(createAgentDto.password);
            const agent = await this.agentModel.create(Object.assign(Object.assign({}, createAgentDto), { password }));
            this.logger.log(`Agent created with name ${agent.name}`);
            return agent;
        }
        catch (error) {
            this.logger.error(`Error while creating Agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async agentList() {
        return await this.agentModel.aggregate([
            {
                $project: {
                    name: 1,
                    id: "$_id",
                    _id: 0,
                },
            },
        ]);
    }
    async remove(agentId) {
        this.logger.log(`Removing Agent with id ${agentId}`);
        try {
            const agent = await this.agentModel.findOne({
                _id: agentId,
            });
            if (!agent) {
                this.logger.error(`Agent not found with id ${agentId}`);
                throw new common_1.UnauthorizedException("Agent not found");
            }
            await agent.remove();
        }
        catch (error) {
            this.logger.error(`Error while removing Agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async update(agentId, updateAgentDto) {
        this.logger.log(`Updating Agent with id ${agentId}`);
        try {
            const agent = await this.agentModel.findOne({
                _id: agentId,
            });
            if (!agent) {
                this.logger.error(`Agent not found with id ${agentId}`);
                throw new common_1.UnauthorizedException("Agent not found");
            }
            if (updateAgentDto.password) {
                updateAgentDto.password = await this.encryptPassword(updateAgentDto.password);
            }
            await agent.updateOne(Object.assign({}, updateAgentDto));
            return {
                message: "Agent updated successfully",
            };
        }
        catch (error) {
            this.logger.error(`Error while updating Agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findAll(query) {
        try {
            const { skip: documentsToSkip, limit: limitOfDocuments, tags, status, bot, } = query;
            const queryObject = {};
            if (status)
                queryObject["status"] = status;
            if (tags)
                queryObject["tags"] = { $in: tags };
            if (bot)
                queryObject["assignedBots"] = { $in: [bot] };
            const agents = this.agentModel
                .find(queryObject)
                .populate("assignedBots", "name")
                .populate("tags", "name")
                .sort({ createdAt: -1 })
                .skip(documentsToSkip);
            if (limitOfDocuments) {
                agents.limit(limitOfDocuments);
            }
            const data = await agents;
            const count = await this.agentModel.count();
            return { data, count };
        }
        catch (error) {
            this.logger.error(`Error while finding Agents: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async findOne(agentId) {
        try {
            return await this.agentModel
                .findOne({
                _id: agentId,
            })
                .populate("tags", "name")
                .populate("assignedBots", "name status createdAt")
                .populate({
                path: "conversations",
                populate: [
                    {
                        path: "visitor",
                        select: "name email",
                    },
                    {
                        path: "bot",
                        select: "name",
                    },
                    {
                        path: "feedbacks",
                        select: "rating comment",
                    },
                ],
                select: "visitor status createdAt platform ",
            })
                .populate("serviceRequests", "priority status createdAt subject description ticketId");
        }
        catch (error) {
            this.logger.error(`Error while finding Agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async assignAgent(botId) {
        try {
            this.logger.log(`Assigning Agent to bot with id ${botId}`);
            const agents = await this.agentModel
                .find({
                assignedBots: { $in: [botId] },
                status: agent_status_enum_1.AgentStatusEnum.ONLINE,
            })
                .sort({
                activeConversations: 1,
                maxConcurrentChats: 1,
            })
                .select("_id maxConcurrentChats activeConversations name")
                .limit(1);
            if (agents.length) {
                const agent = agents[0];
                if (agent.maxConcurrentChats > agent.activeConversations) {
                    agent.activeConversations += 1;
                    await agent.save();
                    return agent;
                }
                return agent;
            }
            return null;
        }
        catch (error) {
            this.logger.error(`Error in assign agent: ${error.message}`);
            throw new Error(error.message);
        }
    }
    async addBotToAgent(botId, agents) {
        try {
            await Promise.all(agents.map(async (agentId) => {
                const agent = await this.agentModel.findOne({
                    _id: new mongoose_1.default.Types.ObjectId(agentId),
                });
                if (agent) {
                    const uniqueBots = new Set(agent.assignedBots.map((bot) => bot.toHexString()));
                    uniqueBots.add(botId.toHexString());
                    agent.assignedBots = [...uniqueBots];
                    await agent.save();
                }
            }));
        }
        catch (error) {
            this.logger.error(`Error in addBotToAgent: ${error.message}`);
            throw new Error(error.message);
        }
    }
    async updateAgentStatus(agentId, status) {
        const agent = await this.agentModel.findOne({
            _id: agentId,
        });
        if (agent) {
            agent.status = status;
            if (status === agent_status_enum_1.AgentStatusEnum.OFFLINE) {
                agent.activeConversations = 0;
                agent.lastSeen = new Date();
            }
            if (status === agent_status_enum_1.AgentStatusEnum.ONLINE) {
                agent.lastSeen = new Date();
            }
            await agent.save();
        }
    }
    async getMe(user) {
        try {
            const agentData = await this.agentModel.findOne({ _id: user._id });
            if (!agentData) {
                throw new common_1.HttpException("Agent not found", 401);
            }
            return {
                email: agentData.email,
                username: agentData.email,
                _id: agentData._id,
                fullName: agentData.name,
                role: agentData.role,
            };
        }
        catch (error) {
            this.logger.error(`Error while finding Agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async addConversations({ agentId, conversationId, }) {
        try {
            const agent = await this.agentModel.findById(agentId);
            if (!agent)
                return;
            agent.conversations.push(conversationId);
            agent.save();
            return agent;
        }
        catch (error) {
            this.logger.error(`Error while adding conversation to visitor with id ${agentId} : ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async updateRatingAndFeedback(agentId, rating, feedbackId) {
        try {
            const agent = await this.agentModel.findById(agentId);
            if (agent) {
                agent.totalRating = agent.totalRating + rating;
                agent.totalRatingCount += 1;
                agent.rating =
                    Math.round((agent.totalRating / agent.totalRatingCount) * 10) / 10;
                agent.feedbacks.push(feedbackId);
                await agent.save();
            }
        }
        catch (error) {
            this.logger.error(`Error while adding rating and feedback to agent with id ${agentId} : ${error.message}`);
        }
    }
    async getTotalCount(days = 30) {
        const total = await this.agentModel.countDocuments();
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.agentModel.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - 60)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Total Agents",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "main",
        };
    }
    async getOnlineAgentsCount(days = 1) {
        const total = await this.agentModel.countDocuments({
            status: agent_status_enum_1.AgentStatusEnum.ONLINE,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.agentModel.countDocuments({
                status: agent_status_enum_1.AgentStatusEnum.ONLINE,
                lastSeen: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Online Agents",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "online_agent",
        };
    }
    async getActiveAgentsCount(days = 30) {
        const total = await this.agentModel.countDocuments({
            active: true,
        });
        let percentageChange = 0;
        if (total) {
            const agoCount = await this.agentModel.countDocuments({
                active: true,
                createdAt: {
                    $gte: new Date(new Date().setDate(new Date().getDate() - days)),
                },
            });
            percentageChange = Math.round((agoCount / total) * 100);
        }
        return {
            stats: total,
            trendNumber: percentageChange,
            trend: percentageChange >= 0 ? "positive" : "negative",
            title: "Active Agents",
            subtitle: (0, get_subtitle_1.getDaySubtitle)(days),
            type: "active_agent",
        };
    }
    async getStats() {
        try {
            const result = await Promise.all([
                this.getTotalCount(),
                this.getOnlineAgentsCount(1),
                this.getActiveAgentsCount(),
            ]);
            return result;
        }
        catch (error) {
            this.logger.error(`Error while getting stats: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async getTotalAgent() {
        try {
            const response = await this.agentModel.aggregate([
                {
                    $group: {
                        _id: null,
                        total: { $sum: 1 },
                        active: { $sum: { $cond: [{ $eq: ["$active", true] }, 1, 0] } },
                        inactive: { $sum: { $cond: [{ $eq: ["$active", false] }, 1, 0] } },
                    },
                },
                {
                    $project: {
                        _id: 0,
                    },
                },
            ]);
            return response[0];
        }
        catch (error) {
            this.logger.error(`Error while getting total agent: ${error.message}`);
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
    async dayWisePerformance(query) {
        query.agentId = query.id;
        delete query.id;
        return await this.conversationService.getDayWisePerformance(query, true);
    }
    async dateWiseConversations(query) {
        query.agentId = query.id;
        delete query.id;
        return await this.conversationService.getDateWiseConversations(query, true);
    }
    async addServiceRequest(data) {
        const { agentId, ticketId } = data;
        try {
            const agent = await this.agentModel.findById(agentId);
            if (agent) {
                agent.serviceRequests = [
                    ...new Set([...agent.serviceRequests, ticketId]),
                ];
                await agent.save();
            }
        }
        catch (error) {
            this.logger.error(`Error while adding service request to agent with id ${agentId} : ${error.message}`);
        }
    }
    async welcomeToAgent(agentId) {
        try {
            const agent = await this.agentModel.findOne({
                _id: agentId,
            });
            if (!agent) {
                throw new common_1.HttpException("Not found", 404);
            }
            const requestHandled = agent.serviceRequests.length;
            const rating = agent.rating;
            const days = Math.round((new Date().getTime() - agent.createdAt.getTime()) / (1000 * 3600 * 24));
            const visitorModel = mongoose_1.default.model("Visitor");
            const visitorCount = await visitorModel.countDocuments({
                agents: {
                    $in: [agentId],
                },
            });
            return {
                requestHandled,
                days,
                visitorCount,
            };
        }
        catch (error) {
            throw new common_1.HttpException(error.message, error.status || 500);
        }
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)("conversation.created.agent", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AgentService.prototype, "addConversations", null);
__decorate([
    (0, event_emitter_1.OnEvent)("ticket.assigned.agent", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AgentService.prototype, "addServiceRequest", null);
AgentService = AgentService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(constants_1.AGENT_PROVIDER)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        config_1.ConfigService,
        conversation_service_1.ConversationService])
], AgentService);
exports.AgentService = AgentService;
//# sourceMappingURL=agent.service.js.map