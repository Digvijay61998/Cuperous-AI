"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAgentDto = void 0;
const class_validator_1 = require("class-validator");
const agent_status_enum_1 = require("../enums/agent-status.enum");
const swagger_1 = require("@nestjs/swagger");
class CreateAgentDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, swagger_1.ApiProperty)({
        description: "Name of the agent",
        example: "Agent 1",
    }),
    __metadata("design:type", String)
], CreateAgentDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsEmail)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, swagger_1.ApiProperty)({
        description: "Email of the agent",
        example: "agent@email.com",
    }),
    __metadata("design:type", String)
], CreateAgentDto.prototype, "email", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, swagger_1.ApiProperty)({
        description: "Password of the agent",
        example: "123456",
    }),
    __metadata("design:type", String)
], CreateAgentDto.prototype, "password", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateAgentDto.prototype, "active", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(agent_status_enum_1.AgentStatusEnum),
    (0, class_validator_1.IsOptional)(),
    (0, swagger_1.ApiProperty)({
        enum: agent_status_enum_1.AgentStatusEnum,
    }),
    __metadata("design:type", String)
], CreateAgentDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    (0, swagger_1.ApiProperty)({
        description: "Assign bots to agent",
        example: ["5f9e1b9b9c9b9c0b8c8c8c8c"],
    }),
    __metadata("design:type", Array)
], CreateAgentDto.prototype, "assignedBots", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsArray)(),
    (0, swagger_1.ApiProperty)({
        description: "Tags for the agent",
        example: ["5f9e1b9b9c9b9c0b8c8c8c8c"],
    }),
    __metadata("design:type", Array)
], CreateAgentDto.prototype, "tags", void 0);
__decorate([
    (0, class_validator_1.IsBase64)(),
    (0, class_validator_1.IsOptional)(),
    (0, swagger_1.ApiProperty)({
        description: "base64 Profile picture of the agent",
    }),
    __metadata("design:type", String)
], CreateAgentDto.prototype, "profilePic", void 0);
exports.CreateAgentDto = CreateAgentDto;
//# sourceMappingURL=create-agent.dto.js.map