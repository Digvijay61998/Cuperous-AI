import { AgentStatusEnum } from "../enums/agent-status.enum";
import { ObjectId } from "mongoose";
export declare class CreateAgentDto {
    name: string;
    email: string;
    password: string;
    active: boolean;
    status: AgentStatusEnum;
    assignedBots: [ObjectId];
    tags: [ObjectId];
    profilePic: string;
}
