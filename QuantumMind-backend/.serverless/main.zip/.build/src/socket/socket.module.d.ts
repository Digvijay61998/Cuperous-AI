export declare class SocketModule {
}
