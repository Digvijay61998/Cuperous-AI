import { Socket } from "socket.io";
import { BotFlowNode, BotSetting } from "src/bots/entities";
import { BotNodeStateEnum } from "src/message-handler/enums/bot-node-state.enum";
import { ConversationService } from "src/conversation/conversation.service";
import { AgentService } from "src/agent/agent.service";
import { VisitorService } from "src/visitor/visitor.service";
import { ModeEnum } from "src/widget/enums/mode.enum";
import { AuthenticatedSocket } from "./socket.adaptor";
export interface SocketConversation {
    _id: string;
    visitor: {
        _id: string;
        name: string;
    };
    lastMessage?: any;
}
export interface SocketState {
    attributes?: Record<string, unknown>;
    currentNode?: BotFlowNode;
    socket?: Socket[] | any[];
    role?: string;
    botId?: string;
    defaultFallback?: BotFlowNode;
    adminId?: string;
    BotNodeState?: Record<string, unknown>;
    startNode?: BotFlowNode;
    conversationId?: string;
    questionNodeState?: Record<string, unknown>;
    botSettings?: BotSetting;
    mode?: ModeEnum;
    handledByAgent?: boolean;
    assignedAgentId?: string;
    platform?: string;
    botName?: string;
    metadata?: Record<string, unknown>;
    ctx?: any;
}
export declare class SocketStateService {
    private conversationService;
    private readonly agentService;
    private readonly visitorService;
    constructor(conversationService: ConversationService, agentService: AgentService, visitorService: VisitorService);
    private socketState;
    add(userId: string, socket: AuthenticatedSocket): boolean;
    remove(userId: string, socket: AuthenticatedSocket): boolean;
    getSocket(userId: string): Socket[];
    getAllSockets(): Socket[];
    getUserData(userId: string): SocketState;
    updateUserData(userId: string, data: SocketState): void;
    getNodeState(userId: string, nodeId: string): unknown;
    setNodeState(userId: string, nodeId: string, state: BotNodeStateEnum): void;
    setQuestionNodeState(userId: string, nodeId: string, state: any): void;
    getQuestionNodeState(userId: string, nodeId: string): any;
    onEndConversation(data: {
        userId: string;
    }): void;
}
