"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketStateService = void 0;
const common_1 = require("@nestjs/common");
const bot_node_state_enum_1 = require("src/message-handler/enums/bot-node-state.enum");
const conversation_service_1 = require("src/conversation/conversation.service");
const agent_service_1 = require("src/agent/agent.service");
const visitor_service_1 = require("src/visitor/visitor.service");
const mode_enum_1 = require("src/widget/enums/mode.enum");
const visitor_status_enum_1 = require("src/visitor/enums/visitor-status.enum");
const agent_status_enum_1 = require("src/agent/enums/agent-status.enum");
const conversation_status_enum_1 = require("src/conversation/enums/conversation-status.enum");
const event_emitter_1 = require("@nestjs/event-emitter");
let SocketStateService = class SocketStateService {
    constructor(conversationService, agentService, visitorService) {
        this.conversationService = conversationService;
        this.agentService = agentService;
        this.visitorService = visitorService;
        this.socketState = new Map();
    }
    add(userId, socket) {
        var _a, _b;
        const existingSockets = ((_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.socket) || [];
        if (!existingSockets || !existingSockets.length) {
            const role = socket.auth.role;
            if (role === "visitor" &&
                ((_b = this.socketState.get(userId)) === null || _b === void 0 ? void 0 : _b.mode) !== mode_enum_1.ModeEnum.preview)
                this.visitorService.updateStatus(userId, visitor_status_enum_1.VisitorStatusEnum.ONLINE);
            else
                this.agentService.updateAgentStatus(userId, agent_status_enum_1.AgentStatusEnum.ONLINE);
        }
        const sockets = [...existingSockets, socket];
        this.socketState.set(userId, Object.assign(Object.assign({}, this.socketState.get(userId)), { socket: sockets }));
        return true;
    }
    remove(userId, socket) {
        const existingSockets = this.socketState.get(userId).socket || [];
        if (!existingSockets) {
            return true;
        }
        const sockets = existingSockets.filter((s) => s.id !== socket.id);
        if (!sockets.length) {
            const role = socket.auth.role;
            if (role === "visitor" && this.socketState.get(userId).handledByAgent) {
                const conversationId = this.socketState.get(userId).conversationId;
                this.visitorService.updateStatus(userId, visitor_status_enum_1.VisitorStatusEnum.OFFLINE);
                this.conversationService.endConversation(conversationId, conversation_status_enum_1.ConversationStatusEnum.EXPIRED);
            }
            else {
                this.agentService.updateAgentStatus(userId, agent_status_enum_1.AgentStatusEnum.OFFLINE);
            }
            this.socketState.delete(userId);
        }
        else {
            this.socketState.set(userId, {
                socket: sockets,
            });
        }
        return true;
    }
    getSocket(userId) {
        var _a;
        return ((_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.socket) || [];
    }
    getAllSockets() {
        const all = [];
        this.socketState.forEach((sockets) => all.push(sockets.socket));
        return all;
    }
    getUserData(userId) {
        return this.socketState.get(userId);
    }
    updateUserData(userId, data) {
        const user = this.socketState.get(userId);
        this.socketState.set(userId, Object.assign(Object.assign({}, this.socketState.get(userId)), data));
        if (data.attributes) {
            this.conversationService.addattributes(data.conversationId, data.attributes);
        }
    }
    getNodeState(userId, nodeId) {
        var _a, _b;
        return (((_b = (_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.BotNodeState) === null || _b === void 0 ? void 0 : _b[nodeId]) ||
            bot_node_state_enum_1.BotNodeStateEnum.NEW);
    }
    setNodeState(userId, nodeId, state) {
        var _a;
        this.socketState.set(userId, Object.assign(Object.assign({}, this.socketState.get(userId)), { BotNodeState: Object.assign(Object.assign({}, (_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.BotNodeState), { [nodeId]: state }) }));
    }
    setQuestionNodeState(userId, nodeId, state) {
        var _a;
        this.socketState.set(userId, Object.assign(Object.assign({}, this.socketState.get(userId)), { questionNodeState: Object.assign(Object.assign({}, (_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.questionNodeState), { [nodeId]: state }) }));
    }
    getQuestionNodeState(userId, nodeId) {
        var _a, _b;
        return (_b = (_a = this.socketState.get(userId)) === null || _a === void 0 ? void 0 : _a.questionNodeState) === null || _b === void 0 ? void 0 : _b[nodeId];
    }
    onEndConversation(data) {
        this.socketState.delete(data.userId);
    }
};
__decorate([
    (0, event_emitter_1.OnEvent)("end.conversation", { async: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SocketStateService.prototype, "onEndConversation", null);
SocketStateService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [conversation_service_1.ConversationService,
        agent_service_1.AgentService,
        visitor_service_1.VisitorService])
], SocketStateService);
exports.SocketStateService = SocketStateService;
//# sourceMappingURL=socket-state.service.js.map