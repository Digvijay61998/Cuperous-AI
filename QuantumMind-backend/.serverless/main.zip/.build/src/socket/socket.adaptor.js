"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthMiddleware = exports.SocketStateAdapter = void 0;
const platform_socket_io_1 = require("@nestjs/platform-socket.io");
const token_service_1 = require("src/token/token.service");
const mode_enum_1 = require("src/widget/enums/mode.enum");
const widget_service_1 = require("src/widget/widget.service");
class SocketStateAdapter extends platform_socket_io_1.IoAdapter {
    constructor(app, socketStateService, redisPropagatorService) {
        super(app);
        this.app = app;
        this.socketStateService = socketStateService;
        this.redisPropagatorService = redisPropagatorService;
    }
    create(port, options) {
        this.server = super.createIOServer(port, options);
        this.redisPropagatorService.injectSocketServer(this.server);
        const tokenService = this.app.get(token_service_1.TokenService);
        const widgetService = this.app.get(widget_service_1.WidgetService);
        this.server.use((0, exports.AuthMiddleware)(tokenService, widgetService));
        return this.server;
    }
    bindClientConnect(server, callback) {
        server.on('connection', (socket) => {
            if (socket.auth) {
                this.socketStateService.add(socket.auth.userId, socket);
                socket.on('disconnect', () => {
                    this.socketStateService.remove(socket.auth.userId, socket);
                    socket.removeAllListeners('disconnect');
                });
            }
            callback(socket);
        });
    }
}
exports.SocketStateAdapter = SocketStateAdapter;
const AuthMiddleware = (tokenService, widgetService) => async (socket, next) => {
    let token = socket.handshake.auth.token || socket.handshake.headers['token'];
    if (!token) {
        const { accessToken } = await widgetService.createVisitor({
            name: '',
            email: '',
        }, '', {
            botId: '63b3c4f389f60e8e3a8df60b',
            mode: mode_enum_1.ModeEnum.live,
        });
        token = accessToken;
    }
    try {
        const decoded = tokenService.verify(token);
        socket.auth = Object.assign({ userId: decoded._id }, decoded);
        next();
    }
    catch (e) {
        return next(e);
    }
};
exports.AuthMiddleware = AuthMiddleware;
//# sourceMappingURL=socket.adaptor.js.map