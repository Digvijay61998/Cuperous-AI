import { INestApplicationContext, WebSocketAdapter } from '@nestjs/common';
import { IoAdapter } from '@nestjs/platform-socket.io';
import socketio, { ServerOptions } from 'socket.io';
import { RedisPropagatorService } from 'src/redis-propagate/redis-propagate.service';
import { TokenService } from 'src/token/token.service';
import { ModeEnum } from 'src/widget/enums/mode.enum';
import { WidgetService } from 'src/widget/widget.service';
import { SocketStateService } from './socket-state.service';
interface SocketAuthData {
    readonly role: string;
    readonly userId: string;
    readonly name?: string;
    readonly email?: string;
    readonly adminId?: string;
    readonly mode?: ModeEnum;
}
export interface AuthenticatedSocket extends socketio.Socket {
    auth: SocketAuthData;
}
export declare class SocketStateAdapter extends IoAdapter implements WebSocketAdapter {
    private readonly app;
    private readonly socketStateService;
    private readonly redisPropagatorService;
    constructor(app: INestApplicationContext, socketStateService: SocketStateService, redisPropagatorService: RedisPropagatorService);
    private server;
    create(port: number, options: ServerOptions & {
        namespace?: string;
    }): socketio.Server;
    bindClientConnect(server: socketio.Server, callback: any): void;
}
export declare const AuthMiddleware: (tokenService: TokenService, widgetService: WidgetService) => (socket: AuthenticatedSocket, next: any) => Promise<any>;
export {};
